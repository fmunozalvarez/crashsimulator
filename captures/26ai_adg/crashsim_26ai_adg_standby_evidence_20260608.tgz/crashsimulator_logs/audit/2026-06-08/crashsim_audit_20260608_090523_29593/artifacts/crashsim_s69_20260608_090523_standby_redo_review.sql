whenever sqlerror exit sql.sqlcode
set pages 200 lines 260 trimspool on tab off feedback off heading off

select 'CSIM_SRL|database_role|' || database_role from v$database;
select 'CSIM_SRL|protection_mode|' || protection_mode from v$database;
select 'CSIM_SRL|open_mode|' || open_mode from v$database;

select 'CSIM_SRL|online_thread|' || thread# ||
       '|online_groups|' || count(*) ||
       '|online_max_mb|' || round(max(bytes)/1024/1024, 2)
from v$log
group by thread#
order by thread#;

select 'CSIM_SRL|standby_thread|' || thread# ||
       '|srl_groups|' || count(*) ||
       '|srl_max_mb|' || round(max(bytes)/1024/1024, 2)
from v$standby_log
group by thread#
order by thread#;

with online_redo as (
  select thread#, count(*) online_groups, max(bytes) max_online_bytes
  from v$log
  group by thread#
),
standby_redo as (
  select thread#, count(*) srl_groups, max(bytes) max_srl_bytes
  from v$standby_log
  group by thread#
),
threads as (
  select thread# from online_redo
  union
  select thread# from standby_redo
)
select 'CSIM_SRL|thread|' || t.thread# ||
       '|online_groups|' || nvl(o.online_groups, 0) ||
       '|required_srl_groups|' || (nvl(o.online_groups, 0) + 1) ||
       '|actual_srl_groups|' || nvl(s.srl_groups, 0) ||
       '|online_max_mb|' || round(nvl(o.max_online_bytes, 0)/1024/1024, 2) ||
       '|srl_max_mb|' || round(nvl(s.max_srl_bytes, 0)/1024/1024, 2) ||
       '|status|' ||
       case
         when nvl(s.srl_groups, 0) = 0 then 'MISSING_SRLS'
         when nvl(s.srl_groups, 0) < nvl(o.online_groups, 0) + 1 then 'TOO_FEW_SRLS'
         when nvl(s.max_srl_bytes, 0) < nvl(o.max_online_bytes, 0) then 'SRL_TOO_SMALL'
         else 'OK'
       end
from threads t
left join online_redo o on o.thread# = t.thread#
left join standby_redo s on s.thread# = t.thread#
order by t.thread#;

exit
