# CrashSimulator Review Center

- Generated UTC: `2026-06-08T09:06:38Z`
- Log directory: `/tmp/crashsimulator/crashsimulator_logs`
- Audit directory: `/tmp/crashsimulator/crashsimulator_logs/audit`

This index lists previously collected CrashSimulator topology snapshots, scenario manifests, runbooks, dry-run/execution audit records, health checks, and reports. It does not reconnect to the database.

## Latest Collected Topology

- Latest topology artifact: `/tmp/crashsimulator/crashsimulator_logs/crashsim_topology_latest.txt`
- Latest service HA review: `/tmp/crashsimulator/crashsimulator_logs/crashsim_service_review_20260608_090535.md`
- Latest scenario readiness report: `/tmp/crashsimulator/crashsimulator_logs/crashsim_scenario_readiness_latest.md`
- Latest MAA readiness report: `/tmp/crashsimulator/crashsimulator_logs/crashsim_maa_report_20260608_090541.md`
- Latest health check: `/tmp/crashsimulator/crashsimulator_logs/crashsim_health_check_20260608_090549.log`

## Scenario / Protection / Recovery Manifests

No stored manifests found.

## Runbooks

No stored artifacts found.

## Health Checks

- `/tmp/crashsimulator/crashsimulator_logs/crashsim_health_check_20260608_090549.log`

## Configuration Reports

No stored artifacts found.

## Backup Strategy / Recoverability Reports

No stored artifacts found.

## Service HA Reviews

- `/tmp/crashsimulator/crashsimulator_logs/crashsim_service_review_20260608_090535.md`

## APEX / ORDS Readiness Reports

No stored artifacts found.

## Scenario Readiness Reports

- `/tmp/crashsimulator/crashsimulator_logs/crashsim_scenario_readiness_20260608_090523.md`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_scenario_readiness_latest.md`

## Scenario Lifecycle Coverage Reports

No stored artifacts found.

## MAA Readiness Reports

- `/tmp/crashsimulator/crashsimulator_logs/crashsim_maa_report_20260608_090541.md`

## Baseline Backup Plans And Logs

No stored artifacts found.

## RMAN And SQL Helper Files

- `/tmp/crashsimulator/crashsimulator_logs/crashsim_maa_report_20260608_090541.sql`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_s69_20260608_090523_standby_redo_review.sql`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_service_review_20260608_090535.sql`

## Audit Records

- `/tmp/crashsimulator/crashsimulator_logs/audit/2026-06-08/crashsim_audit_20260608_090523_29593` - mode `scenario_readiness_report`, started `2026-06-08T09:05:24Z`, exit `0`
  Command: `./CrashSimulatorV2.sh --scenario-readiness-report --pdb CRASHPDB --html`
- `/tmp/crashsimulator/crashsimulator_logs/audit/2026-06-08/crashsim_audit_20260608_090535_32284` - mode `service_review`, started `2026-06-08T09:05:35Z`, exit `0`
  Command: `./CrashSimulatorV2.sh --service-review --html`
- `/tmp/crashsimulator/crashsimulator_logs/audit/2026-06-08/crashsim_audit_20260608_090541_33043` - mode `maa_report`, started `2026-06-08T09:05:41Z`, exit `0`
  Command: `./CrashSimulatorV2.sh --maa-report --html`
- `/tmp/crashsimulator/crashsimulator_logs/audit/2026-06-08/crashsim_audit_20260608_090549_34884` - mode `health`, started `2026-06-08T09:05:50Z`, exit `0`
  Command: `./CrashSimulatorV2.sh --health-check`

## Access Shortcuts

- Show latest topology: `./CrashSimulatorV2.sh --review-topology`
- Show latest scenario readiness report: `./CrashSimulatorV2.sh --show-artifact latest:scenario-readiness`
- Show latest scenario lifecycle report: `./CrashSimulatorV2.sh --show-artifact latest:lifecycle`
- Show latest health check: `./CrashSimulatorV2.sh --show-artifact latest:health`
- Generate HTML for latest review index: `./CrashSimulatorV2.sh --render-html latest:review`
- Generate HTML for a specific artifact: `./CrashSimulatorV2.sh --render-html /path/to/artifact`
