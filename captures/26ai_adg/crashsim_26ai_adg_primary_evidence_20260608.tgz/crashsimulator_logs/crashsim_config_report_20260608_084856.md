# CrashSimulator Target Database Configuration Report

- Generated UTC: `2026-06-08T08:48:58Z`
- Host: `crashrac1-xnvfw`
- OS user: `oracle`
- Database: `CRASHDB`
- DB unique name: `crashrdb`
- Instance/SID: `crashdb1`
- Role/open mode: `PRIMARY` / `READ WRITE`
- CDB: `YES`
- Storage: `FILESYSTEM`
- Cluster type: `RAC`
- Oracle home: `/u02/app/oracle/product/23.0.0.0/dbhome_1`
- Deep RMAN validation: `disabled`
- SQL evidence file: `/tmp/crashsimulator/crashsimulator_logs/crashsim_config_report_20260608_084856.sql`

Backup and recoverability notes: this report includes RMAN metadata, backup coverage by datafile, corruption views, and an RMAN restore preview. External schedulers or OCI backup policies may need separate inspection when they are not visible in target database RMAN history.

## SQL Database, PDB, Storage, Backup, TDE, Data Guard, And Corruption Evidence

Command: /u02/app/oracle/product/23.0.0.0/dbhome_1/bin/sqlplus -s /\ as\ sysdba @/tmp/crashsimulator/crashsimulator_logs/crashsim_config_report_20260608_084856.sql

```text
# SQL Evidence

## Database Identity

NAME                               DB_UNIQUE_NAME                                 DBID PLATFORM_NAME                                                                                         DATABASE_ROLE    OPEN_MODE            CDB LOG_MODE
---------------------------------- ------------------------------ -------------------- ----------------------------------------------------------------------------------------------------- ---------------- -------------------- --- ------------
FORCE_LOGGING                           FLASHBACK_ON       PROTECTION_MODE      SWITCHOVER_STATUS
--------------------------------------- ------------------ -------------------- --------------------
CRASHDB                            crashrdb                                 1275206961 Linux x86 64-bit                                                                                      PRIMARY          READ WRITE           YES ARCHIVELOG
YES                                     YES                MAXIMUM PERFORMANCE  TO STANDBY


1 row selected.

## Instance Identity

INSTANCE_NAME    HOST_NAME                                                        VERSION           STATUS       DATABASE_STATUS   ACTIVE_ST PAR              THREAD# ARCHIVE STARTUP_TIME
---------------- ---------------------------------------------------------------- ----------------- ------------ ----------------- --------- --- -------------------- ------- -------------------
crashdb1         crashrac1-xnvfw                                                  23.0.0.0.0        OPEN         ACTIVE            NORMAL    YES                    1 STARTED 2026-06-08 04:38:03

1 row selected.

## Database Version

no rows selected

## Key Paths And Parameters

NAME                               DISPLAY_VALUE
---------------------------------- ------------------------------------------------------------------------------------------------------------------------
adg_redirect_dml                   FALSE
audit_file_dest                    /u02/app/oracle/product/23.0.0.0/dbhome_1/rdbms/audit
cluster_database                   TRUE
compatible                         23.6.0
control_files                      @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/CONTROLFILE/Current.OMF.713193E5
db_create_file_dest                @rJOnB8bM(DATA_HC_HIGHREDUNDANCY)
db_create_online_log_dest_1        @rJOnB8bM(DATA_HC_HIGHREDUNDANCY)
db_create_online_log_dest_2
db_name                            crashdb
db_recovery_file_dest              @rJOnB8bM(RECO_HC_HIGHREDUNDANCY)
db_recovery_file_dest_size         240G
db_unique_name                     crashrdb
diagnostic_dest                    /u02/app/oracle
enable_pluggable_database          TRUE
remote_login_passwordfile          EXCLUSIVE
spfile                             @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/PARAMETERFILE/spfile.OMF.37A52C57
tde_configuration                  keystore_configuration=FILE
wallet_root                        /var/opt/oracle/dbaas_acfs/crashdb/wallet_root

18 rows selected.

## Non-Default Database Parameters

PARAMETER_NAME                                             TYPE ISDEFAULT ISMODIFIED ISSYS_MOD ISPDB DISPLAY_VALUE
------------------------------------------ -------------------- --------- ---------- --------- ----- ------------------------------------------------------------------------------------------------------------------------
_gc_bypass_readers                                            1 FALSE     FALSE      IMMEDIATE TRUE  TRUE
_instance_recovery_bloom_filter_size                          3 FALSE     FALSE      IMMEDIATE FALSE 1048576
_parallel_adaptive_max_users                                  3 FALSE     FALSE      IMMEDIATE FALSE 2
cluster_database                                              1 FALSE     FALSE      FALSE     FALSE TRUE
compatible                                                    2 FALSE     FALSE      IMMEDIATE FALSE 23.6.0
control_files                                                 2 FALSE     FALSE      FALSE     FALSE @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/CONTROLFILE/Current.OMF.713193E5
control_management_pack_access                                2 FALSE     FALSE      IMMEDIATE FALSE DIAGNOSTIC+TUNING
db_block_checking                                             2 FALSE     FALSE      IMMEDIATE TRUE  OFF
db_block_checksum                                             2 FALSE     SYSTEM_MOD IMMEDIATE FALSE TYPICAL
db_block_size                                                 3 FALSE     FALSE      FALSE     FALSE 8192
db_create_file_dest                                           2 FALSE     FALSE      IMMEDIATE TRUE  @rJOnB8bM(DATA_HC_HIGHREDUNDANCY)
db_create_online_log_dest_1                                   2 FALSE     FALSE      IMMEDIATE TRUE  @rJOnB8bM(DATA_HC_HIGHREDUNDANCY)
db_domain                                                     2 FALSE     FALSE      FALSE     TRUE  clientsubnet.dns.oraclevcn.com
db_files                                                      3 FALSE     FALSE      FALSE     TRUE  1024
db_flashback_retention_target                                 3 FALSE     FALSE      IMMEDIATE FALSE 1440
db_lost_write_protect                                         2 FALSE     SYSTEM_MOD IMMEDIATE TRUE  TYPICAL
db_name                                                       2 FALSE     FALSE      FALSE     FALSE crashdb
db_recovery_file_dest                                         2 FALSE     FALSE      IMMEDIATE FALSE @rJOnB8bM(RECO_HC_HIGHREDUNDANCY)
db_recovery_file_dest_size                                    6 FALSE     FALSE      IMMEDIATE FALSE 240G
db_unique_name                                                2 FALSE     FALSE      FALSE     FALSE crashrdb
diagnostic_dest                                               2 FALSE     FALSE      IMMEDIATE FALSE /u02/app/oracle
dispatchers                                                   2 FALSE     FALSE      IMMEDIATE FALSE (PROTOCOL=TCP) (SERVICE=crashdbXDB)
distributed_lock_timeout                                      3 FALSE     FALSE      IMMEDIATE TRUE  360
enable_ddl_logging                                            1 FALSE     FALSE      IMMEDIATE TRUE  TRUE
enable_pluggable_database                                     1 FALSE     FALSE      FALSE     FALSE TRUE
fast_start_mttr_target                                        3 FALSE     SYSTEM_MOD IMMEDIATE FALSE 300
filesystemio_options                                          2 FALSE     FALSE      FALSE     FALSE setall
global_names                                                  1 FALSE     FALSE      IMMEDIATE TRUE  TRUE
inmemory_force                                                2 FALSE     FALSE      IMMEDIATE TRUE  cellmemory_level
instance_number                                               3 FALSE     FALSE      FALSE     FALSE 1
local_listener                                                2 FALSE     SYSTEM_MOD IMMEDIATE TRUE   (ADDRESS=(PROTOCOL=TCP)(HOST=10.2.0.57)(PORT=1521)), (ADDRESS=(PROTOCOL=TCPS)(HOST=10.2.0.57)(PORT=2484))
log_archive_dest_1                                            2 FALSE     FALSE      IMMEDIATE FALSE LOCATION=USE_DB_RECOVERY_FILE_DEST VALID_FOR=(ALL_LOGFILES,ALL_ROLES) MAX_FAILURE=1 REOPEN=5 DB_UNIQUE_NAME=crashrdb ALT
                                                                                                     ERNATE=LOG_ARCHIVE_DEST_10

log_archive_dest_10                                           2 FALSE     FALSE      IMMEDIATE FALSE LOCATION=@rJOnB8bM VALID_FOR=(ALL_LOGFILES,ALL_ROLES) DB_UNIQUE_NAME=crashrdb ALTERNATE=LOG_ARCHIVE_DEST_1
log_archive_dest_state_1                                      2 FALSE     FALSE      IMMEDIATE FALSE ENABLE
log_archive_dest_state_10                                     2 FALSE     FALSE      IMMEDIATE FALSE ALTERNATE
log_archive_dest_state_2                                      2 FALSE     SYSTEM_MOD IMMEDIATE FALSE ENABLE
log_archive_format                                            2 FALSE     FALSE      FALSE     FALSE %t_%s_%r.dbf
log_buffer                                                    6 FALSE     FALSE      FALSE     FALSE 256M
nls_language                                                  2 FALSE     FALSE      FALSE     TRUE  AMERICAN
nls_territory                                                 2 FALSE     FALSE      FALSE     TRUE  AMERICA
open_cursors                                                  3 FALSE     FALSE      IMMEDIATE TRUE  1000
os_authent_prefix                                             2 FALSE     FALSE      FALSE     FALSE
parallel_execution_message_size                               3 FALSE     FALSE      FALSE     FALSE 16384
parallel_threads_per_cpu                                      3 FALSE     FALSE      IMMEDIATE FALSE 1
pga_aggregate_target                                          6 FALSE     FALSE      IMMEDIATE TRUE  2500M
processes                                                     3 FALSE     FALSE      IMMEDIATE FALSE 2048
recyclebin                                                    2 FALSE     FALSE      DEFERRED  TRUE  on
remote_listener                                               2 FALSE     SYSTEM_MOD IMMEDIATE TRUE  crashrac-scan-tsrch.clientsubnet.dns.oraclevcn.com:1521
remote_login_passwordfile                                     2 FALSE     FALSE      FALSE     FALSE EXCLUSIVE
sec_protocol_error_further_action                             2 FALSE     FALSE      IMMEDIATE FALSE (DROP,3)
sga_target                                                    6 FALSE     FALSE      IMMEDIATE TRUE  3808M
sql92_security                                                1 FALSE     FALSE      FALSE     TRUE  TRUE
tablespace_encryption                                         2 FALSE     FALSE      FALSE     FALSE AUTO_ENABLE
tde_configuration                                             2 FALSE     FALSE      IMMEDIATE TRUE  keystore_configuration=FILE
thread                                                        3 FALSE     FALSE      IMMEDIATE FALSE 1
undo_tablespace                                               2 FALSE     FALSE      IMMEDIATE TRUE  UNDOTBS1
use_large_pages                                               2 FALSE     FALSE      FALSE     FALSE ONLY
wallet_root                                                   2 FALSE     FALSE      FALSE     FALSE /var/opt/oracle/dbaas_acfs/crashdb/wallet_root

58 rows selected.

## Diagnostic And Trace Locations

NAME                               VALUE
---------------------------------- ------------------------------------------------------------------------------------------------------------------------
ADR Base                           /u02/app/oracle
ADR Home                           /u02/app/oracle/diag/rdbms/crashrdb/crashdb1
Active Incident Count              0
Active Problem Count               0
Attention Log                      /u02/app/oracle/diag/rdbms/crashrdb/crashdb1/trace/attention_crashdb1.log
Default Trace File                 /u02/app/oracle/diag/rdbms/crashrdb/crashdb1/trace/crashdb1_ora_191981.trc
Diag Alert                         /u02/app/oracle/diag/rdbms/crashrdb/crashdb1/alert
Diag Cdump                         /u02/app/oracle/diag/rdbms/crashrdb/crashdb1/cdump
Diag Enabled                       TRUE
Diag Incident                      /u02/app/oracle/diag/rdbms/crashrdb/crashdb1/incident
Diag Trace                         /u02/app/oracle/diag/rdbms/crashrdb/crashdb1/trace
Health Monitor                     /u02/app/oracle/diag/rdbms/crashrdb/crashdb1/hm
ORACLE_HOME                        /u02/app/oracle/product/23.0.0.0/dbhome_1

13 rows selected.

## Control Files

NAME
----------------------------------
@rJOnB8bM/CREASHRAC-A4FEA717C5C96F
3BFFC46A6348A21A9F/CRASHRDB/CONTRO
LFILE/Current.OMF.713193E5


1 row selected.

## Redo Log Groups

              GROUP#              THREAD#            SEQUENCE#              SIZE_MB            BLOCKSIZE              MEMBERS ARC STATUS
-------------------- -------------------- -------------------- -------------------- -------------------- -------------------- --- ----------------
                   1                    1                   17                 4000                  512                    1 YES INACTIVE
                   2                    1                   18                 4000                  512                    1 YES INACTIVE
                   3                    1                   19                 4000                  512                    1 NO  CURRENT
                   4                    1                   16                 4000                  512                    1 YES INACTIVE
                   5                    2                   17                 4000                  512                    1 YES INACTIVE
                   6                    2                   18                 4000                  512                    1 NO  CURRENT
                   7                    2                   15                 4000                  512                    1 YES INACTIVE
                   8                    2                   16                 4000                  512                    1 YES INACTIVE

8 rows selected.

## Redo Log Members

              GROUP#              THREAD# STATUS           TYPE    IS_ MEMBER
-------------------- -------------------- ---------------- ------- --- ------------------------------------------------------------------------------------------------------------------------------------------------------
                   1                    1 INACTIVE         ONLINE  NO  @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ONLINELOG/group_1.OMF.79DBCD20
                   2                    1 INACTIVE         ONLINE  NO  @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ONLINELOG/group_2.OMF.306D564A
                   3                    1 CURRENT          ONLINE  NO  @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ONLINELOG/group_3.OMF.4E70B52B
                   4                    1 INACTIVE         ONLINE  NO  @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ONLINELOG/group_4.OMF.63AA4D7B
                   5                    2 INACTIVE         ONLINE  NO  @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ONLINELOG/group_5.OMF.2E494504
                   6                    2 CURRENT          ONLINE  NO  @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ONLINELOG/group_6.OMF.168611B0
                   7                    2 INACTIVE         ONLINE  NO  @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ONLINELOG/group_7.OMF.1AC8EC21
                   8                    2 INACTIVE         ONLINE  NO  @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ONLINELOG/group_8.OMF.4D619824

8 rows selected.

## Database Size Summary

COMPONENT             FILE_COUNT              SIZE_GB
----------- -------------------- --------------------
DATAFILES                     17                13.48
TEMPFILES                      3                22.98
ONLINE REDO                    8                31.25

3 rows selected.

## SYSTEM And UNDO Datafiles

               FILE# TABLESPACE_NAME                TABLES              SIZE_MB STATUS  ENABLED    FILE_NAME
-------------------- ------------------------------ ------ -------------------- ------- ---------- ------------------------------------------------------------------------------------------------------------------------------------------------------
                   1 SYSTEM                         SYSTEM                 2000 SYSTEM  READ WRITE @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/SYSTEM.OMF.70DAA345
                   5 UNDOTBS1                       UNDO                   2000 ONLINE  READ WRITE @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/UNDOTBS1.OMF.5CF22136
                   8 UNDOTBS2                       UNDO                   2000 ONLINE  READ WRITE @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/UNDOTBS2.OMF.55ECD93B
                   2 SYSTEM                         SYSTEM                  600 SYSTEM  READ WRITE @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/5096C84B7BB5210CE0636C0DF40A1151/DATAFILE/SYSTEM.OMF.3BED3E82
                   6 UNDOTBS1                       UNDO                    600 ONLINE  READ WRITE @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/5096C84B7BB5210CE0636C0DF40A1151/DATAFILE/UNDOTBS1.OMF.1F3606C1
                   9 SYSTEM                         SYSTEM                  600 SYSTEM  READ WRITE @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/SYSTEM.OMF.49D473E6
                  11 UNDOTBS1                       UNDO                    600 ONLINE  READ WRITE @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/UNDOTBS1.OMF.79BB15E3
                  12 UNDO_4                         UNDO                  95.38 ONLINE  READ WRITE @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/UNDO_4.OMF.7FD1842F

8 rows selected.

## Temporary Files

               FILE# TABLESPACE_NAME                             SIZE_MB STATUS  ENABLED    FILE_NAME
-------------------- ------------------------------ -------------------- ------- ---------- ------------------------------------------------------------------------------------------------------------------------------------------------------
                   1 TEMP                                          17408 ONLINE  READ WRITE @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/TEMPFILE/TEMP.OMF.6CE4F0B7
                   2 TEMP                                           5096 ONLINE  READ WRITE @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/5096C84B7BB5210CE0636C0DF40A1151/DATAFILE/temp012026-06-08_04-20-55-817-AM.dbf
                   4 TEMP                                           1024 ONLINE  READ WRITE @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/TEMPFILE/TEMP.OMF.7E47A0BB

3 rows selected.

## FRA Destination And Usage

NAME                                     SPACE_LIMIT_GB        SPACE_USED_GB SPACE_RECLAIMABLE_GB      NUMBER_OF_FILES
---------------------------------- -------------------- -------------------- -------------------- --------------------
@rJOnB8bM(RECO_HC_HIGHREDUNDANCY)                   240                16.56                   .4                   41

1 row selected.

## FRA Usage By File Type

FILE_TYPE                 PERCENT_SPACE_USED PERCENT_SPACE_RECLAIMABLE      NUMBER_OF_FILES
----------------------- -------------------- ------------------------- --------------------
ARCHIVED LOG                             .17                       .17                   34
AUXILIARY DATAFILE COPY                    0                         0                    0
BACKUP PIECE                             .14                         0                    2
CONTROL FILE                             .07                         0                    1
FLASHBACK LOG                           6.51                         0                    4
FOREIGN ARCHIVED LOG                       0                         0                    0
IMAGE COPY                                 0                         0                    0
REDO LOG                                   0                         0                    0

8 rows selected.

## RMAN Configuration

NAME                               VALUE
---------------------------------- ------------------------------------------------------------------------------------------------------------------------
BACKUP OPTIMIZATION                OFF
CHANNEL                            DEVICE TYPE 'SBT_TAPE' FORMAT   '%d_%I_%U_%T_%t' PARMS  "SBT_LIBRARY=/u02/app/oracle/product/23.0.0.0/dbhome_1/lib/libra
                                   .so, ENV=(RA_WALLET='location=file:/var/opt/oracle/dbaas_acfs/crashdb/wallet_root/server_seps credential_alias=DBRS',RA_
                                   FORMAT=TRUE)"

COMPRESSION ALGORITHM              'low' AS OF RELEASE 'DEFAULT' OPTIMIZE FOR LOAD TRUE
CONTROLFILE AUTOBACKUP             ON
DB_UNIQUE_NAME                     'crashrdb' CONNECT IDENTIFIER  'crashrdb'
DB_UNIQUE_NAME                     'crashdr' CONNECT IDENTIFIER  'crashdr'
DEFAULT DEVICE TYPE TO             'SBT_TAPE'
DEVICE TYPE                        'SBT_TAPE' PARALLELISM 4 BACKUP TYPE TO COMPRESSED BACKUPSET
ENCRYPTION ALGORITHM               'AES256'
ENCRYPTION FOR DATABASE            ON
RETENTION POLICY                   TO NONE
SNAPSHOT CONTROLFILE NAME          TO '@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/CONTROLFILE/snapcf_crashdb.f'

12 rows selected.

## Recent RMAN Backup Jobs

         SESSION_KEY INPUT_TYPE    STATUS                  START_TIME           END_TIME                  ELAPSED_SECONDS OUTPUT_DEVICE_TYP
-------------------- ------------- ----------------------- -------------------- -------------------- -------------------- -----------------
INPUT_BYTES_DISPLAY
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
OUTPUT_BYTES_DISPLAY
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                  61 DB FULL       COMPLETED               2026-06-08 08:42:30  2026-06-08 08:43:21                    51 SBT_TAPE
    4.73G
  925.25M

                  56 ARCHIVELOG    COMPLETED               2026-06-08 08:33:12  2026-06-08 08:33:30                    18 SBT_TAPE
  175.43M
    9.50M

                  51 ARCHIVELOG    COMPLETED               2026-06-08 08:03:12  2026-06-08 08:03:30                    18 SBT_TAPE
  206.90M
   41.00M

                  46 ARCHIVELOG    COMPLETED               2026-06-08 07:33:19  2026-06-08 07:33:35                    16 SBT_TAPE
  178.50M
   12.75M

                  41 ARCHIVELOG    COMPLETED               2026-06-08 07:03:11  2026-06-08 07:03:29                    18 SBT_TAPE
  231.15M
   65.25M

                  34 ARCHIVELOG    COMPLETED               2026-06-08 06:33:12  2026-06-08 06:33:30                    18 SBT_TAPE
  174.85M
    8.75M

                  29 ARCHIVELOG    COMPLETED               2026-06-08 06:03:13  2026-06-08 06:03:32                    19 SBT_TAPE
  203.10M
   37.50M

                  23 ARCHIVELOG    COMPLETED               2026-06-08 05:33:15  2026-06-08 05:33:31                    16 SBT_TAPE
  173.48M
    7.50M

                  18 DB INCR       COMPLETED               2026-06-08 05:08:01  2026-06-08 05:08:31                    30 SBT_TAPE
    4.48G
    3.59G

                  11 ARCHIVELOG    COMPLETED               2026-06-08 05:03:11  2026-06-08 05:03:30                    19 SBT_TAPE
  397.71M
  232.00M


10 rows selected.

## Backup Set Summary

    BACKUP_SET_RECID            SET_STAMP            SET_COUNT B    INCREMENTAL_LEVEL CON          PIECE_COUNT START_TIME           COMPLETION_TIME
-------------------- -------------------- -------------------- - -------------------- --- -------------------- -------------------- --------------------
                  67           1235378594                   82 D                      YES                    1 2026-06-08 08:43:14  2026-06-08 08:43:18
                  66           1235378592                   81 D                      NO                     1 2026-06-08 08:43:12  2026-06-08 08:43:12
                  65           1235378586                   80 D                      YES                    1 2026-06-08 08:43:06  2026-06-08 08:43:11
                  62           1235378582                   79 L                      NO                     1 2026-06-08 08:43:02  2026-06-08 08:43:03
                  64           1235378582                   76 L                      NO                     1 2026-06-08 08:43:02  2026-06-08 08:43:03
                  63           1235378582                   77 L                      NO                     1 2026-06-08 08:43:02  2026-06-08 08:43:03
                  61           1235378582                   78 L                      NO                     1 2026-06-08 08:43:02  2026-06-08 08:43:02
                  60           1235378573                   75 D                      YES                    1 2026-06-08 08:42:53  2026-06-08 08:42:56
                  59           1235378566                   74 D                      NO                     1 2026-06-08 08:42:46  2026-06-08 08:42:52
                  58           1235378566                   72 D                      NO                     1 2026-06-08 08:42:46  2026-06-08 08:42:51
                  57           1235378566                   73 D                      NO                     1 2026-06-08 08:42:46  2026-06-08 08:42:50
                  56           1235378551                   67 D                      NO                     1 2026-06-08 08:42:31  2026-06-08 08:42:46
                  53           1235378555                   70 D                      NO                     1 2026-06-08 08:42:35  2026-06-08 08:42:44
                  55           1235378559                   71 D                      NO                     1 2026-06-08 08:42:39  2026-06-08 08:42:44
                  54           1235378550                   66 D                      NO                     1 2026-06-08 08:42:30  2026-06-08 08:42:44
                  52           1235378554                   69 D                      NO                     1 2026-06-08 08:42:34  2026-06-08 08:42:36
                  51           1235378554                   68 D                      NO                     1 2026-06-08 08:42:34  2026-06-08 08:42:34
                  50           1235378550                   64 D                      NO                     1 2026-06-08 08:42:30  2026-06-08 08:42:33
                  49           1235378550                   65 D                      NO                     1 2026-06-08 08:42:30  2026-06-08 08:42:31
                  48           1235378001                   63 D                      YES                    1 2026-06-08 08:33:21  2026-06-08 08:33:24
                  46           1235377997                   61 L                      NO                     1 2026-06-08 08:33:17  2026-06-08 08:33:18
                  47           1235377997                   62 L                      NO                     1 2026-06-08 08:33:17  2026-06-08 08:33:18
                  45           1235376202                   60 D                      YES                    1 2026-06-08 08:03:22  2026-06-08 08:03:25
                  43           1235376197                   59 L                      NO                     1 2026-06-08 08:03:17  2026-06-08 08:03:18
                  44           1235376197                   58 L                      NO                     1 2026-06-08 08:03:17  2026-06-08 08:03:18
                  42           1235374406                   57 D                      YES                    1 2026-06-08 07:33:26  2026-06-08 07:33:30
                  40           1235374402                   55 L                      NO                     1 2026-06-08 07:33:22  2026-06-08 07:33:23
                  41           1235374402                   56 L                      NO                     1 2026-06-08 07:33:22  2026-06-08 07:33:23
                  39           1235372601                   54 D                      YES                    1 2026-06-08 07:03:21  2026-06-08 07:03:24
                  38           1235372596                   53 L                      NO                     1 2026-06-08 07:03:16  2026-06-08 07:03:18
                  37           1235372596                   52 L                      NO                     1 2026-06-08 07:03:16  2026-06-08 07:03:17
                  36           1235370801                   51 D                      YES                    1 2026-06-08 06:33:21  2026-06-08 06:33:25
                  34           1235370796                   50 L                      NO                     1 2026-06-08 06:33:16  2026-06-08 06:33:17
                  35           1235370796                   49 L                      NO                     1 2026-06-08 06:33:16  2026-06-08 06:33:17
                  33           1235369003                   48 D                      YES                    1 2026-06-08 06:03:23  2026-06-08 06:03:26
                  30           1235368998                   46 L                      NO                     1 2026-06-08 06:03:18  2026-06-08 06:03:20
                  32           1235368998                   44 L                      NO                     1 2026-06-08 06:03:18  2026-06-08 06:03:20
                  31           1235368998                   45 L                      NO                     1 2026-06-08 06:03:18  2026-06-08 06:03:20
                  29           1235368998                   47 L                      NO                     1 2026-06-08 06:03:18  2026-06-08 06:03:19
                  28           1235368390                   43 D                      YES                    1 2026-06-08 05:53:10  2026-06-08 05:53:13
                  27           1235367202                   27 D                      YES                    1 2026-06-08 05:33:22  2026-06-08 05:33:25
                  25           1235367199                   25 L                      NO                     1 2026-06-08 05:33:19  2026-06-08 05:33:19
                  26           1235367199                   26 L                      NO                     1 2026-06-08 05:33:19  2026-06-08 05:33:19
                  24           1235365713                   24 D                      YES                    1 2026-06-08 05:08:33  2026-06-08 05:08:38
                  22           1235365710                   22 L                      NO                     1 2026-06-08 05:08:30  2026-06-08 05:08:30
                  23           1235365710                   23 L                      NO                     1 2026-06-08 05:08:30  2026-06-08 05:08:30
                  21           1235365704                   21 I                    0 NO                     1 2026-06-08 05:08:24  2026-06-08 05:08:26
                  20           1235365699                   17 I                    0 NO                     1 2026-06-08 05:08:19  2026-06-08 05:08:24
                  18           1235365699                   19 I                    0 NO                     1 2026-06-08 05:08:19  2026-06-08 05:08:23
                  19           1235365700                   20 I                    0 NO                     1 2026-06-08 05:08:20  2026-06-08 05:08:23
                  17           1235365695                   16 I                    0 NO                     1 2026-06-08 05:08:15  2026-06-08 05:08:21
                  16           1235365699                   18 I                    0 NO                     1 2026-06-08 05:08:19  2026-06-08 05:08:19
                  14           1235365687                    9 I                    0 NO                     1 2026-06-08 05:08:07  2026-06-08 05:08:18
                  15           1235365695                   15 I                    0 NO                     1 2026-06-08 05:08:15  2026-06-08 05:08:18
                  13           1235365687                   12 I                    0 NO                     1 2026-06-08 05:08:07  2026-06-08 05:08:15
                  11           1235365687                   11 I                    0 NO                     1 2026-06-08 05:08:07  2026-06-08 05:08:13
                  12           1235365692                   14 I                    0 NO                     1 2026-06-08 05:08:12  2026-06-08 05:08:13
                  10           1235365688                   13 I                    0 NO                     1 2026-06-08 05:08:08  2026-06-08 05:08:10
                   9           1235365687                   10 I                    0 NO                     1 2026-06-08 05:08:07  2026-06-08 05:08:07
                   7           1235365683                    8 L                      NO                     1 2026-06-08 05:08:03  2026-06-08 05:08:03

60 rows selected.

## Observed Backup Methodology From RMAN History

INPUT_TYPE    STATUS                             JOB_COUNT FIRST_OBSERVED      LAST_OBSERVED
------------- ----------------------- -------------------- ------------------- -------------------
ARCHIVELOG    COMPLETED                                  8 2026-06-08 05:03:11 2026-06-08 08:33:12
DB FULL       COMPLETED                                  1 2026-06-08 08:42:30 2026-06-08 08:42:30
DB INCR       COMPLETED                                  1 2026-06-08 05:08:01 2026-06-08 05:08:01

3 rows selected.

## Datafile Backup Coverage

               FILE# FILE_NAME                                                                                                                                              LAST_BACKUP_TIME    BACKUP_STATUS
-------------------- ------------------------------------------------------------------------------------------------------------------------------------------------------ ------------------- ----------------------------------
                   1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/SYSTEM.OMF.70DAA345                                                             2026-06-08 08:42:46 BACKUP METADATA FOUND
                   2 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/5096C84B7BB5210CE0636C0DF40A1151/DATAFILE/SYSTEM.OMF.3BED3E82                            2026-06-08 08:42:51 BACKUP METADATA FOUND
                   3 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/SYSAUX.OMF.45447F4E                                                             2026-06-08 08:42:44 BACKUP METADATA FOUND
                   4 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/5096C84B7BB5210CE0636C0DF40A1151/DATAFILE/SYSAUX.OMF.7122AC18                            2026-06-08 08:42:52 BACKUP METADATA FOUND
                   5 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/UNDOTBS1.OMF.5CF22136                                                           2026-06-08 08:42:33 BACKUP METADATA FOUND
                   6 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/5096C84B7BB5210CE0636C0DF40A1151/DATAFILE/UNDOTBS1.OMF.1F3606C1                          2026-06-08 08:42:50 BACKUP METADATA FOUND
                   7 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/USERS.OMF.6CA6D570                                                              2026-06-08 08:42:33 BACKUP METADATA FOUND
                   8 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/UNDOTBS2.OMF.55ECD93B                                                           2026-06-08 08:42:31 BACKUP METADATA FOUND
                   9 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/SYSTEM.OMF.49D473E6                            2026-06-08 08:42:44 BACKUP METADATA FOUND
                  10 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/SYSAUX.OMF.5B8C6142                            2026-06-08 08:42:44 BACKUP METADATA FOUND
                  11 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/UNDOTBS1.OMF.79BB15E3                          2026-06-08 08:42:36 BACKUP METADATA FOUND
                  12 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/UNDO_4.OMF.7FD1842F                            2026-06-08 08:42:40 BACKUP METADATA FOUND
                  13 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/USERS.OMF.7A32E8B8                             2026-06-08 08:42:34 BACKUP METADATA FOUND
                  14 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/CRASHSIM_ROOT_RO_TBS.OMF.28790F18                                               2026-06-08 08:42:32 BACKUP METADATA FOUND
                  15 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/CRASHSIM_ROOT_INDEX_TBS.OMF.15484A11                                            2026-06-08 08:42:32 BACKUP METADATA FOUND
                  16 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/CRASHSIM_RO_TBS.OMF.3653F3F1                   2026-06-08 08:42:36 BACKUP METADATA FOUND
                  17 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/CRASHSIM_INDEX_TBS.OMF.4F7C5839                2026-06-08 08:42:35 BACKUP METADATA FOUND

17 rows selected.

## Backup Piece Status

S DEVICE_TYPE                PIECE_COUNT LATEST_COMPLETION
- ----------------- -------------------- -------------------
A DISK                                 2 2026-06-08 05:53:13
A SBT_TAPE                            65 2026-06-08 08:43:19

2 rows selected.

## Recoverability Indicators

               FILE#   CHECKPOINT_CHANGE# CHECKPOINT_TIME     UNRECOVERABLE_CHANGE# UNRECOVERABLE_TIME  NAME
-------------------- -------------------- ------------------- --------------------- ------------------- ----------------------------------
                   1              1330959 2026-06-08 08:44:46                     0                     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F
                                                                                                        3BFFC46A6348A21A9F/CRASHRDB/DATAFI
                                                                                                        LE/SYSTEM.OMF.70DAA345

                   2              1185923 2026-06-08 04:30:13                     0                     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F
                                                                                                        3BFFC46A6348A21A9F/CRASHRDB/5096C8
                                                                                                        4B7BB5210CE0636C0DF40A1151/DATAFIL
                                                                                                        E/SYSTEM.OMF.3BED3E82

                   3              1330959 2026-06-08 08:44:46                     0                     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F
                                                                                                        3BFFC46A6348A21A9F/CRASHRDB/DATAFI
                                                                                                        LE/SYSAUX.OMF.45447F4E

                   4              1185923 2026-06-08 04:30:13                     0                     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F
                                                                                                        3BFFC46A6348A21A9F/CRASHRDB/5096C8
                                                                                                        4B7BB5210CE0636C0DF40A1151/DATAFIL
                                                                                                        E/SYSAUX.OMF.7122AC18

                   5              1330959 2026-06-08 08:44:46                     0                     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F
                                                                                                        3BFFC46A6348A21A9F/CRASHRDB/DATAFI
                                                                                                        LE/UNDOTBS1.OMF.5CF22136

                   6              1185923 2026-06-08 04:30:13                     0                     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F
                                                                                                        3BFFC46A6348A21A9F/CRASHRDB/5096C8
                                                                                                        4B7BB5210CE0636C0DF40A1151/DATAFIL
                                                                                                        E/UNDOTBS1.OMF.1F3606C1

                   7              1330959 2026-06-08 08:44:46                     0                     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F
                                                                                                        3BFFC46A6348A21A9F/CRASHRDB/DATAFI
                                                                                                        LE/USERS.OMF.6CA6D570

                   8              1330959 2026-06-08 08:44:46                     0                     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F
                                                                                                        3BFFC46A6348A21A9F/CRASHRDB/DATAFI
                                                                                                        LE/UNDOTBS2.OMF.55ECD93B

                   9              1331120 2026-06-08 08:45:36                     0                     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F
                                                                                                        3BFFC46A6348A21A9F/CRASHRDB/53B77A
                                                                                                        B496E44BD8E0633400020A4FF3/DATAFIL
                                                                                                        E/SYSTEM.OMF.49D473E6

                  10              1331120 2026-06-08 08:45:36                     0                     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F
                                                                                                        3BFFC46A6348A21A9F/CRASHRDB/53B77A
                                                                                                        B496E44BD8E0633400020A4FF3/DATAFIL
                                                                                                        E/SYSAUX.OMF.5B8C6142

                  11              1331120 2026-06-08 08:45:36                     0                     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F
                                                                                                        3BFFC46A6348A21A9F/CRASHRDB/53B77A
                                                                                                        B496E44BD8E0633400020A4FF3/DATAFIL
                                                                                                        E/UNDOTBS1.OMF.79BB15E3

                  12              1331120 2026-06-08 08:45:36                     0                     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F
                                                                                                        3BFFC46A6348A21A9F/CRASHRDB/53B77A
                                                                                                        B496E44BD8E0633400020A4FF3/DATAFIL
                                                                                                        E/UNDO_4.OMF.7FD1842F

                  13              1331120 2026-06-08 08:45:36                     0                     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F
                                                                                                        3BFFC46A6348A21A9F/CRASHRDB/53B77A
                                                                                                        B496E44BD8E0633400020A4FF3/DATAFIL
                                                                                                        E/USERS.OMF.7A32E8B8

                  14              1328979 2026-06-08 08:41:17                     0                     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F
                                                                                                        3BFFC46A6348A21A9F/CRASHRDB/DATAFI
                                                                                                        LE/CRASHSIM_ROOT_RO_TBS.OMF.28790F
                                                                                                        18

                  15              1330959 2026-06-08 08:44:46                     0                     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F
                                                                                                        3BFFC46A6348A21A9F/CRASHRDB/DATAFI
                                                                                                        LE/CRASHSIM_ROOT_INDEX_TBS.OMF.154
                                                                                                        84A11

                  16              1329351 2026-06-08 08:41:19                     0                     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F
                                                                                                        3BFFC46A6348A21A9F/CRASHRDB/53B77A
                                                                                                        B496E44BD8E0633400020A4FF3/DATAFIL
                                                                                                        E/CRASHSIM_RO_TBS.OMF.3653F3F1

                  17              1331120 2026-06-08 08:45:36                     0                     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F
                                                                                                        3BFFC46A6348A21A9F/CRASHRDB/53B77A
                                                                                                        B496E44BD8E0633400020A4FF3/DATAFIL
                                                                                                        E/CRASHSIM_INDEX_TBS.OMF.4F7C5839


17 rows selected.

## Files Requiring Media Recovery

no rows selected

## Database Block Corruption

no rows selected

## Copy Corruption

no rows selected

## Backup Corruption

no rows selected

## Restore Points

no rows selected

## Data Guard Role And FSFO Columns

DATABASE_ROLE    PROTECTION_MODE      PROTECTION_LEVEL     SWITCHOVER_STATUS    FS_FAILOVER_STATUS     FS_FAILOVER_CURRENT_TARGET     FS_FAILOVER_THRESHOLD FS_FAIL
---------------- -------------------- -------------------- -------------------- ---------------------- ------------------------------ --------------------- -------
PRIMARY          MAXIMUM PERFORMANCE  MAXIMUM PERFORMANCE  TO STANDBY           DISABLED                                                                  0

1 row selected.

## Data Guard Destinations

             DEST_ID STATUS    TARGET           DESTINATION                                                                                                              DB_UNIQUE_NAME                 VALID_NOW
-------------------- --------- ---------------- ------------------------------------------------------------------------------------------------------------------------ ------------------------------ ----------------
ERROR
------------------------------------------------------------------------------------------------------------------------
                   1 VALID     PRIMARY          USE_DB_RECOVERY_FILE_DEST                                                                                                crashrdb                       YES


                   2 VALID     STANDBY          crashdr                                                                                                                  crashdr                        YES


                  10 ALTERNATE PRIMARY          @rJOnB8bM                                                                                                                crashrdb                       UNKNOWN



3 rows selected.

## Archive Gaps

no rows selected

## Data Guard Stats

no rows selected

## TDE Wallet Status

WRL_TYPE
--------------------
WRL_PARAMETER
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
STATUS                         WALLET_TYPE          WALLET_OR KEYSTORE FULLY_BAC               CON_ID
------------------------------ -------------------- --------- -------- --------- --------------------
FILE
/var/opt/oracle/dbaas_acfs/crashdb/wallet_root/tde/
OPEN                           AUTOLOGIN            SINGLE    NONE     NO                           1

FILE

OPEN                           AUTOLOGIN            SINGLE    UNITED   NO                           2

FILE

OPEN                           AUTOLOGIN            SINGLE    UNITED   NO                           3


3 rows selected.

## Encrypted Tablespaces

TABLESPACE_NAME                ENC
------------------------------ ---
CRASHSIM_ROOT_INDEX_TBS        YES
CRASHSIM_ROOT_RO_TBS           YES
SYSAUX                         YES
SYSTEM                         YES
TEMP                           YES
UNDOTBS1                       YES
UNDOTBS2                       YES
USERS                          YES

8 rows selected.

## Encrypted Columns

no rows selected

## PDB State And Size

PDB_NAME                                     CON_ID OPEN_MODE  RES        TOTAL_SIZE_GB OPEN_TIME
------------------------------ -------------------- ---------- --- -------------------- -------------------
PDB$SEED                                          2 READ ONLY  NO                  6.73 2026-06-08 04:38:25
CRASHPDB                                          3 READ WRITE NO                  3.88 2026-06-08 04:38:29

2 rows selected.

## Datafile Count And Size By Container

PDB_NAME                                     CON_ID       DATAFILE_COUNT          DATAFILE_GB          TEMPFILE_GB
------------------------------ -------------------- -------------------- -------------------- --------------------
CDB$ROOT                                          1                    7                 8.84                   17
PDB$SEED                                          2                    3                 1.76                 4.98
CRASHPDB                                          3                    7                 2.88                    1

3 rows selected.

## Tablespaces By Container

PDB_NAME                       TABLESPACE_NAME                CONTENTS              STATUS    BIG LOGGING   EXTENT_MAN ALLOCATIO SEGMEN              DATA_MB              TEMP_MB
------------------------------ ------------------------------ --------------------- --------- --- --------- ---------- --------- ------ -------------------- --------------------
CDB$ROOT                       CRASHSIM_ROOT_INDEX_TBS        PERMANENT             ONLINE    YES LOGGING   LOCAL      SYSTEM    AUTO                     16                    0
CDB$ROOT                       CRASHSIM_ROOT_RO_TBS           PERMANENT             READ ONLY YES LOGGING   LOCAL      SYSTEM    AUTO                     16                    0
CDB$ROOT                       SYSAUX                         PERMANENT             ONLINE    YES LOGGING   LOCAL      SYSTEM    AUTO                   2000                    0
CDB$ROOT                       SYSTEM                         PERMANENT             ONLINE    YES LOGGING   LOCAL      SYSTEM    MANUAL                 2000                    0
CDB$ROOT                       TEMP                           TEMPORARY             ONLINE    YES NOLOGGING LOCAL      UNIFORM   MANUAL                    0                17408
CDB$ROOT                       UNDOTBS1                       UNDO                  ONLINE    YES LOGGING   LOCAL      SYSTEM    MANUAL                 2000                    0
CDB$ROOT                       UNDOTBS2                       UNDO                  ONLINE    YES LOGGING   LOCAL      SYSTEM    MANUAL                 2000                    0
CDB$ROOT                       USERS                          PERMANENT             ONLINE    YES LOGGING   LOCAL      SYSTEM    AUTO                   1024                    0
CRASHPDB                       CRASHSIM_INDEX_TBS             PERMANENT             ONLINE    YES LOGGING   LOCAL      SYSTEM    AUTO                     16                    0
CRASHPDB                       CRASHSIM_RO_TBS                PERMANENT             READ ONLY YES LOGGING   LOCAL      SYSTEM    AUTO                     16                    0
CRASHPDB                       SYSAUX                         PERMANENT             ONLINE    YES LOGGING   LOCAL      SYSTEM    AUTO                    600                    0
CRASHPDB                       SYSTEM                         PERMANENT             ONLINE    YES LOGGING   LOCAL      SYSTEM    MANUAL                  600                    0
CRASHPDB                       TEMP                           TEMPORARY             ONLINE    YES NOLOGGING LOCAL      UNIFORM   MANUAL                    0                 1024
CRASHPDB                       UNDOTBS1                       UNDO                  ONLINE    YES LOGGING   LOCAL      SYSTEM    MANUAL                  600                    0
CRASHPDB                       UNDO_4                         UNDO                  ONLINE    YES LOGGING   LOCAL      SYSTEM    MANUAL                95.38                    0
CRASHPDB                       USERS                          PERMANENT             ONLINE    YES LOGGING   LOCAL      SYSTEM    AUTO                   1024                    0

16 rows selected.

## Datafiles By Container

PDB_NAME                                    FILE_ID TABLESPACE_NAME                             SIZE_MB STATUS    ONLINE_ AUT
------------------------------ -------------------- ------------------------------ -------------------- --------- ------- ---
FILE_NAME
------------------------------------------------------------------------------------------------------------------------------------------------------
CDB$ROOT                                          1 SYSTEM                                         2000 AVAILABLE SYSTEM  YES
@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/SYSTEM.OMF.70DAA345

CDB$ROOT                                          3 SYSAUX                                         2000 AVAILABLE ONLINE  YES
@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/SYSAUX.OMF.45447F4E

CDB$ROOT                                          5 UNDOTBS1                                       2000 AVAILABLE ONLINE  YES
@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/UNDOTBS1.OMF.5CF22136

CDB$ROOT                                          7 USERS                                          1024 AVAILABLE ONLINE  YES
@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/USERS.OMF.6CA6D570

CDB$ROOT                                          8 UNDOTBS2                                       2000 AVAILABLE ONLINE  YES
@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/UNDOTBS2.OMF.55ECD93B

CDB$ROOT                                         14 CRASHSIM_ROOT_RO_TBS                             16 AVAILABLE ONLINE  YES
@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/CRASHSIM_ROOT_RO_TBS.OMF.28790F18

CDB$ROOT                                         15 CRASHSIM_ROOT_INDEX_TBS                          16 AVAILABLE ONLINE  YES
@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/CRASHSIM_ROOT_INDEX_TBS.OMF.15484A11

CRASHPDB                                          9 SYSTEM                                          600 AVAILABLE SYSTEM  YES
@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/SYSTEM.OMF.49D473E6

CRASHPDB                                         10 SYSAUX                                          600 AVAILABLE ONLINE  YES
@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/SYSAUX.OMF.5B8C6142

CRASHPDB                                         11 UNDOTBS1                                        600 AVAILABLE ONLINE  YES
@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/UNDOTBS1.OMF.79BB15E3

CRASHPDB                                         12 UNDO_4                                        95.38 AVAILABLE ONLINE  YES
@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/UNDO_4.OMF.7FD1842F

CRASHPDB                                         13 USERS                                          1024 AVAILABLE ONLINE  YES
@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/USERS.OMF.7A32E8B8

CRASHPDB                                         16 CRASHSIM_RO_TBS                                  16 AVAILABLE ONLINE  YES
@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/CRASHSIM_RO_TBS.OMF.3653F3F1

CRASHPDB                                         17 CRASHSIM_INDEX_TBS                               16 AVAILABLE ONLINE  YES
@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/CRASHSIM_INDEX_TBS.OMF.4F7C5839


14 rows selected.

## Tempfiles By Container

PDB_NAME                                    FILE_ID TABLESPACE_NAME                             SIZE_MB STATUS  AUT
------------------------------ -------------------- ------------------------------ -------------------- ------- ---
FILE_NAME
------------------------------------------------------------------------------------------------------------------------------------------------------
CDB$ROOT                                          1 TEMP                                          17408 ONLINE  YES
@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/TEMPFILE/TEMP.OMF.6CE4F0B7

CRASHPDB                                          4 TEMP                                           1024 ONLINE  YES
@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/TEMPFILE/TEMP.OMF.7E47A0BB


2 rows selected.

## Encrypted Tablespaces By Container

PDB_NAME                       TABLESPACE_NAME                ENC
------------------------------ ------------------------------ ---
CDB$ROOT                       CRASHSIM_ROOT_INDEX_TBS        YES
CDB$ROOT                       CRASHSIM_ROOT_RO_TBS           YES
CDB$ROOT                       SYSAUX                         YES
CDB$ROOT                       SYSTEM                         YES
CDB$ROOT                       TEMP                           YES
CDB$ROOT                       UNDOTBS1                       YES
CDB$ROOT                       UNDOTBS2                       YES
CDB$ROOT                       USERS                          YES
CRASHPDB                       CRASHSIM_INDEX_TBS             YES
CRASHPDB                       CRASHSIM_RO_TBS                YES
CRASHPDB                       SYSAUX                         YES
CRASHPDB                       SYSTEM                         YES
CRASHPDB                       TEMP                           YES
CRASHPDB                       UNDOTBS1                       YES
CRASHPDB                       UNDO_4                         YES
CRASHPDB                       USERS                          YES

16 rows selected.

```

## RMAN Catalog And Restore Preview

The report invokes RMAN with `target /` only. If the output says it is using the target control file, no recovery catalog was used by this report session. This does not prove that an external scheduler never uses a catalog; it reports what is detectable from the target host/session.


## RMAN SHOW ALL

Command: /u02/app/oracle/product/23.0.0.0/dbhome_1/bin/rman target / cmdfile=/tmp/crashsimulator/crashsimulator_logs/crashsim_config_report_20260608_084856_show_all.rman

```text

Recovery Manager: Release 23.26.2.0.0 - Production on Mon Jun 8 08:48:59 2026
Version 23.26.2.0.0

Copyright (c) 1982, 2026, Oracle and/or its affiliates.  All rights reserved.

connected to target database: CRASHDB (DBID=1275206961)

RMAN> show all;
2> exit
using target database control file instead of recovery catalog
RMAN configuration parameters for database with db_unique_name CRASHRDB are:
CONFIGURE RETENTION POLICY TO NONE;
CONFIGURE BACKUP OPTIMIZATION OFF;
CONFIGURE DEFAULT DEVICE TYPE TO 'SBT_TAPE';
CONFIGURE CONTROLFILE AUTOBACKUP ON;
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE SBT_TAPE TO '%F'; # default
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '%F'; # default
CONFIGURE DEVICE TYPE 'SBT_TAPE' PARALLELISM 4 BACKUP TYPE TO COMPRESSED BACKUPSET;
CONFIGURE DEVICE TYPE DISK PARALLELISM 1 BACKUP TYPE TO BACKUPSET; # default
CONFIGURE DATAFILE BACKUP COPIES FOR DEVICE TYPE SBT_TAPE TO 1; # default
CONFIGURE DATAFILE BACKUP COPIES FOR DEVICE TYPE DISK TO 1; # default
CONFIGURE ARCHIVELOG BACKUP COPIES FOR DEVICE TYPE SBT_TAPE TO 1; # default
CONFIGURE ARCHIVELOG BACKUP COPIES FOR DEVICE TYPE DISK TO 1; # default
CONFIGURE CHANNEL DEVICE TYPE 'SBT_TAPE' FORMAT   '%d_%I_%U_%T_%t' PARMS  "SBT_LIBRARY=/u02/app/oracle/product/23.0.0.0/dbhome_1/lib/libra.so, ENV=(RA_WALLET='location=file:/var/opt/oracle/dbaas_acfs/crashdb/wallet_root/server_seps credential_alias=DBRS',RA_FORMAT=TRUE)";
CONFIGURE MAXSETSIZE TO UNLIMITED; # default
CONFIGURE ENCRYPTION FOR DATABASE ON;
CONFIGURE ENCRYPTION ALGORITHM 'AES256';
CONFIGURE COMPRESSION ALGORITHM 'low' AS OF RELEASE 'DEFAULT' OPTIMIZE FOR LOAD TRUE;
CONFIGURE DB_UNIQUE_NAME 'crashrdb' CONNECT IDENTIFIER  'crashrdb';
CONFIGURE DB_UNIQUE_NAME 'crashdr' CONNECT IDENTIFIER  'crashdr';
CONFIGURE RMAN OUTPUT TO KEEP FOR 7 DAYS; # default
CONFIGURE ARCHIVELOG DELETION POLICY TO NONE; # default
CONFIGURE SNAPSHOT CONTROLFILE NAME TO '@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/CONTROLFILE/snapcf_crashdb.f';

Recovery Manager complete.
```

## RMAN RESTORE DATABASE PREVIEW SUMMARY

Command: /u02/app/oracle/product/23.0.0.0/dbhome_1/bin/rman target / cmdfile=/tmp/crashsimulator/crashsimulator_logs/crashsim_config_report_20260608_084856_restore_preview.rman

```text

Recovery Manager: Release 23.26.2.0.0 - Production on Mon Jun 8 08:49:01 2026
Version 23.26.2.0.0

Copyright (c) 1982, 2026, Oracle and/or its affiliates.  All rights reserved.

connected to target database: CRASHDB (DBID=1275206961)

RMAN> restore database preview summary;
2> exit
Starting restore at 08-JUN-26
using target database control file instead of recovery catalog
allocated channel: ORA_SBT_TAPE_1
channel ORA_SBT_TAPE_1: SID=2352 instance=crashdb1 device type=SBT_TAPE
channel ORA_SBT_TAPE_1: RA Library (RANRTP7) SID 53BB1521A7ADEF69E0633400020A59A6
RMAN-06918: warning: allocated SBT channel to the Recovery Appliance in NOCATALOG mode
allocated channel: ORA_SBT_TAPE_2
channel ORA_SBT_TAPE_2: SID=2359 instance=crashdb1 device type=SBT_TAPE
channel ORA_SBT_TAPE_2: RA Library (RANRTP7) SID 53BB152AD1A3EF75E0633400020A63EB
RMAN-06918: warning: allocated SBT channel to the Recovery Appliance in NOCATALOG mode
allocated channel: ORA_SBT_TAPE_3
channel ORA_SBT_TAPE_3: SID=2437 instance=crashdb1 device type=SBT_TAPE
channel ORA_SBT_TAPE_3: RA Library (RANRTP7) SID 53BB153456CAEF89E0633400020AA703
RMAN-06918: warning: allocated SBT channel to the Recovery Appliance in NOCATALOG mode
allocated channel: ORA_SBT_TAPE_4
channel ORA_SBT_TAPE_4: SID=2436 instance=crashdb1 device type=SBT_TAPE
channel ORA_SBT_TAPE_4: RA Library (RANRTP7) SID 53BB153EA17DEFC4E0633400020AD161
RMAN-06918: warning: allocated SBT channel to the Recovery Appliance in NOCATALOG mode
allocated channel: ORA_DISK_1
channel ORA_DISK_1: SID=2402 instance=crashdb1 device type=DISK


List of Backups
===============
Key     TY LV S Device Type Completion Time #Pieces #Copies Compressed Tag
------- -- -- - ----------- --------------- ------- ------- ---------- ---
56      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
58      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
54      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
59      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
50      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
57      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
49      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
55      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
53      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
52      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
51      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
using channel ORA_SBT_TAPE_1
using channel ORA_SBT_TAPE_2
using channel ORA_SBT_TAPE_3
using channel ORA_SBT_TAPE_4
using channel ORA_DISK_1

List of Archived Log Copies for database with db_unique_name CRASHRDB
=====================================================================

Key     Thrd Seq     S Low Time 
------- ---- ------- - ---------
51      1    17      A 08-JUN-26
        Name: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ARCHIVELOG/2026_06_08/thread_1_seq_17.OMF.4607A176

52      1    18      A 08-JUN-26
        Name: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ARCHIVELOG/2026_06_08/thread_1_seq_18.OMF.737F99D0

50      2    16      A 08-JUN-26
        Name: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ARCHIVELOG/2026_06_08/thread_2_seq_16.OMF.4BEE5D3E

55      2    17      A 08-JUN-26
        Name: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ARCHIVELOG/2026_06_08/thread_2_seq_17.OMF.7BEC3328

recovery will be done up to SCN 1329970
Media recovery start SCN is 1329806
Recovery must be done beyond SCN 1329848 to clear datafile fuzziness
validation succeeded for backup piece
Finished restore at 08-JUN-26

Recovery Manager complete.
```

## Deep RMAN Validation

Skipped by default. Re-run with `--deep-validate` or set `CRASHSIM_REPORT_DEEP_VALIDATE=1` to run RMAN restore/database validation. Those checks are read-only but can be I/O intensive.

## Operating System And Oracle Environment

Command: env | sort with secret redaction

```text
 eval ${which_declare} ) | /usr/bin/which --tty-only --read-alias --read-functions --show-tilde --show-dot $@
BASH_FUNC_which%%=() {  ( alias;
CDPATH=.:/opt/oracle.ExaWatcher
CRASHSIM_GRID_HOME=/u01/app/23.0.0.0/gridhome_1
HISTCONTROL=ignoredups
HISTSIZE=1000
HOME=/home/oracle
HOSTNAME=crashrac1-xnvfw
LANG=C.UTF-8
LC_CTYPE=C.UTF-8
LESSOPEN=||/usr/bin/lesspipe.sh %s
LOGNAME=oracle
MAIL=/var/spool/mail/oracle
OLDPWD=/home/opc
ORACLE_BASE=/u02/app/oracle
ORACLE_HOME=/u02/app/oracle/product/23.0.0.0/dbhome_1
ORACLE_SID=crashdb1
PATH=/home/oracle/.local/bin:/home/oracle/bin:/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/sbin
PWD=/tmp/crashsimulator
PYTHONPATH=:/opt/oracle.cellos/lib/python
SHELL=/bin/bash
SHLVL=2
SUDO_COMMAND=/bin/bash -lc cd /tmp/crashsimulator; ./CrashSimulatorV2.sh --config-report --html; ./CrashSimulatorV2.sh --backup-report --html; ./CrashSimulatorV2.sh --service-review --html; ./CrashSimulatorV2.sh --maa-report --html; ./CrashSimulatorV2.sh --review --html
SUDO_GID=2000
SUDO_UID=2000
SUDO_USER=opc
S_COLORS=auto
TERM=unknown
TNS_ADMIN=/u02/app/oracle/product/23.0.0.0/dbhome_1/network/admin
USER=oracle
_=/bin/env
which_declare=declare -f
}
```

## Host Kernel And Identity

Command: uname -a

```text
Linux crashrac1-xnvfw 5.15.0-308.179.6.16.el8uek.x86_64 #2 SMP Thu Sep 18 11:19:34 PDT 2025 x86_64 x86_64 x86_64 GNU/Linux
```

## ORACLE_HOME Directory

Command: bash -lc ls\ -ld\ \'/u02/app/oracle/product/23.0.0.0/dbhome_1\'\ 2\>\&1\;\ du\ -sh\ \'/u02/app/oracle/product/23.0.0.0/dbhome_1\'\ 2\>\&1

```text
drwxr-xr-x. 67 oracle oinstall 4096 Jun  8 04:30 /u02/app/oracle/product/23.0.0.0/dbhome_1
6.4G	/u02/app/oracle/product/23.0.0.0/dbhome_1
```

## OPatch LSPatches

Command: /u02/app/oracle/product/23.0.0.0/dbhome_1/OPatch/opatch lspatches

```text
35221462;TRACKING BUG TO SHIP IAM AUTHSDK FOR 26AI CODELINE FOR CLOUD
39093738;OCW RELEASE UPDATE 23.26.2.0.0 (39093738) Gold Image
39093711;Database Release Update : 23.26.2.0.0 (39093711) Gold Image

OPatch succeeded.
```

## Listener Status

lsnrctl was not found in PATH.

## Network config: /u02/app/oracle/product/23.0.0.0/dbhome_1/network/admin/listener.ora

File not found: `/u02/app/oracle/product/23.0.0.0/dbhome_1/network/admin/listener.ora`

## Network config: /u02/app/oracle/product/23.0.0.0/dbhome_1/network/admin/tnsnames.ora

File: `/u02/app/oracle/product/23.0.0.0/dbhome_1/network/admin/tnsnames.ora`

```text
# tnsnames.ora Network Configuration File: /u02/app/oracle/product/23.0.0.0/dbhome_1/network/admin/crashdb/tnsnames.ora
# Generated by Oracle configuration tools.
CRASHRDB=
	(DESCRIPTION=
	  (ADDRESS=
	    (PROTOCOL= TCP)
	    
	    (HOST= crashrac-scan-tsrch.clientsubnet.dns.oraclevcn.com)
	    
	    (PORT= 1521)
	    )
	  
	  (CONNECT_DATA=
	    (SERVER= DEDICATED)
	    
	    (SERVICE_NAME= crashrdb.clientsubnet.dns.oraclevcn.com)
	    )
	  )
	
CRASHDB=
	(DESCRIPTION=
	  (ADDRESS=
	    (PROTOCOL=TCP)
	    
	    (HOST=crashrac-scan-tsrch.clientsubnet.dns.oraclevcn.com)
	    
	    (PORT=1521)
	    )
	  
	  (CONNECT_DATA=
	    (SERVER=DEDICATED)
	    
	    (SERVICE_NAME=crashrdb.clientsubnet.dns.oraclevcn.com)
	    
	    (FAILOVER_MODE=
	      (TYPE=select)
	      
	      (METHOD=basic)
	      )
	    )
	  )
	
CRASHPDB=
	(DESCRIPTION=
	  (ADDRESS=
	    (PROTOCOL=TCP)
	    
	    (HOST=crashrac-scan-tsrch.clientsubnet.dns.oraclevcn.com)
	    
	    (PORT=1521)
	    )
	  
	  (CONNECT_DATA=
	    (SERVER=DEDICATED)
	    
	    (SERVICE_NAME=CRASHPDB.clientsubnet.dns.oraclevcn.com)
	    
	    (FAILOVER_MODE=
	      (TYPE=select)
	      
	      (METHOD=basic)
	      )
	    )
	  )
	
CRASHDB_CRASHPDB=
	(DESCRIPTION=
	  (ADDRESS=
	    (PROTOCOL=TCP)
	    
	    (HOST=crashrac-scan-tsrch.clientsubnet.dns.oraclevcn.com)
	    
	    (PORT=1521)
	    )
	  
	  (CONNECT_DATA=
	    (SERVER=DEDICATED)
	    
	    (SERVICE_NAME=crashdb_CRASHPDB.paas.oracle.com)
	    
	    (FAILOVER_MODE=
	      (TYPE=select)
	      
	      (METHOD=basic)
	      )
	    )
	  )
	
IFILE=/var/opt/oracle/dbaas_acfs/crashdb/dbrs/tnsnames.ora
IFILE=/var/opt/oracle/dbaas_acfs/crashdb/tnsnames.ora

```

## Network config: /u02/app/oracle/product/23.0.0.0/dbhome_1/network/admin/sqlnet.ora

File: `/u02/app/oracle/product/23.0.0.0/dbhome_1/network/admin/sqlnet.ora`

```text
HTTPS_SSL_VERSION=1.2
SQLNET.CRYPTO_CHECKSUM_CLIENT=ACCEPTED
SQLNET.CRYPTO_CHECKSUM_SERVER=ACCEPTED
SQLNET.CRYPTO_CHECKSUM_TYPES_CLIENT=(SHA256,SHA384,SHA512,SHA1)
SQLNET.CRYPTO_CHECKSUM_TYPES_SERVER=(SHA256,SHA384,SHA512)
SQLNET.ENCRYPTION_CLIENT=REQUESTED
SQLNET.ENCRYPTION_SERVER=REQUESTED
SQLNET.ENCRYPTION_TYPES_CLIENT=(AES256,AES192,AES128)
SQLNET.ENCRYPTION_TYPES_SERVER=(AES256,AES192,AES128)
SQLNET.EXPIRE_TIME=10
SQLNET.IGNORE_ANO_ENCRYPTION_FOR_TCPS=TRUE
SQLNET.WALLET_OVERRIDE=FALSE
SSL_CIPHER_SUITES=(TLS_AES_128_CCM_SHA256,TLS_AES_128_GCM_SHA256,TLS_AES_256_GCM_SHA384,TLS_CHACHA20_POLY1305_SHA256,TLS_DHE_RSA_WITH_AES_128_GCM_SHA256,TLS_DHE_RSA_WITH_AES_256_GCM_SHA384,TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384)
SSL_CLIENT_AUTHENTICATION=FALSE
SSL_VERSION=TLSv1.2+
WALLET_LOCATION=
    (SOURCE=
      (METHOD=FILE)
      (METHOD_DATA=(DIRECTORY=/var/opt/oracle/dbaas_acfs/grid/tcps_wallets)))
ENCRYPTION_WALLET_LOCATION=
    (SOURCE=
      (METHOD=FILE)
      (METHOD_DATA=(DIRECTORY=/var/opt/oracle/dbaas_acfs/crashdb/wallet_root/tde)))

```

## srvctl config database

Command: srvctl config database -d crashrdb

```text
Database unique name: crashrdb
Database name: crashdb
Oracle home: /u02/app/oracle/product/23.0.0.0/dbhome_1
Oracle user: oracle
Spfile: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/PARAMETERFILE/spfile.OMF.37A52C57
Password file: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/PASSWORD/pwdCRASHRDB.4B81E94C
Domain: clientsubnet.dns.oraclevcn.com
Start options: open
Stop options: immediate
Database role: PRIMARY
Management policy: AUTOMATIC
Server pools: 
Disk Groups: 
Mount point paths: /var/opt/oracle/dbaas_acfs
Services: crashdb_CRASHPDB.paas.oracle.com,crashdb_CRASHPDB_ro.paas.oracle.com
Type: RAC
Start concurrency: 
Stop concurrency: 
OSDBA group: dba
OSOPER group: racoper
Database instances: crashdb1,crashdb2
Configured nodes: crashrac1-xnvfw,crashrac2-picqh
CSS critical: no
CPU count: 0
Memory target: 0
Maximum memory: 0
Default network number for database services: 
Database is administrator managed
```

## srvctl status database

Command: srvctl status database -d crashrdb

```text
Instance crashdb1 is running on node crashrac1-xnvfw
Instance crashdb2 is running on node crashrac2-picqh
```

## srvctl config services

Command: srvctl config service -d crashrdb

```text
Service name: crashdb_CRASHPDB.paas.oracle.com
Cardinality: 2
Service role: PRIMARY
Management policy: AUTOMATIC
DTP transaction: FALSE
AQ HA notifications: FALSE
Global: FALSE
Commit Outcome: FALSE
Commit Outcome Fastpath: FALSE
Reset State: NONE
Failover type: NONE
Failover method: NONE
Failover retries: 
Failover delay: 
Failover restore: NONE
Connection Load Balancing Goal: LONG
Runtime Load Balancing Goal: NONE
TAF policy specification: NONE
Edition: 
Pluggable database name: CRASHPDB
True Cache service: 
Maximum lag time: ANY
SQL Translation Profile: 
Retention: 86400 seconds
Failback :  no  
Replay Initiation Time: 300 seconds
Drain timeout: 
Template timeout: 86400 seconds
Stop option: 
Session State Consistency: 
Auto Connection Rebalance: DEFAULT
GSM Flags: 0
Service is enabled
Preferred instances: crashdb1,crashdb2
Available instances: 
CSS critical: no

Service name: crashdb_CRASHPDB_ro.paas.oracle.com
Cardinality: 2
Service role: PHYSICAL_STANDBY
Management policy: AUTOMATIC
DTP transaction: FALSE
AQ HA notifications: FALSE
Global: FALSE
Commit Outcome: FALSE
Commit Outcome Fastpath: FALSE
Reset State: NONE
Failover type: NONE
Failover method: 
Failover retries: 
Failover delay: 
Failover restore: NONE
Connection Load Balancing Goal: LONG
Runtime Load Balancing Goal: NONE
TAF policy specification: NONE
Edition: 
Pluggable database name: CRASHPDB
True Cache service: 
Maximum lag time: ANY
SQL Translation Profile: 
Retention: 86400 seconds
Failback :  no  
Replay Initiation Time: 300 seconds
Drain timeout: 
Template timeout: 86400 seconds
Stop option: 
Session State Consistency: 
Auto Connection Rebalance: DEFAULT
GSM Flags: 0
Service is enabled
Preferred instances: crashdb1,crashdb2
Available instances: 
CSS critical: no
```

## srvctl status services

Command: srvctl status service -d crashrdb

```text
Service crashdb_CRASHPDB.paas.oracle.com is running on instances crashdb1,crashdb2
Service crashdb_CRASHPDB_ro.paas.oracle.com is not running.
```

## srvctl config asm

Command: srvctl config asm

```text
PRCR-1001 : Resource ora.asm does not exist

[command exited with status 1]
```

## srvctl status asm

Command: srvctl status asm

```text
PRCR-1001 : Resource ora.asm does not exist

[command exited with status 1]
```

## Grid Infrastructure CRS Check

Command: crsctl check crs

```text

[command exited with status 1]
```

## Grid Infrastructure Resource Status

Command: crsctl stat res -t

```text

[command exited with status 1]
```

## Voting Disk Status

Command: crsctl query css votedisk

```text

[command exited with status 1]
```

## Data Guard Broker Configuration

dgmgrl was not found in PATH. SQL Data Guard/FSFO evidence is still included above.
