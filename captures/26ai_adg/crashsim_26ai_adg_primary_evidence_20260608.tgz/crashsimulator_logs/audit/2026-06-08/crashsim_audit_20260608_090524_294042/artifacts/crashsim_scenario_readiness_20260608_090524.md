# CrashSimulator Scenario Readiness Report

- Generated UTC: `2026-06-08T09:05:47Z`
- Tool version: `2.0.0-dev`
- Log directory: `/tmp/crashsimulator/crashsimulator_logs`
- Target PDB context: `CRASHPDB`
- Target schema context: `not set`
- Target FILE# context: `not set`

This report validates the discovered target environment against the CrashSimulator scenario registry. The same requirement checks, topology gates, target selection, and execution guardrails are used by scenario execution, so unavailable scenarios are blocked before destructive code runs.

## Current Topology

| Signal | Value |
| --- | --- |
| Host | crashrac1-xnvfw |
| OS user | oracle |
| Oracle home | /u02/app/oracle/product/23.0.0.0/dbhome_1 |
| SQL*Plus | /u02/app/oracle/product/23.0.0.0/dbhome_1/bin/sqlplus |
| Database name | CRASHDB |
| DB unique name | crashrdb |
| Database role | PRIMARY |
| Open mode | READ WRITE |
| CDB | YES |
| Instance | crashdb1 |
| Thread | 1 |
| RAC parallel | YES |
| Cluster type | RAC |
| GI managed | 1 |
| Storage type | FILESYSTEM |
| Protection mode | MAXIMUM PERFORMANCE |
| Switchover status | TO STANDBY |
| SPFILE | @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/PARAMETERFILE/spfile.OMF.37A52C57 |
| Password file | @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/PASSWORD/pwdCRASHRDB.4B81E94C |
| FRA | @rJOnB8bM(RECO_HC_HIGHREDUNDANCY) |

## PDBs

| PDB | CON_ID | Open mode |
| --- | --- | --- |
| CRASHPDB | 3 | READ WRITE |

## Readiness Summary

| Status | Count | Meaning |
| --- | ---: | --- |
| RUNNABLE | 55 | Scenario can be selected for dry-run and, when requested, execution. |
| PLAN-ONLY | 5 | Scenario can produce useful dry-run/runbook evidence, but execution is blocked by a guardrail or provider-specific limitation. |
| NOT-RUNNABLE | 22 | Scenario is not available in the current topology or target context. |
| TOTAL | 82 | Registered scenarios evaluated. |

## Runnable Scenarios

| ID | Group | Scope | Impact | Scenario | Reason |
| --- | --- | --- | --- | --- | --- |
| `1` | Core | CDB/non-CDB | destructive | Loss of one control file | Requirements passed and target selection produced executable actions. |
| `2` | Core | CDB/non-CDB | destructive | Loss of all control files | Requirements passed and target selection produced executable actions. |
| `4` | Core | CDB/non-CDB | destructive | Loss of all members from current redo group | Requirements passed and target selection produced executable actions. |
| `5` | Core | CDB/non-CDB | destructive | Loss of one non-system datafile | Requirements passed and target selection produced executable actions. |
| `6` | Core | CDB/non-CDB | destructive | Loss of one temporary file | Requirements passed and target selection produced executable actions. |
| `7` | Core | CDB/non-CDB | destructive | Loss of one SYSTEM datafile | Requirements passed and target selection produced executable actions. |
| `8` | Core | CDB/non-CDB | destructive | Loss of one UNDO datafile | Requirements passed and target selection produced executable actions. |
| `9` | Core | CDB/non-CDB | destructive | Loss of a read-only tablespace | Requirements passed and target selection produced executable actions. |
| `10` | Core | CDB/non-CDB | destructive | Loss of an index-only tablespace | Requirements passed and target selection produced executable actions. |
| `11` | Logical | CDB/non-CDB | logical | Drop non-unique indexes outside Oracle schemas | Requirements passed and target selection produced executable actions. |
| `12` | Core | CDB/non-CDB | destructive | Loss of a non-system tablespace | Requirements passed and target selection produced executable actions. |
| `13` | Core | CDB/non-CDB | destructive | Loss of a temporary tablespace | Requirements passed and target selection produced executable actions. |
| `14` | Core | CDB/non-CDB | destructive | Loss of SYSTEM tablespace | Requirements passed and target selection produced executable actions. |
| `15` | Core | CDB/non-CDB | destructive | Loss of UNDO tablespace | Requirements passed and target selection produced executable actions. |
| `16` | Config | CDB/non-CDB | destructive | Loss of password file | Requirements passed and target selection produced executable actions. |
| `17` | Core | CDB/non-CDB | destructive | Loss of all datafiles | Requirements passed and target selection produced executable actions. |
| `19` | Core | CDB/non-CDB | destructive | Loss of all inactive redo groups | Requirements passed and target selection produced executable actions. |
| `20` | Core | CDB/non-CDB | destructive | Loss of all active redo groups | Requirements passed and target selection produced executable actions. |
| `21` | Core | CDB/non-CDB | destructive | Loss of all current redo group members | Requirements passed and target selection produced executable actions. |
| `22` | Corrupt | CDB/non-CDB | destructive | Datafile header corruption | Requirements passed and target selection produced executable actions. |
| `23` | Corrupt | CDB/non-CDB | destructive | Control file corruption | Requirements passed and target selection produced executable actions. |
| `24` | Corrupt | CDB/non-CDB | destructive | Redo log corruption | Requirements passed and target selection produced executable actions. |
| `26` | Config | CDB/non-CDB | destructive | Loss of SPFILE | Requirements passed and target selection produced executable actions. |
| `27` | Config | CDB/non-CDB | destructive | Loss of SQL*Net config files | Requirements passed and target selection produced executable actions. |
| `29` | Backup | CDB/non-CDB | destructive | Loss of FRA destination | Requirements passed and target selection produced executable actions. |
| `30` | PDB | PDB | destructive | PDB loss of one non-system datafile | Requirements passed and target selection produced executable actions. |
| `31` | PDB | PDB | destructive | PDB loss of one temporary file | Requirements passed and target selection produced executable actions. |
| `32` | PDB | PDB | destructive | PDB loss of one SYSTEM datafile | Requirements passed and target selection produced executable actions. |
| `33` | PDB | PDB | destructive | PDB loss of one UNDO datafile | Requirements passed and target selection produced executable actions. |
| `34` | PDB | PDB | destructive | PDB loss of read-only tablespace | Requirements passed and target selection produced executable actions. |
| `35` | PDB | PDB | destructive | PDB loss of index-only tablespace | Requirements passed and target selection produced executable actions. |
| `36` | PDB | PDB | logical | PDB drop non-unique indexes | Requirements passed and target selection produced executable actions. |
| `37` | PDB | PDB | destructive | PDB loss of non-system tablespace | Requirements passed and target selection produced executable actions. |
| `38` | PDB | PDB | destructive | PDB loss of temporary tablespace | Requirements passed and target selection produced executable actions. |
| `39` | PDB | PDB | destructive | PDB loss of SYSTEM tablespace | Requirements passed and target selection produced executable actions. |
| `40` | PDB | PDB | destructive | PDB loss of UNDO tablespace | Requirements passed and target selection produced executable actions. |
| `41` | PDB | PDB | destructive | PDB loss of all datafiles | Requirements passed and target selection produced executable actions. |
| `42` | PDB | PDB | destructive | PDB SYSTEM file header corruption | Requirements passed and target selection produced executable actions. |
| `43` | PDB | PDB | logical | PDB loss of one user table | Requirements passed and target selection produced executable actions. |
| `44` | PDB | PDB | logical | PDB loss of one user schema | Requirements passed and target selection produced executable actions. |
| `51` | DataGuard | Primary | logical | Primary transport destination deferred | Requirements passed and target selection produced executable actions. |
| `55` | RAC | RAC | destructive | RAC abort one instance | Requirements passed and target selection produced executable actions. |
| `56` | RAC | RAC | logical | RAC service relocation failure practice | Requirements passed and target selection produced executable actions. |
| `57` | Network | CDB/non-CDB | destructive | Listener config unavailable | Requirements passed and target selection produced executable actions. |
| `58` | Security | CDB/non-CDB | destructive | TDE wallet or keystore unavailable | Requirements passed and target selection produced executable actions. |
| `59` | Backup | CDB/non-CDB | destructive | Missing archived redo log | Requirements passed and target selection produced executable actions. |
| `60` | Backup | External | logical | Recovery catalog unavailable | Requirements passed and target selection produced executable actions. |
| `61` | Backup | CDB/non-CDB | destructive | FRA reaches critical utilization | Requirements passed and target selection produced executable actions. |
| `62` | Backup | CDB/non-CDB | destructive | Missing required archived log during recovery | Requirements passed and target selection produced executable actions. |
| `63` | Core | CDB/non-CDB | logical | TEMP tablespace exhaustion | Requirements passed and target selection produced executable actions. |
| `64` | Compliance | CDB/non-CDB | logical | RTO validation drill | Requirements passed and target selection produced executable actions. |
| `65` | Compliance | CDB/non-CDB | logical | RPO validation drill | Requirements passed and target selection produced executable actions. |
| `68` | DataGuard | Primary | logical | Data Guard transport network partition | Requirements passed and target selection produced executable actions. |
| `69` | DataGuard | DG | logical | Standby redo log misconfiguration review | Requirements passed and target selection produced executable actions. |
| `71` | RAC | RAC | logical | RAC service placement failure | Requirements passed and target selection produced executable actions. |

## Dry-Run Planning Only

| ID | Group | Scope | Impact | Scenario | Reason |
| --- | --- | --- | --- | --- | --- |
| `25` | Backup | CDB/non-CDB | destructive | Loss of RMAN backup pieces | Scenario 25 can see local and object-storage backup handles; execution requires --piece-handle or --local-only --max-targets <n>. |
| `28` | Config | CDB/non-CDB | destructive | Loss of ORACLE_HOME | Scenario 28 ORACLE_HOME loss requires an external restore/reinstall plan and is intentionally dry-run/manual only in this framework. |
| `45` | PDB | PDB | destructive | Drop selected PDB including datafiles | Scenario 45 can only execute against a disposable PDB whose name starts with CRASHSIM_. Current PDB: CRASHPDB. |
| `47` | GI | Cluster | destructive | OCR loss or restore drill | Selected target requires a provider-specific or manual handler before safe execution: OCR (OCR restore practice must use a root/Grid procedure, verified OCR backups, and CRS validation) |
| `48` | GI | Cluster | destructive | Voting disk loss or restore drill | Selected target requires a provider-specific or manual handler before safe execution: VOTING_DISK (Voting disk replacement practice must use a root/Grid procedure and cluster membership validation) |

## Not Runnable Now

| ID | Group | Scope | Impact | Scenario | Reason |
| --- | --- | --- | --- | --- | --- |
| `3` | Core | CDB/non-CDB | destructive | Loss of one member from current redo group | No multiplexed member was found in the CURRENT redo group. Add at least one additional online redo member to the current group, or multiplex all redo groups and switch logs until a multiplexed group is current, then rerun validation. |
| `18` | Core | CDB/non-CDB | destructive | Loss of one member from multiplexed redo group | No online redo group with more than one member was found. Multiplex the online redo logs, preferably every group/thread in RAC, then rerun validation. |
| `46` | ASM | ASM | destructive | ASM data disk group unavailable | Scenario 46 requires ASM storage. |
| `49` | ASM | ASM | destructive | ASM SPFILE loss | Scenario 49 requires ASM storage. |
| `50` | DataGuard | Standby | logical | Standby managed recovery cancelled | Scenario 50 requires a physical standby database with managed recovery running. Run it on a standby environment, then confirm an MRP process is visible in V$MANAGED_STANDBY. |
| `52` | DataGuard | DG | logical | Data Guard broker configuration unavailable | Scenario 52 is registered as a placeholder for DG testing, but a runnable handler is not implemented yet. |
| `53` | ADG | Standby | logical | Active Data Guard read-only session pressure | Scenario 53 requires an Active Data Guard standby opened READ ONLY WITH APPLY. Run it on an ADG standby after confirming open mode and apply status. |
| `54` | DataGuard | Standby | logical | Snapshot standby conversion practice | Scenario 54 requires a Data Guard physical standby that is approved for snapshot-standby conversion practice. Run it on the standby after confirming flashback, broker/transport posture, and restore-point policy. |
| `66` | DataGuard | DG | logical | FSFO observer unavailable | FSFO observer was not detected. Enable Fast-Start Failover, start an observer, and confirm V$DATABASE.FS_FAILOVER_OBSERVER_PRESENT or DGMGRL evidence before running scenario 66. |
| `67` | DataGuard | Standby | logical | Data Guard apply lag exceeds SLA | Scenario 67 requires a physical standby database with managed recovery running. Run it on a standby environment, then confirm an MRP process is visible in V$MANAGED_STANDBY. |
| `70` | RAC | RAC | logical | RAC VIP relocation drill | Unable to collect Clusterware resource status with crsctl. |
| `72` | ASM | ASM | destructive | ASM single disk failure | Scenario 72 requires ASM storage. |
| `73` | APEX/ORDS | Application | logical | ORDS service unavailable | ORDS is not installed or not in PATH. Install/configure ORDS on this host before running scenario 73. |
| `74` | APEX/ORDS | Application | destructive | ORDS configuration unavailable | ORDS configuration directory was not found at /etc/ords/config. Configure ORDS or pass --ords-config-dir before running scenario 74. |
| `75` | APEX/ORDS | Application | logical | ORDS database pool misconfiguration | ORDS is not installed or not in PATH. Install/configure ORDS before running scenario 75. |
| `76` | APEX/ORDS | Application | logical | APEX/ORDS runtime account locked | No unlocked APEX/ORDS runtime account was found. Install/configure APEX/ORDS in the selected container and confirm APEX_PUBLIC_USER or ORDS_PUBLIC_USER exists before running scenario 76. |
| `77` | APEX/ORDS | Application | destructive | APEX static resources unavailable | No APEX static images directory was found. Install APEX static files and pass --apex-images-dir before running scenario 77. |
| `78` | APEX/ORDS | Application | logical | APEX application availability validation after recovery | The ORDS/APEX smoke URL is not reachable: http://localhost:8080/ords/. Start/configure ORDS and validate network access before running scenario 78. |
| `79` | APEX/ORDS | Application | logical | ORDS node unavailable behind load balancer | ORDS is not installed or not in PATH. Install/configure ORDS on this host before running scenario 79. |
| `80` | APEX/ORDS | Application | logical | APEX session continuity test | APEX is not installed in the selected target container. Install APEX in the PDB and rerun validation for scenario 80. |
| `81` | APEX/ORDS | Application | logical | APEX mail queue and configuration validation | APEX is not installed in the selected target container. Install APEX in the PDB and rerun validation for scenario 81. |
| `82` | APEX/ORDS | Application | logical | APEX upgrade or patch rollback readiness | APEX is not installed in the selected target container. Install APEX in the PDB and rerun validation for scenario 82. |

## How CrashSimulator Uses This Result

- `--scenario <id> --execute`, `--protect <id> --execute`, and aleatory scenario execution run readiness validation before confirmation or destructive actions.
- Guided Workflow scenario selection now shows the selected scenario readiness status immediately.
- Use only `RUNNABLE` scenarios for execution drills. Review `PLAN-ONLY` and `NOT-RUNNABLE` reasons before changing topology, targets, or helper coverage.
- Re-run this report after changing database topology, adding PDBs, multiplexing redo/control files, configuring Data Guard, adding ASM/GI lab disks, reseeding logical objects, or taking fresh backups.

## Recommended Next Commands

```bash
./CrashSimulatorV2.sh --validate-scenario <id> --pdb CRASHPDB
./CrashSimulatorV2.sh --scenario <id> --pdb CRASHPDB --dry-run
./CrashSimulatorV2.sh --runbook <id> --pdb CRASHPDB
./CrashSimulatorV2.sh --health-check --pdb CRASHPDB
```
