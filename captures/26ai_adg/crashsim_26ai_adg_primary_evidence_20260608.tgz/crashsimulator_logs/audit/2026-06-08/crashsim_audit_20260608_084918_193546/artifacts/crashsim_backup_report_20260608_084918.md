# CrashSimulator Backup Strategy And Recoverability Report

- Generated UTC: `2026-06-08T08:49:21Z`
- Host: `crashrac1-xnvfw`
- OS user: `oracle`
- Database: `CRASHDB`
- DB unique name: `crashrdb`
- DBID: `1275206961`
- Role/open mode: `PRIMARY` / `READ WRITE`
- CDB: `YES`
- Storage: `FILESYSTEM`
- Cluster type: `RAC`
- Deep RMAN validation: `disabled`
- RMAN repository source requested: `target control file`
- SQL evidence file: `/tmp/crashsimulator/crashsimulator_logs/crashsim_backup_report_20260608_084918.evidence`

This report estimates recoverability from current database/RMAN metadata and optional RMAN validation output. RTO/RPO values are planning estimates, not guarantees; prove them with timed restore, recovery, and application validation drills.

## Executive Summary

| Field | Value |
| --- | --- |
| Strategy detected | Level 0/full datafile backup strategy observed with archived redo backups |
| Level 0/full cadence | roughly hourly or better; last backup `2026-06-08 08:43:18`, age `0.1` hours |
| Level 1 incremental cadence | not enough history; last backup `NONE`, age `UNKNOWN` hours |
| Archived redo backup cadence | roughly hourly or better; last backup `2026-06-08 08:43:03`, age `0.1` hours |
| Visible database size | `13.48` GB across `17` datafiles |
| Backup device types | `SBT_TAPE` |
| Backup piece device types | `DISK,SBT_TAPE` |
| Backup-only RPO estimate | Backup-only RPO is approximately the age of the latest archived redo backup, currently about 0.1 hours; actual data loss can be lower if required archived logs and online redo survive locally. Oldest currently unbacked archived redo is about 3 hours old. Valid Data Guard destinations are visible and may provide a lower HA/DR RPO than backup-only recovery; validate transport/apply lag separately. |
| Backup/recovery RTO estimate | Potential RTO may be lower if image copies are current and switch-to-copy/roll-forward is practiced. Visible database size is 13.48 GB. Latest Level 0/full backup age is 0.1 hours. Recent successful backup job duration averages 0.4 minutes and maxes at 0.9 minutes; restore time can differ and must be measured. |

## Backup Health Checks

| Status | Area | Check | Evidence | Recommendation |
| --- | --- | --- | --- | --- |
| `OK` | Coverage | Every datafile has backup metadata | missing_datafiles=0 | Keep validating restore paths and catalog/control-file metadata retention. |
| `OK` | Baseline | Recent Level 0/full backup | age_hours=0.1 | Keep Level 0/full backups aligned with restore-time objectives. |
| `OK` | Recoverability | ARCHIVELOG mode | log_mode=ARCHIVELOG | Continue backing archived redo frequently enough to meet RPO. |
| `OK` | RPO | Recent archived redo backup | age_hours=0.1 | Back up archived redo more frequently than the required backup-only RPO. |
| `OK` | Reliability | No failed RMAN jobs in last 7 days | failed_7d=0, failed_30d=0 | Keep alerting on failed backup jobs. |
| `OK` | Repository | Backup piece status | available=67, expired=0, unavailable=0, deleted=0 | Schedule periodic CROSSCHECK and cleanup obsolete/expired records. |
| `OK` | Control file | Control file autobackup | ON | Keep autobackup enabled and test restore controlfile from autobackup. |
| `OK` | Validation | Recovery/corruption views | recover_files=0, corruption_rows=0 | Continue scheduled validation and corruption monitoring. |
| `OK` | FRA | FRA utilization | fra_used_pct=6.9 | Keep FRA capacity monitored against archive generation and retention. |

## Strategy Interpretation And Recommendations

- Observed strategy: Level 0/full datafile backup strategy observed with archived redo backups.
- RMAN retention policy: `TO NONE`.
- Control file record keep time: `7` days. If no catalog is used, keep this long enough to preserve restore history for your retention window.
- Backup repository source: `Target control file only for this report run.`.
- RTO guidance: Potential RTO may be lower if image copies are current and switch-to-copy/roll-forward is practiced. Visible database size is 13.48 GB. Latest Level 0/full backup age is 0.1 hours. Recent successful backup job duration averages 0.4 minutes and maxes at 0.9 minutes; restore time can differ and must be measured.
- RPO guidance: Backup-only RPO is approximately the age of the latest archived redo backup, currently about 0.1 hours; actual data loss can be lower if required archived logs and online redo survive locally. Oldest currently unbacked archived redo is about 3 hours old. Valid Data Guard destinations are visible and may provide a lower HA/DR RPO than backup-only recovery; validate transport/apply lag separately.
- Best-practice direction: run periodic RMAN restore validation, validate selected backups when pieces are suspected missing, keep repository metadata accurate with crosschecks, protect control file/SPFILE backups, and run timed CrashSimulator restore drills to prove actual RTO/RPO.

## SQL Backup Repository Details


## Control-File SQL Backup Evidence

Command: /u02/app/oracle/product/23.0.0.0/dbhome_1/bin/sqlplus -s /\ as\ sysdba @/tmp/crashsimulator/crashsimulator_logs/crashsim_backup_report_20260608_084918_detail.sql

```text
# Backup SQL Evidence

## Database Backup Context

NAME                                   DB_UNIQUE_NAME                 DATABASE_ROLE    OPEN_MODE            CDB LOG_MODE     FORCE_LOGGING                           FLASHBACK_ON
-------------------------------------- ------------------------------ ---------------- -------------------- --- ------------ --------------------------------------- ------------------
CRASHDB                                crashrdb                       PRIMARY          READ WRITE           YES ARCHIVELOG   YES                                     YES

1 row selected.

## RMAN Configuration

NAME                                   VALUE
-------------------------------------- ------------------------------------------------------------------------------------------------------------------------
BACKUP OPTIMIZATION                    OFF
CHANNEL                                DEVICE TYPE 'SBT_TAPE' FORMAT   '%d_%I_%U_%T_%t' PARMS  "SBT_LIBRARY=/u02/app/oracle/product/23.0.0.0/dbhome_1/lib/libra
                                       .so, ENV=(RA_WALLET='location=file:/var/opt/oracle/dbaas_acfs/crashdb/wallet_root/server_seps credential_alias=DBRS',RA_
                                       FORMAT=TRUE)"

COMPRESSION ALGORITHM                  'low' AS OF RELEASE 'DEFAULT' OPTIMIZE FOR LOAD TRUE
CONTROLFILE AUTOBACKUP                 ON
DB_UNIQUE_NAME                         'crashrdb' CONNECT IDENTIFIER  'crashrdb'
DB_UNIQUE_NAME                         'crashdr' CONNECT IDENTIFIER  'crashdr'
DEFAULT DEVICE TYPE TO                 'SBT_TAPE'
DEVICE TYPE                            'SBT_TAPE' PARALLELISM 4 BACKUP TYPE TO COMPRESSED BACKUPSET
ENCRYPTION ALGORITHM                   'AES256'
ENCRYPTION FOR DATABASE                ON
RETENTION POLICY                       TO NONE
SNAPSHOT CONTROLFILE NAME              TO '@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/CONTROLFILE/snapcf_crashdb.f'

12 rows selected.

## RMAN Job History - Last 60 Jobs

         SESSION_KEY INPUT_TYPE               STATUS                   START_TIME           END_TIME                  ELAPSED_MINUTES OUTPUT_DEVICE_TYP
-------------------- ------------------------ ------------------------ -------------------- -------------------- -------------------- -----------------
INPUT_BYTES_DISPLAY
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
OUTPUT_BYTES_DISPLAY
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                  61 DB FULL                  COMPLETED                2026-06-08 08:42:30  2026-06-08 08:43:21                    .9 SBT_TAPE
    4.73G
  925.25M

                  56 ARCHIVELOG               COMPLETED                2026-06-08 08:33:12  2026-06-08 08:33:30                    .3 SBT_TAPE
  175.43M
    9.50M

                  51 ARCHIVELOG               COMPLETED                2026-06-08 08:03:12  2026-06-08 08:03:30                    .3 SBT_TAPE
  206.90M
   41.00M

                  46 ARCHIVELOG               COMPLETED                2026-06-08 07:33:19  2026-06-08 07:33:35                    .3 SBT_TAPE
  178.50M
   12.75M

                  41 ARCHIVELOG               COMPLETED                2026-06-08 07:03:11  2026-06-08 07:03:29                    .3 SBT_TAPE
  231.15M
   65.25M

                  34 ARCHIVELOG               COMPLETED                2026-06-08 06:33:12  2026-06-08 06:33:30                    .3 SBT_TAPE
  174.85M
    8.75M

                  29 ARCHIVELOG               COMPLETED                2026-06-08 06:03:13  2026-06-08 06:03:32                    .3 SBT_TAPE
  203.10M
   37.50M

                  23 ARCHIVELOG               COMPLETED                2026-06-08 05:33:15  2026-06-08 05:33:31                    .3 SBT_TAPE
  173.48M
    7.50M

                  18 DB INCR                  COMPLETED                2026-06-08 05:08:01  2026-06-08 05:08:31                    .5 SBT_TAPE
    4.48G
    3.59G

                  11 ARCHIVELOG               COMPLETED                2026-06-08 05:03:11  2026-06-08 05:03:30                    .3 SBT_TAPE
  397.71M
  232.00M


10 rows selected.

## Observed Job Cadence By Type, Day, And Hour

INPUT_TYPE               START_DAY  ST            JOB_COUNT FIRST_OBSERVED      LAST_OBSERVED
------------------------ ---------- -- -------------------- ------------------- -------------------
ARCHIVELOG               MON        05                    2 2026-06-08 05:03:11 2026-06-08 05:33:15
ARCHIVELOG               MON        06                    2 2026-06-08 06:03:13 2026-06-08 06:33:12
ARCHIVELOG               MON        07                    2 2026-06-08 07:03:11 2026-06-08 07:33:19
ARCHIVELOG               MON        08                    2 2026-06-08 08:03:12 2026-06-08 08:33:12
DB FULL                  MON        08                    1 2026-06-08 08:42:30 2026-06-08 08:42:30
DB INCR                  MON        05                    1 2026-06-08 05:08:01 2026-06-08 05:08:01

6 rows selected.

## Datafile Backup Coverage

               FILE# FILE_NAME                                                                                                                                              LAST_BACKUP_TIME    LAST_INCREMENTAL_LEVEL BACKUP_STATUS
-------------------- ------------------------------------------------------------------------------------------------------------------------------------------------------ ------------------- ---------------------- ----------------------------------
                   1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/SYSTEM.OMF.70DAA345                                                             2026-06-08 08:42:46                        BACKUP METADATA FOUND
                   2 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/5096C84B7BB5210CE0636C0DF40A1151/DATAFILE/SYSTEM.OMF.3BED3E82                            2026-06-08 08:42:51                        BACKUP METADATA FOUND
                   3 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/SYSAUX.OMF.45447F4E                                                             2026-06-08 08:42:44                        BACKUP METADATA FOUND
                   4 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/5096C84B7BB5210CE0636C0DF40A1151/DATAFILE/SYSAUX.OMF.7122AC18                            2026-06-08 08:42:52                        BACKUP METADATA FOUND
                   5 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/UNDOTBS1.OMF.5CF22136                                                           2026-06-08 08:42:33                        BACKUP METADATA FOUND
                   6 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/5096C84B7BB5210CE0636C0DF40A1151/DATAFILE/UNDOTBS1.OMF.1F3606C1                          2026-06-08 08:42:50                        BACKUP METADATA FOUND
                   7 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/USERS.OMF.6CA6D570                                                              2026-06-08 08:42:33                        BACKUP METADATA FOUND
                   8 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/UNDOTBS2.OMF.55ECD93B                                                           2026-06-08 08:42:31                        BACKUP METADATA FOUND
                   9 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/SYSTEM.OMF.49D473E6                            2026-06-08 08:42:44                        BACKUP METADATA FOUND
                  10 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/SYSAUX.OMF.5B8C6142                            2026-06-08 08:42:44                        BACKUP METADATA FOUND
                  11 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/UNDOTBS1.OMF.79BB15E3                          2026-06-08 08:42:36                        BACKUP METADATA FOUND
                  12 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/UNDO_4.OMF.7FD1842F                            2026-06-08 08:42:40                        BACKUP METADATA FOUND
                  13 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/USERS.OMF.7A32E8B8                             2026-06-08 08:42:34                        BACKUP METADATA FOUND
                  14 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/CRASHSIM_ROOT_RO_TBS.OMF.28790F18                                               2026-06-08 08:42:32                        BACKUP METADATA FOUND
                  15 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/CRASHSIM_ROOT_INDEX_TBS.OMF.15484A11                                            2026-06-08 08:42:32                        BACKUP METADATA FOUND
                  16 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/CRASHSIM_RO_TBS.OMF.3653F3F1                   2026-06-08 08:42:36                        BACKUP METADATA FOUND
                  17 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/CRASHSIM_INDEX_TBS.OMF.4F7C5839                2026-06-08 08:42:35                        BACKUP METADATA FOUND

17 rows selected.

## Datafile Backup Levels - Last 90 Days

BACKUP_CLASS            BACKED_FILE_ENTRIES FIRST_OBSERVED      LAST_OBSERVED
---------------------- -------------------- ------------------- -------------------
FULL/NON-INCREMENTAL                     31 2026-06-08 04:48:11 2026-06-08 08:43:18
LEVEL 0                                  13 2026-06-08 05:08:07 2026-06-08 05:08:26

2 rows selected.

## Backup Piece Status

STATUS                   DEVICE_TYPE                 PIECE_COUNT OLDEST_COMPLETION   LATEST_COMPLETION
------------------------ ------------------ -------------------- ------------------- -------------------
A                        DISK                                  2 2026-06-08 04:48:11 2026-06-08 05:53:13
A                        SBT_TAPE                             65 2026-06-08 05:03:16 2026-06-08 08:43:19

2 rows selected.

## Recent Backup Pieces

               RECID                STAMP STATUS                   DEVICE_TYPE        COMPLETION_TIME                   SIZE_GB COM
-------------------- -------------------- ------------------------ ------------------ -------------------- -------------------- ---
HANDLE
------------------------------------------------------------------------------------------------------------------------------------------------------
                  67           1235378595 A                        SBT_TAPE           2026-06-08 08:43:19                     0 YES
c-1275206961-20260608-0c

                  66           1235378592 A                        SBT_TAPE           2026-06-08 08:43:13                     0 YES
CRASHDB_1275206961_2h050od0_81_1_1_20260608_1780908192

                  65           1235378589 A                        SBT_TAPE           2026-06-08 08:43:11                     0 YES
CRASHDB_1275206961_2gt40ocq_80_1_1_20260608_1780908189

                  64           1235378582 A                        SBT_TAPE           2026-06-08 08:43:04                     0 YES
CRASHDB_1275206961_2cm40ocm_76_1_1_20260608_1780908182

                  61           1235378582 A                        SBT_TAPE           2026-06-08 08:43:03                     0 YES
CRASHDB_1275206961_2em40ocm_78_1_1_20260608_1780908182

                  63           1235378582 A                        SBT_TAPE           2026-06-08 08:43:03                     0 YES
CRASHDB_1275206961_2dm40ocm_77_1_1_20260608_1780908182

                  62           1235378582 A                        SBT_TAPE           2026-06-08 08:43:03                     0 YES
CRASHDB_1275206961_2fm40ocm_79_1_1_20260608_1780908182

                  60           1235378575 A                        SBT_TAPE           2026-06-08 08:42:56                     0 YES
c-1275206961-20260608-0b

                  59           1235378566 A                        SBT_TAPE           2026-06-08 08:42:53                   .04 YES
CRASHDB_1275206961_2a640oc6_74_1_1_20260608_1780908166

                  57           1235378566 A                        SBT_TAPE           2026-06-08 08:42:51                   .09 YES
CRASHDB_1275206961_29640oc6_73_1_1_20260608_1780908166

                  58           1235378566 A                        SBT_TAPE           2026-06-08 08:42:51                   .13 YES
CRASHDB_1275206961_28640oc6_72_1_1_20260608_1780908166

                  56           1235378551 A                        SBT_TAPE           2026-06-08 08:42:47                   .34 YES
CRASHDB_1275206961_23n30obn_67_1_1_20260608_1780908151

                  55           1235378559 A                        SBT_TAPE           2026-06-08 08:42:45                   .13 YES
CRASHDB_1275206961_27v30obv_71_1_1_20260608_1780908159

                  53           1235378556 A                        SBT_TAPE           2026-06-08 08:42:44                   .04 YES
CRASHDB_1275206961_26s30obr_70_1_1_20260608_1780908156

                  54           1235378551 A                        SBT_TAPE           2026-06-08 08:42:44                   .08 YES
CRASHDB_1275206961_22n30obm_66_1_1_20260608_1780908151

                  52           1235378554 A                        SBT_TAPE           2026-06-08 08:42:37                   .05 YES
CRASHDB_1275206961_25q30obq_69_1_1_20260608_1780908154

                  51           1235378554 A                        SBT_TAPE           2026-06-08 08:42:35                     0 YES
CRASHDB_1275206961_24q30obq_68_1_1_20260608_1780908154

                  50           1235378551 A                        SBT_TAPE           2026-06-08 08:42:33                     0 YES
CRASHDB_1275206961_20m30obm_64_1_1_20260608_1780908150

                  49           1235378551 A                        SBT_TAPE           2026-06-08 08:42:32                     0 YES
CRASHDB_1275206961_21m30obm_65_1_1_20260608_1780908150

                  48           1235378003 A                        SBT_TAPE           2026-06-08 08:33:25                     0 YES
c-1275206961-20260608-0a

                  46           1235377997 A                        SBT_TAPE           2026-06-08 08:33:18                     0 NO
1tdivnqd_61_1_1

                  47           1235377997 A                        SBT_TAPE           2026-06-08 08:33:18                     0 NO
1udivnqd_62_1_1

                  45           1235376203 A                        SBT_TAPE           2026-06-08 08:03:25                     0 YES
c-1275206961-20260608-09

                  44           1235376197 A                        SBT_TAPE           2026-06-08 08:03:19                   .02 NO
1q5qtm25_58_1_1

                  43           1235376197 A                        SBT_TAPE           2026-06-08 08:03:18                   .02 NO
1r5qtm25_59_1_1

                  42           1235374408 A                        SBT_TAPE           2026-06-08 07:33:30                     0 YES
c-1275206961-20260608-08

                  40           1235374402 A                        SBT_TAPE           2026-06-08 07:33:23                   .01 NO
1n22ska2_55_1_1

                  41           1235374402 A                        SBT_TAPE           2026-06-08 07:33:23                     0 NO
1o22ska2_56_1_1

                  39           1235372602 A                        SBT_TAPE           2026-06-08 07:03:24                     0 YES
c-1275206961-20260608-07

                  37           1235372596 A                        SBT_TAPE           2026-06-08 07:03:18                   .03 NO
1kk9qihk_52_1_1

                  38           1235372596 A                        SBT_TAPE           2026-06-08 07:03:18                   .03 NO
1lk9qihk_53_1_1

                  36           1235370802 A                        SBT_TAPE           2026-06-08 06:33:25                     0 YES
c-1275206961-20260608-06

                  34           1235370796 A                        SBT_TAPE           2026-06-08 06:33:18                     0 NO
1ichogpc_50_1_1

                  35           1235370796 A                        SBT_TAPE           2026-06-08 06:33:18                     0 NO
1hchogpc_49_1_1

                  33           1235369005 A                        SBT_TAPE           2026-06-08 06:03:27                     0 YES
c-1275206961-20260608-05

                  30           1235368998 A                        SBT_TAPE           2026-06-08 06:03:20                     0 NO
1e6pmf16_46_1_1

                  32           1235368998 A                        SBT_TAPE           2026-06-08 06:03:20                   .02 NO
1c6pmf16_44_1_1

                  31           1235368998 A                        SBT_TAPE           2026-06-08 06:03:20                   .01 NO
1d6pmf16_45_1_1

                  29           1235368999 A                        SBT_TAPE           2026-06-08 06:03:19                     0 NO
1f6pmf16_47_1_1

                  28           1235368391 A                        DISK               2026-06-08 05:53:13                   .16 NO
@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/AUTOBACKUP/2026_06_08/s_1235368390.OMF.190EBC6D

                  27           1235367204 A                        SBT_TAPE           2026-06-08 05:33:25                     0 YES
c-1275206961-20260608-03

                  26           1235367199 A                        SBT_TAPE           2026-06-08 05:33:20                     0 NO
0qv0ld8v_26_1_1

                  25           1235367199 A                        SBT_TAPE           2026-06-08 05:33:19                     0 NO
0pv0ld8v_25_1_1

                  24           1235365715 A                        SBT_TAPE           2026-06-08 05:08:38                     0 YES
c-1275206961-20260608-02

                  23           1235365710 A                        SBT_TAPE           2026-06-08 05:08:31                     0 YES
0neijbqe_23_1_1

                  22           1235365710 A                        SBT_TAPE           2026-06-08 05:08:30                     0 YES
0meijbqe_22_1_1

                  21           1235365704 A                        SBT_TAPE           2026-06-08 05:08:26                   .33 NO
0l8ijbq8_21_1_1

                  20           1235365699 A                        SBT_TAPE           2026-06-08 05:08:24                   .31 NO
0h3ijbq3_17_1_1

                  18           1235365699 A                        SBT_TAPE           2026-06-08 05:08:23                   .31 NO
0j3ijbq3_19_1_1

                  19           1235365700 A                        SBT_TAPE           2026-06-08 05:08:23                    .3 NO
0k4ijbq4_20_1_1

                  17           1235365696 A                        SBT_TAPE           2026-06-08 05:08:22                   .33 NO
0gvhjbpv_16_1_1

                  15           1235365695 A                        SBT_TAPE           2026-06-08 05:08:19                    .3 NO
0fvhjbpv_15_1_1

                  16           1235365699 A                        SBT_TAPE           2026-06-08 05:08:19                   .02 NO
0i3ijbq3_18_1_1

                  14           1235365687 A                        SBT_TAPE           2026-06-08 05:08:18                   .96 NO
09nhjbpn_9_1_1

                  13           1235365688 A                        SBT_TAPE           2026-06-08 05:08:16                   .59 NO
0cnhjbpn_12_1_1

                  11           1235365687 A                        SBT_TAPE           2026-06-08 05:08:13                   .01 NO
0bnhjbpn_11_1_1

                  12           1235365692 A                        SBT_TAPE           2026-06-08 05:08:13                   .07 NO
0eshjbps_14_1_1

                  10           1235365688 A                        SBT_TAPE           2026-06-08 05:08:10                   .07 NO
0dohjbpo_13_1_1

                   9           1235365687 A                        SBT_TAPE           2026-06-08 05:08:07                   .01 NO
0anhjbpn_10_1_1

                   7           1235365683 A                        SBT_TAPE           2026-06-08 05:08:04                     0 YES
08jhjbpj_8_1_1

                   8           1235365683 A                        SBT_TAPE           2026-06-08 05:08:04                     0 YES
07jhjbpj_7_1_1

                   6           1235365406 A                        SBT_TAPE           2026-06-08 05:03:27                     0 YES
c-1275206961-20260608-01

                   4           1235365396 A                        SBT_TAPE           2026-06-08 05:03:19                   .14 NO
02k8jbgj_2_1_1

                   5           1235365396 A                        SBT_TAPE           2026-06-08 05:03:19                   .01 NO
05k8jbgk_5_1_1

                   3           1235365396 A                        SBT_TAPE           2026-06-08 05:03:18                   .05 NO
03k8jbgk_3_1_1

                   2           1235365396 A                        SBT_TAPE           2026-06-08 05:03:16                   .03 NO
04k8jbgk_4_1_1

                   1           1235364489 A                        DISK               2026-06-08 04:48:11                   .16 NO
@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/AUTOBACKUP/2026_06_08/s_1235364487.OMF.101996CD


67 rows selected.

## Archived Redo Backup Coverage - Last 7 Days

             THREAD#            SEQUENCE# FIRST_TIME          COMPLETION_TIME      DEL         BACKUP_COUNT NAME
-------------------- -------------------- ------------------- -------------------- --- -------------------- --------------------------------------
                   1                    2 2026-06-08 04:23:45 2026-06-08 04:38:18  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_1_seq_2.OMF.585E0D0C

                   1                    3 2026-06-08 04:38:17 2026-06-08 04:38:20  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_1_seq_3.OMF.5F5D61F8

                   1                    4 2026-06-08 04:38:18 2026-06-08 05:03:14  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_1_seq_4.OMF.728553E2

                   1                    5 2026-06-08 05:03:13 2026-06-08 05:08:01  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_1_seq_5.OMF.12A8C0FB

                   1                    6 2026-06-08 05:08:01 2026-06-08 05:08:28  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_1_seq_6.OMF.2E95EB33

                   1                    7 2026-06-08 05:08:28 2026-06-08 05:33:17  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_1_seq_7.OMF.42B09783

                   1                    8 2026-06-08 05:33:16 2026-06-08 05:48:49  NO                     0 crashdr
                   1                    8 2026-06-08 05:33:16 2026-06-08 05:48:47  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_1_seq_8.OMF.2A28F3D0

                   1                    9 2026-06-08 05:48:46 2026-06-08 05:49:08  NO                     0 crashdr
                   1                    9 2026-06-08 05:48:46 2026-06-08 05:49:08  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_1_seq_9.OMF.7DEB4BB9

                   1                   10 2026-06-08 05:49:07 2026-06-08 06:03:13  NO                     0 crashdr
                   1                   10 2026-06-08 05:49:07 2026-06-08 06:03:13  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_1_seq_10.OMF.1E8064E3

                   1                   11 2026-06-08 06:03:13 2026-06-08 06:33:14  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_1_seq_11.OMF.05B6F797

                   1                   11 2026-06-08 06:03:13 2026-06-08 06:33:14  NO                     0 crashdr
                   1                   12 2026-06-08 06:33:14 2026-06-08 07:03:14  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_1_seq_12.OMF.65C14994

                   1                   12 2026-06-08 06:33:14 2026-06-08 07:03:14  NO                     0 crashdr
                   1                   13 2026-06-08 07:03:14 2026-06-08 07:33:20  NO                     0 crashdr
                   1                   13 2026-06-08 07:03:14 2026-06-08 07:33:20  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_1_seq_13.OMF.062F790F

                   1                   14 2026-06-08 07:33:20 2026-06-08 08:03:14  NO                     0 crashdr
                   1                   14 2026-06-08 07:33:20 2026-06-08 08:03:15  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_1_seq_14.OMF.1F2ACC05

                   1                   15 2026-06-08 08:03:14 2026-06-08 08:33:15  NO                     0 crashdr
                   1                   15 2026-06-08 08:03:14 2026-06-08 08:33:15  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_1_seq_15.OMF.1245AE91

                   1                   16 2026-06-08 08:33:14 2026-06-08 08:42:25  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_1_seq_16.OMF.56A3E20E

                   1                   16 2026-06-08 08:33:14 2026-06-08 08:42:25  NO                     0 crashdr
                   1                   17 2026-06-08 08:42:25 2026-06-08 08:42:59  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_1_seq_17.OMF.4607A176

                   1                   17 2026-06-08 08:42:25 2026-06-08 08:43:00  NO                     0 crashdr
                   1                   18 2026-06-08 08:42:59 2026-06-08 08:42:59  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_1_seq_18.OMF.737F99D0

                   1                   18 2026-06-08 08:42:59 2026-06-08 08:43:00  NO                     0 crashdr
                   2                    1 2026-06-08 04:28:51 2026-06-08 04:28:55  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_2_seq_1.OMF.32D33AAC

                   2                    2 2026-06-08 04:30:55 2026-06-08 04:37:47  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_2_seq_2.OMF.2CE992D5

                   2                    3 2026-06-08 04:38:17 2026-06-08 05:03:13  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_2_seq_3.OMF.640B513E

                   2                    4 2026-06-08 05:03:13 2026-06-08 05:08:02  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_2_seq_4.OMF.6CF5C155

                   2                    5 2026-06-08 05:08:01 2026-06-08 05:08:27  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_2_seq_5.OMF.3677815F

                   2                    6 2026-06-08 05:08:27 2026-06-08 05:33:16  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_2_seq_6.OMF.4C56D338

                   2                    7 2026-06-08 05:33:16 2026-06-08 05:48:49  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_2_seq_7.OMF.489BC808

                   2                    7 2026-06-08 05:33:16 2026-06-08 05:48:49  NO                     0 crashdr
                   2                    8 2026-06-08 05:48:49 2026-06-08 05:49:07  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_2_seq_8.OMF.2771ACC8

                   2                    8 2026-06-08 05:48:49 2026-06-08 05:49:07  NO                     0 crashdr
                   2                    9 2026-06-08 05:49:07 2026-06-08 06:03:16  NO                     0 crashdr
                   2                    9 2026-06-08 05:49:07 2026-06-08 06:03:16  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_2_seq_9.OMF.5E0D28FE

                   2                   10 2026-06-08 06:03:16 2026-06-08 06:33:13  NO                     0 crashdr
                   2                   10 2026-06-08 06:03:16 2026-06-08 06:33:13  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_2_seq_10.OMF.52F3E0A5

                   2                   11 2026-06-08 06:33:13 2026-06-08 07:03:13  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_2_seq_11.OMF.4E45627C

                   2                   11 2026-06-08 06:33:13 2026-06-08 07:03:13  NO                     0 crashdr
                   2                   12 2026-06-08 07:03:13 2026-06-08 07:33:19  NO                     0 crashdr
                   2                   12 2026-06-08 07:03:13 2026-06-08 07:33:20  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_2_seq_12.OMF.16719152

                   2                   13 2026-06-08 07:33:19 2026-06-08 08:03:14  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_2_seq_13.OMF.26C024E0

                   2                   13 2026-06-08 07:33:19 2026-06-08 08:03:14  NO                     0 crashdr
                   2                   14 2026-06-08 08:03:13 2026-06-08 08:33:15  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_2_seq_14.OMF.2F347FFE

                   2                   14 2026-06-08 08:03:13 2026-06-08 08:33:14  NO                     0 crashdr
                   2                   15 2026-06-08 08:33:14 2026-06-08 08:42:27  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_2_seq_15.OMF.0A17ADF7

                   2                   15 2026-06-08 08:33:14 2026-06-08 08:42:26  NO                     0 crashdr
                   2                   16 2026-06-08 08:42:26 2026-06-08 08:42:59  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_2_seq_16.OMF.4BEE5D3E

                   2                   16 2026-06-08 08:42:26 2026-06-08 08:42:59  NO                     0 crashdr
                   2                   17 2026-06-08 08:42:59 2026-06-08 08:43:02  NO                     1 @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFF
                                                                                                            C46A6348A21A9F/CRASHRDB/ARCHIVELOG/202
                                                                                                            6_06_08/thread_2_seq_17.OMF.7BEC3328

                   2                   17 2026-06-08 08:42:59 2026-06-08 08:43:02  NO                     0 crashdr

56 rows selected.

## Unbacked Archived Redo Logs

             THREAD#            SEQUENCE# FIRST_TIME          COMPLETION_TIME      DEL         BACKUP_COUNT NAME
-------------------- -------------------- ------------------- -------------------- --- -------------------- --------------------------------------
                   2                    7 2026-06-08 05:33:16 2026-06-08 05:48:49  NO                     0 crashdr
                   1                    8 2026-06-08 05:33:16 2026-06-08 05:48:49  NO                     0 crashdr
                   2                    8 2026-06-08 05:48:49 2026-06-08 05:49:07  NO                     0 crashdr
                   1                    9 2026-06-08 05:48:46 2026-06-08 05:49:08  NO                     0 crashdr
                   1                   10 2026-06-08 05:49:07 2026-06-08 06:03:13  NO                     0 crashdr
                   2                    9 2026-06-08 05:49:07 2026-06-08 06:03:16  NO                     0 crashdr
                   2                   10 2026-06-08 06:03:16 2026-06-08 06:33:13  NO                     0 crashdr
                   1                   11 2026-06-08 06:03:13 2026-06-08 06:33:14  NO                     0 crashdr
                   2                   11 2026-06-08 06:33:13 2026-06-08 07:03:13  NO                     0 crashdr
                   1                   12 2026-06-08 06:33:14 2026-06-08 07:03:14  NO                     0 crashdr
                   2                   12 2026-06-08 07:03:13 2026-06-08 07:33:19  NO                     0 crashdr
                   1                   13 2026-06-08 07:03:14 2026-06-08 07:33:20  NO                     0 crashdr
                   2                   13 2026-06-08 07:33:19 2026-06-08 08:03:14  NO                     0 crashdr
                   1                   14 2026-06-08 07:33:20 2026-06-08 08:03:14  NO                     0 crashdr
                   2                   14 2026-06-08 08:03:13 2026-06-08 08:33:14  NO                     0 crashdr
                   1                   15 2026-06-08 08:03:14 2026-06-08 08:33:15  NO                     0 crashdr
                   1                   16 2026-06-08 08:33:14 2026-06-08 08:42:25  NO                     0 crashdr
                   2                   15 2026-06-08 08:33:14 2026-06-08 08:42:26  NO                     0 crashdr
                   2                   16 2026-06-08 08:42:26 2026-06-08 08:42:59  NO                     0 crashdr
                   1                   17 2026-06-08 08:42:25 2026-06-08 08:43:00  NO                     0 crashdr
                   1                   18 2026-06-08 08:42:59 2026-06-08 08:43:00  NO                     0 crashdr
                   2                   17 2026-06-08 08:42:59 2026-06-08 08:43:02  NO                     0 crashdr

22 rows selected.

## Backup Corruption Views

SOURCE_NAME                            ROW_COUNT
--------------------------- --------------------
V$DATABASE_BLOCK_CORRUPTION                    0
V$COPY_CORRUPTION                              0
V$BACKUP_CORRUPTION                            0

3 rows selected.

## Files Requiring Media Recovery

no rows selected

## FRA Usage

NAME                                         SPACE_LIMIT_GB        SPACE_USED_GB SPACE_RECLAIMABLE_GB      NUMBER_OF_FILES
-------------------------------------- -------------------- -------------------- -------------------- --------------------
@rJOnB8bM(RECO_HC_HIGHREDUNDANCY)                       240                16.56                   .4                   41

1 row selected.

## FRA Usage By File Type

FILE_TYPE                 PERCENT_SPACE_USED PERCENT_SPACE_RECLAIMABLE      NUMBER_OF_FILES
----------------------- -------------------- ------------------------- --------------------
ARCHIVED LOG                             .17                       .17                   34
AUXILIARY DATAFILE COPY                    0                         0                    0
BACKUP PIECE                             .14                         0                    2
CONTROL FILE                             .07                         0                    1
FLASHBACK LOG                           6.51                         0                    4
FOREIGN ARCHIVED LOG                       0                         0                    0
IMAGE COPY                                 0                         0                    0
REDO LOG                                   0                         0                    0

8 rows selected.

## Data Guard / RPO Adjacent Evidence

             DEST_ID STATUS                   TARGET
-------------------- ------------------------ ----------------
DESTINATION
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DB_UNIQUE_NAME                 VALID_NOW        ERROR
------------------------------ ---------------- -----------------------------------------------------------------
                   1 VALID                    PRIMARY
USE_DB_RECOVERY_FILE_DEST
crashrdb                       YES

                   2 VALID                    STANDBY
crashdr
crashdr                        YES

                  10 ALTERNATE                PRIMARY
@rJOnB8bM
crashrdb                       UNKNOWN


3 rows selected.


no rows selected

```

## RMAN Repository, Restore Preview, Need-Backup, And Obsolete Report

Repository source requested: `target control file`

Command: `rman target / cmdfile=/tmp/crashsimulator/crashsimulator_logs/crashsim_backup_report_20260608_084918_repository.rman log=/tmp/crashsimulator/crashsimulator_logs/crashsim_backup_report_20260608_084918_repository.log`

```text

Recovery Manager: Release 23.26.2.0.0 - Production on Mon Jun 8 08:49:22 2026
Version 23.26.2.0.0

Copyright (c) 1982, 2026, Oracle and/or its affiliates.  All rights reserved.

connected to target database: CRASHDB (DBID=1275206961)

RMAN> show all;
2> list backup summary;
3> list backup of database summary;
4> list backup of archivelog all summary;
5> list expired backup summary;
6> list expired archivelog all;
7> report schema;
8> report need backup;
9> report obsolete;
10> restore database preview summary;
11> exit;
using target database control file instead of recovery catalog
RMAN configuration parameters for database with db_unique_name CRASHRDB are:
CONFIGURE RETENTION POLICY TO NONE;
CONFIGURE BACKUP OPTIMIZATION OFF;
CONFIGURE DEFAULT DEVICE TYPE TO 'SBT_TAPE';
CONFIGURE CONTROLFILE AUTOBACKUP ON;
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE SBT_TAPE TO '%F'; # default
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '%F'; # default
CONFIGURE DEVICE TYPE 'SBT_TAPE' PARALLELISM 4 BACKUP TYPE TO COMPRESSED BACKUPSET;
CONFIGURE DEVICE TYPE DISK PARALLELISM 1 BACKUP TYPE TO BACKUPSET; # default
CONFIGURE DATAFILE BACKUP COPIES FOR DEVICE TYPE SBT_TAPE TO 1; # default
CONFIGURE DATAFILE BACKUP COPIES FOR DEVICE TYPE DISK TO 1; # default
CONFIGURE ARCHIVELOG BACKUP COPIES FOR DEVICE TYPE SBT_TAPE TO 1; # default
CONFIGURE ARCHIVELOG BACKUP COPIES FOR DEVICE TYPE DISK TO 1; # default
CONFIGURE CHANNEL DEVICE TYPE 'SBT_TAPE' FORMAT   '%d_%I_%U_%T_%t' PARMS  "SBT_LIBRARY=/u02/app/oracle/product/23.0.0.0/dbhome_1/lib/libra.so, ENV=(RA_WALLET='location=file:/var/opt/oracle/dbaas_acfs/crashdb/wallet_root/server_seps credential_alias=DBRS',RA_FORMAT=TRUE)";
CONFIGURE MAXSETSIZE TO UNLIMITED; # default
CONFIGURE ENCRYPTION FOR DATABASE ON;
CONFIGURE ENCRYPTION ALGORITHM 'AES256';
CONFIGURE COMPRESSION ALGORITHM 'low' AS OF RELEASE 'DEFAULT' OPTIMIZE FOR LOAD TRUE;
CONFIGURE DB_UNIQUE_NAME 'crashrdb' CONNECT IDENTIFIER  'crashrdb';
CONFIGURE DB_UNIQUE_NAME 'crashdr' CONNECT IDENTIFIER  'crashdr';
CONFIGURE RMAN OUTPUT TO KEEP FOR 7 DAYS; # default
CONFIGURE ARCHIVELOG DELETION POLICY TO NONE; # default
CONFIGURE SNAPSHOT CONTROLFILE NAME TO '@rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/CONTROLFILE/snapcf_crashdb.f';


List of Backups
===============
Key     TY LV S Device Type Completion Time #Pieces #Copies Compressed Tag
------- -- -- - ----------- --------------- ------- ------- ---------- ---
1       B  F  A DISK        08-JUN-26       1       1       NO         TAG20260608T044807
2       B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T050315
3       B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T050315
4       B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T050315
5       B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T050315
6       B  F  A SBT_TAPE    08-JUN-26       1       1       YES        TAG20260608T050325
7       B  A  A SBT_TAPE    08-JUN-26       1       1       YES        DBTREGULAR-L01780893614915AEJ
8       B  A  A SBT_TAPE    08-JUN-26       1       1       YES        DBTREGULAR-L01780893614915AEJ
9       B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
10      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
11      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
12      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
13      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
14      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
15      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
16      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
17      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
18      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
19      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
20      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
21      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
22      B  A  A SBT_TAPE    08-JUN-26       1       1       YES        DBTREGULAR-L01780893614915AEJ
23      B  A  A SBT_TAPE    08-JUN-26       1       1       YES        DBTREGULAR-L01780893614915AEJ
24      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        TAG20260608T050833
25      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T053318
26      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T053318
27      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        TAG20260608T053322
28      B  F  A DISK        08-JUN-26       1       1       NO         TAG20260608T055310
29      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T060318
30      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T060318
31      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T060318
32      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T060318
33      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        TAG20260608T060323
34      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T063316
35      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T063316
36      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        TAG20260608T063321
37      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T070316
38      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T070316
39      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        TAG20260608T070321
40      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T073321
41      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T073321
42      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        TAG20260608T073326
43      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T080317
44      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T080317
45      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        TAG20260608T080322
46      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T083316
47      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T083316
48      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        TAG20260608T083321
49      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
50      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
51      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
52      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
53      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
54      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
55      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
56      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
57      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
58      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
59      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
60      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        TAG20260608T084253
61      B  A  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223_ARCH
62      B  A  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223_ARCH
63      B  A  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223_ARCH
64      B  A  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223_ARCH
65      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223_CTL
66      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223_SPFILE
67      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        TAG20260608T084314


List of Backups
===============
Key     TY LV S Device Type Completion Time #Pieces #Copies Compressed Tag
------- -- -- - ----------- --------------- ------- ------- ---------- ---
9       B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
10      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
11      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
12      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
13      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
14      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
15      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
16      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
17      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
18      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
19      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
20      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
21      B  0  A SBT_TAPE    08-JUN-26       1       1       NO         DBTREGULAR-L01780893614915AEJ
49      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
50      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
51      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
52      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
53      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
54      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
55      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
56      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
57      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
58      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223
59      B  F  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223


List of Backups
===============
Key     TY LV S Device Type Completion Time #Pieces #Copies Compressed Tag
------- -- -- - ----------- --------------- ------- ------- ---------- ---
2       B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T050315
3       B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T050315
4       B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T050315
5       B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T050315
7       B  A  A SBT_TAPE    08-JUN-26       1       1       YES        DBTREGULAR-L01780893614915AEJ
8       B  A  A SBT_TAPE    08-JUN-26       1       1       YES        DBTREGULAR-L01780893614915AEJ
22      B  A  A SBT_TAPE    08-JUN-26       1       1       YES        DBTREGULAR-L01780893614915AEJ
23      B  A  A SBT_TAPE    08-JUN-26       1       1       YES        DBTREGULAR-L01780893614915AEJ
25      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T053318
26      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T053318
29      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T060318
30      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T060318
31      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T060318
32      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T060318
34      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T063316
35      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T063316
37      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T070316
38      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T070316
40      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T073321
41      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T073321
43      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T080317
44      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T080317
46      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T083316
47      B  A  A SBT_TAPE    08-JUN-26       1       1       NO         TAG20260608T083316
61      B  A  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223_ARCH
62      B  A  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223_ARCH
63      B  A  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223_ARCH
64      B  A  A SBT_TAPE    08-JUN-26       1       1       YES        CSIM_BASE_260608084223_ARCH

specification does not match any backup in the repository

specification does not match any archived log in the repository

Report of database schema for database with db_unique_name CRASHRDB

List of Permanent Datafiles
===========================
File Size(MB) Tablespace           RB segs Datafile Name
---- -------- -------------------- ------- ------------------------
1    2000     SYSTEM               YES     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/SYSTEM.OMF.70DAA345
2    600      PDB$SEED:SYSTEM      NO      @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/5096C84B7BB5210CE0636C0DF40A1151/DATAFILE/SYSTEM.OMF.3BED3E82
3    2000     SYSAUX               NO      @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/SYSAUX.OMF.45447F4E
4    600      PDB$SEED:SYSAUX      NO      @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/5096C84B7BB5210CE0636C0DF40A1151/DATAFILE/SYSAUX.OMF.7122AC18
5    2000     UNDOTBS1             YES     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/UNDOTBS1.OMF.5CF22136
6    600      PDB$SEED:UNDOTBS1    NO      @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/5096C84B7BB5210CE0636C0DF40A1151/DATAFILE/UNDOTBS1.OMF.1F3606C1
7    1024     USERS                NO      @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/USERS.OMF.6CA6D570
8    2000     UNDOTBS2             YES     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/UNDOTBS2.OMF.55ECD93B
9    600      CRASHPDB:SYSTEM      YES     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/SYSTEM.OMF.49D473E6
10   600      CRASHPDB:SYSAUX      NO      @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/SYSAUX.OMF.5B8C6142
11   600      CRASHPDB:UNDOTBS1    YES     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/UNDOTBS1.OMF.79BB15E3
12   95       CRASHPDB:UNDO_4      YES     @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/UNDO_4.OMF.7FD1842F
13   1024     CRASHPDB:USERS       NO      @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/USERS.OMF.7A32E8B8
14   16       CRASHSIM_ROOT_RO_TBS NO      @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/CRASHSIM_ROOT_RO_TBS.OMF.28790F18
15   16       CRASHSIM_ROOT_INDEX_TBS NO      @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/CRASHSIM_ROOT_INDEX_TBS.OMF.15484A11
16   16       CRASHPDB:CRASHSIM_RO_TBS NO      @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/CRASHSIM_RO_TBS.OMF.3653F3F1
17   16       CRASHPDB:CRASHSIM_INDEX_TBS NO      @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/CRASHSIM_INDEX_TBS.OMF.4F7C5839

List of Temporary Files
=======================
File Size(MB) Tablespace           Maxsize(MB) Tempfile Name
---- -------- -------------------- ----------- --------------------
1    17408    TEMP                 524288      @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/TEMPFILE/TEMP.OMF.6CE4F0B7
2    5096     PDB$SEED:TEMP        33554431    @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/5096C84B7BB5210CE0636C0DF40A1151/DATAFILE/temp012026-06-08_04-20-55-817-AM.dbf
4    1024     CRASHPDB:TEMP        33554431    @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/TEMPFILE/TEMP.OMF.7E47A0BB

RMAN-00571: ===========================================================
RMAN-00569: =============== ERROR MESSAGE STACK FOLLOWS ===============
RMAN-00571: ===========================================================
RMAN-03002: failure of report command at 06/08/2026 08:49:26
RMAN-06525: RMAN retention policy is set to none
RMAN Client Diagnostic Trace file : /u02/app/oracle/diag/clients/user_oracle/RMAN_1488713457_116/trace/ora_rman_194066_0.trc

Recovery Manager complete.

[command exited with status 1]
```

## RMAN Deep Validation

Skipped by default. Re-run with `--deep-validate` or set `CRASHSIM_REPORT_DEEP_VALIDATE=1` to run `RESTORE DATABASE VALIDATE`, `RESTORE ARCHIVELOG ALL VALIDATE`, and `VALIDATE DATABASE CHECK LOGICAL`. Those checks are read-only but can be I/O intensive, especially for SBT/Object Storage.

## References

- Oracle Database 19c backup and recovery administration: https://docs.oracle.com/en/database/oracle/oracle-database/19/admqs/performing-backup-and-recovery.html
- Oracle Maximum Availability Architecture overview: https://www.oracle.com/database/technologies/maximum-availability-architecture/
- CrashSimulator RTO/RPO planning reference: https://oraclemaa.com/from-downtime-to-data-loss-getting-rto-and-rpo-right-for-high-availability-and-disaster-recovery

## Raw Backup Evidence

Evidence file: `/tmp/crashsimulator/crashsimulator_logs/crashsim_backup_report_20260608_084918.evidence`

```text
CSIM_BKP|db_name|CRASHDB
CSIM_BKP|db_unique_name|crashrdb
CSIM_BKP|dbid|1275206961
CSIM_BKP|database_role|PRIMARY
CSIM_BKP|open_mode|READ WRITE
CSIM_BKP|cdb|YES
CSIM_BKP|log_mode|ARCHIVELOG
CSIM_BKP|force_logging|YES
CSIM_BKP|flashback_on|YES
CSIM_BKP|platform_name|Linux x86 64-bit
CSIM_BKP|control_file_record_keep_time|7
CSIM_BKP|archive_lag_target|0
CSIM_BKP|db_recovery_file_dest|@rJOnB8bM(RECO_HC_HIGHREDUNDANCY)
CSIM_BKP|rman_retention_policy|TO NONE
CSIM_BKP|rman_controlfile_autobackup|ON
CSIM_BKP|rman_backup_optimization|OFF
CSIM_BKP|rman_encryption|ON
CSIM_BKP|rman_compression|'low' AS OF RELEASE 'DEFAULT' OPTIMIZE FOR LOAD TRUE
CSIM_BKP|rman_channel_config_count|1
CSIM_BKP|datafile_count|17
CSIM_BKP|tempfile_count|3
CSIM_BKP|database_size_gb|13.48
CSIM_BKP|datafile_copy_count|3
CSIM_BKP|datafiles_without_backup_metadata|0
CSIM_BKP|oldest_datafile_backup_time|2026-06-08 08:42:31
CSIM_BKP|last_datafile_backup_time|2026-06-08 08:43:18
CSIM_BKP|last_datafile_backup_age_hours|.1
CSIM_BKP|last_level0_backup_time|2026-06-08 08:43:18
CSIM_BKP|last_level0_backup_age_hours|.1
CSIM_BKP|last_level1_backup_time|NONE
CSIM_BKP|last_level1_backup_age_hours|UNKNOWN
CSIM_BKP|level0_count_30d|38
CSIM_BKP|level1_count_30d|0
CSIM_BKP|level0_avg_gap_hours|.1
CSIM_BKP|level1_avg_gap_hours|UNKNOWN
CSIM_BKP|successful_jobs_7d|10
CSIM_BKP|failed_jobs_7d|0
CSIM_BKP|successful_jobs_30d|10
CSIM_BKP|failed_jobs_30d|0
CSIM_BKP|last_successful_job_time|2026-06-08 08:43:21
CSIM_BKP|last_successful_job_age_hours|.1
CSIM_BKP|backup_device_types|SBT_TAPE
CSIM_BKP|avg_successful_job_elapsed_minutes_30d|.4
CSIM_BKP|max_successful_job_elapsed_minutes_30d|.9
CSIM_BKP|archivelog_backup_sets_30d|28
CSIM_BKP|last_archivelog_backup_time|2026-06-08 08:43:03
CSIM_BKP|last_archivelog_backup_age_hours|.1
CSIM_BKP|archivelog_backup_avg_gap_hours|.2
CSIM_BKP|archivelogs_known_7d|56
CSIM_BKP|archivelogs_not_backed_7d|22
CSIM_BKP|oldest_unbacked_archivelog_time|2026-06-08 05:48:49
CSIM_BKP|oldest_unbacked_archivelog_age_hours|3
CSIM_BKP|latest_archivelog_time|2026-06-08 08:43:02
CSIM_BKP|controlfile_backup_count_30d|14
CSIM_BKP|last_controlfile_backup_time|2026-06-08 08:43:18
CSIM_BKP|last_controlfile_backup_age_hours|.1
CSIM_BKP|backup_piece_available_count|67
CSIM_BKP|backup_piece_expired_count|0
CSIM_BKP|backup_piece_deleted_count|0
CSIM_BKP|backup_piece_unavailable_count|0
CSIM_BKP|latest_backup_piece_time|2026-06-08 08:43:19
CSIM_BKP|backup_piece_device_types|DISK,SBT_TAPE
CSIM_BKP|recover_file_count|0
CSIM_BKP|block_corruption_count|0
CSIM_BKP|copy_corruption_count|0
CSIM_BKP|backup_corruption_count|0
CSIM_BKP|fra_configured|YES
CSIM_BKP|fra_used_pct|6.9
CSIM_BKP|fra_reclaimable_pct|.17
CSIM_BKP|remote_standby_dest_count|1
CSIM_BKP|valid_remote_standby_dest_count|1
CSIM_BKP|standby_dest_error_count|0
CSIM_BKP|archive_gap_count|0
CSIM_BKP|dataguard_transport_lag|UNKNOWN
CSIM_BKP|dataguard_apply_lag|UNKNOWN
```
