whenever sqlerror exit sql.sqlcode
set pages 500 lines 260 trimspool on tab off verify off feedback on
set numwidth 20
column name format a34
column value format a120
column display_value format a120
column file_name format a150
column member format a150
column destination format a120
column error format a120
column handle format a120
column path format a150
column pdb_name format a30
column tablespace_name format a30
column parameter_name format a42
column start_time format a20
column end_time format a20
column completion_time format a20

prompt # SQL Evidence
prompt
prompt ## Database Identity
select name, db_unique_name, dbid, platform_name, database_role, open_mode,
       cdb, log_mode, force_logging, flashback_on, protection_mode,
       switchover_status
from v$database;

prompt ## Instance Identity
select instance_name, host_name, version, status, database_status, active_state,
       parallel, thread#, archiver, to_char(startup_time, 'YYYY-MM-DD HH24:MI:SS') startup_time
from v$instance;

prompt ## Database Version
select banner_full from v$version where banner_full like 'Oracle Database%';

prompt ## Key Paths And Parameters
select name, display_value
from v$parameter
where name in (
  'spfile',
  'control_files',
  'db_name',
  'db_unique_name',
  'db_recovery_file_dest',
  'db_recovery_file_dest_size',
  'db_create_file_dest',
  'db_create_online_log_dest_1',
  'db_create_online_log_dest_2',
  'diagnostic_dest',
  'audit_file_dest',
  'adg_redirect_dml',
  'compatible',
  'cluster_database',
  'remote_login_passwordfile',
  'enable_pluggable_database',
  'local_undo_enabled',
  'wallet_root',
  'tde_configuration'
)
order by name;

prompt ## Non-Default Database Parameters
select name parameter_name, type, isdefault, ismodified, issys_modifiable, ispdb_modifiable, display_value
from v$parameter
where isdefault = 'FALSE'
order by name;

prompt ## Diagnostic And Trace Locations
select name, value from v$diag_info order by name;

prompt ## Control Files
select name from v$controlfile order by name;

prompt ## Redo Log Groups
select l.group#, l.thread#, l.sequence#, round(l.bytes/1024/1024,2) size_mb,
       l.blocksize, l.members, l.archived, l.status
from v$log l
order by l.thread#, l.group#;

prompt ## Redo Log Members
select lf.group#, l.thread#, l.status, lf.type, lf.is_recovery_dest_file, lf.member
from v$logfile lf
join v$log l on l.group# = lf.group#
order by lf.group#, lf.member;

prompt ## Database Size Summary
select 'DATAFILES' component, count(*) file_count, round(sum(bytes)/1024/1024/1024,2) size_gb
from v$datafile
union all
select 'TEMPFILES' component, count(*) file_count, round(nvl(sum(bytes),0)/1024/1024/1024,2) size_gb
from v$tempfile
union all
select 'ONLINE REDO' component, count(*) file_count, round(nvl(sum(bytes),0)/1024/1024/1024,2) size_gb
from v$log;

prompt ## SYSTEM And UNDO Datafiles
select df.file#, ts.name tablespace_name,
       case when ts.name = 'SYSTEM' then 'SYSTEM'
            when ts.name like 'UNDO%' then 'UNDO'
            else 'OTHER'
       end tablespace_class,
       round(df.bytes/1024/1024,2) size_mb,
       df.status, df.enabled, df.name file_name
from v$datafile df
join v$tablespace ts on ts.ts# = df.ts# and ts.con_id = df.con_id
where ts.name = 'SYSTEM'
   or ts.name like 'UNDO%'
order by df.con_id, df.file#;

prompt ## Temporary Files
select tf.file#, ts.name tablespace_name, round(tf.bytes/1024/1024,2) size_mb,
       tf.status, tf.enabled, tf.name file_name
from v$tempfile tf
join v$tablespace ts on ts.ts# = tf.ts# and ts.con_id = tf.con_id
order by tf.con_id, tf.file#;

prompt ## FRA Destination And Usage
select name, round(space_limit/1024/1024/1024,2) space_limit_gb,
       round(space_used/1024/1024/1024,2) space_used_gb,
       round(space_reclaimable/1024/1024/1024,2) space_reclaimable_gb,
       number_of_files
from v$recovery_file_dest;

prompt ## FRA Usage By File Type
select file_type, percent_space_used, percent_space_reclaimable, number_of_files
from v$flash_recovery_area_usage
order by file_type;

prompt ## RMAN Configuration
select name, value from v$rman_configuration order by name;

prompt ## Recent RMAN Backup Jobs
select *
from (
  select session_key, input_type, status,
         to_char(start_time, 'YYYY-MM-DD HH24:MI:SS') start_time,
         to_char(end_time, 'YYYY-MM-DD HH24:MI:SS') end_time,
         elapsed_seconds, output_device_type, input_bytes_display, output_bytes_display
  from v$rman_backup_job_details
  order by start_time desc
)
where rownum <= 40;

prompt ## Backup Set Summary
select *
from (
  select recid backup_set_recid, set_stamp, set_count, backup_type,
         incremental_level, controlfile_included, pieces piece_count,
         to_char(start_time, 'YYYY-MM-DD HH24:MI:SS') start_time,
         to_char(completion_time, 'YYYY-MM-DD HH24:MI:SS') completion_time
  from v$backup_set
  order by completion_time desc
)
where rownum <= 60;

prompt ## Observed Backup Methodology From RMAN History
select nvl(input_type, 'UNKNOWN') input_type, status, count(*) job_count,
       to_char(min(start_time), 'YYYY-MM-DD HH24:MI:SS') first_observed,
       to_char(max(start_time), 'YYYY-MM-DD HH24:MI:SS') last_observed
from v$rman_backup_job_details
where start_time >= sysdate - 60
group by input_type, status
order by input_type, status;

prompt ## Datafile Backup Coverage
select df.file#, df.name file_name,
       to_char(max(bdf.completion_time), 'YYYY-MM-DD HH24:MI:SS') last_backup_time,
       case when max(bdf.completion_time) is null then 'NO BACKUP IN CONTROL FILE METADATA'
            else 'BACKUP METADATA FOUND'
       end backup_status
from v$datafile df
left join v$backup_datafile bdf on bdf.file# = df.file#
group by df.file#, df.name
order by df.file#;

prompt ## Backup Piece Status
select status, device_type, count(*) piece_count,
       to_char(max(completion_time), 'YYYY-MM-DD HH24:MI:SS') latest_completion
from v$backup_piece
group by status, device_type
order by status, device_type;

prompt ## Recoverability Indicators
select file#, checkpoint_change#, to_char(checkpoint_time, 'YYYY-MM-DD HH24:MI:SS') checkpoint_time,
       unrecoverable_change#, to_char(unrecoverable_time, 'YYYY-MM-DD HH24:MI:SS') unrecoverable_time,
       name
from v$datafile
order by file#;

prompt ## Files Requiring Media Recovery
select * from v$recover_file order by file#;

prompt ## Database Block Corruption
select * from v$database_block_corruption order by file#, block#;

prompt ## Copy Corruption
select * from v$copy_corruption order by file#, block#;

prompt ## Backup Corruption
select * from v$backup_corruption order by file#, block#;

prompt ## Restore Points
select name, scn, time, database_incarnation#, guarantee_flashback_database, storage_size
from v$restore_point
order by time desc;

prompt ## Data Guard Role And FSFO Columns
select database_role, protection_mode, protection_level, switchover_status,
       fs_failover_status, fs_failover_current_target,
       fs_failover_threshold, fs_failover_observer_present
from v$database;

prompt ## Data Guard Destinations
select dest_id, status, target, destination, db_unique_name, valid_now, error
from v$archive_dest
where destination is not null
order by dest_id;

prompt ## Archive Gaps
select * from v$archive_gap;

prompt ## Data Guard Stats
select name, value, unit, time_computed, datum_time
from v$dataguard_stats
order by name;

prompt ## TDE Wallet Status
select * from v$encryption_wallet;

prompt ## Encrypted Tablespaces
select tablespace_name, encrypted
from dba_tablespaces
where encrypted = 'YES'
order by tablespace_name;

prompt ## Encrypted Columns
select owner, table_name, count(*) encrypted_column_count
from dba_encrypted_columns
group by owner, table_name
order by owner, table_name;

prompt ## PDB State And Size
select p.name pdb_name, p.con_id, p.open_mode, p.restricted,
       round(p.total_size/1024/1024/1024,2) total_size_gb,
       to_char(p.open_time, 'YYYY-MM-DD HH24:MI:SS') open_time
from v$pdbs p
order by p.con_id;

prompt ## Datafile Count And Size By Container
select c.name pdb_name, c.con_id, count(df.file#) datafile_count,
       round(nvl(sum(df.bytes),0)/1024/1024/1024,2) datafile_gb,
       round(nvl(tf.temp_bytes,0)/1024/1024/1024,2) tempfile_gb
from v$containers c
left join v$datafile df on df.con_id = c.con_id
left join (
  select con_id, sum(bytes) temp_bytes
  from v$tempfile
  group by con_id
) tf on tf.con_id = c.con_id
group by c.name, c.con_id, tf.temp_bytes
order by c.con_id;

prompt ## Tablespaces By Container
select p.name pdb_name, t.tablespace_name, t.contents, t.status, t.bigfile,
       t.logging, t.extent_management, t.allocation_type, t.segment_space_management,
       round(nvl(df.bytes,0)/1024/1024,2) data_mb,
       round(nvl(tf.bytes,0)/1024/1024,2) temp_mb
from cdb_tablespaces t
join v$containers p on p.con_id = t.con_id
left join (
  select con_id, tablespace_name, sum(bytes) bytes
  from cdb_data_files
  group by con_id, tablespace_name
) df on df.con_id = t.con_id and df.tablespace_name = t.tablespace_name
left join (
  select con_id, tablespace_name, sum(bytes) bytes
  from cdb_temp_files
  group by con_id, tablespace_name
) tf on tf.con_id = t.con_id and tf.tablespace_name = t.tablespace_name
order by p.con_id, t.tablespace_name;

prompt ## Datafiles By Container
select p.name pdb_name, df.file_id, df.tablespace_name,
       round(df.bytes/1024/1024,2) size_mb, df.status, df.online_status,
       df.autoextensible, df.file_name
from cdb_data_files df
join v$containers p on p.con_id = df.con_id
order by p.con_id, df.file_id;

prompt ## Tempfiles By Container
select p.name pdb_name, tf.file_id, tf.tablespace_name,
       round(tf.bytes/1024/1024,2) size_mb, tf.status, tf.autoextensible, tf.file_name
from cdb_temp_files tf
join v$containers p on p.con_id = tf.con_id
order by p.con_id, tf.file_id;

prompt ## Encrypted Tablespaces By Container
select p.name pdb_name, t.tablespace_name, t.encrypted
from cdb_tablespaces t
join v$containers p on p.con_id = t.con_id
where t.encrypted = 'YES'
order by p.con_id, t.tablespace_name;

exit
