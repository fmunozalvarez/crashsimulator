whenever sqlerror exit sql.sqlcode
set serveroutput on size unlimited feedback on timing on pages 100 lines 220
alter session set container = CRASHPDB;
prompt TEMP usage before controlled pressure
select tablespace, round(sum(blocks * 8192)/1024/1024, 2) used_mb
from v$tempseg_usage
group by tablespace
order by tablespace;
declare
  l_rows number := 178957;
  l_mb number := 512;
begin
  begin
    execute immediate 'drop table crashsim_temp_pressure purge';
  exception
    when others then
      if sqlcode != -942 then
        raise;
      end if;
  end;

  execute immediate 'create global temporary table crashsim_temp_pressure (id number, payload varchar2(4000)) on commit preserve rows';
  dbms_output.put_line('Attempting controlled TEMP pressure: approximately ' || l_mb || ' MB using ' || l_rows || ' rows.');

  begin
    insert into crashsim_temp_pressure
    select level, rpad('X', 3000, 'X')
    from dual
    connect by level <= l_rows
    order by dbms_random.value;
    dbms_output.put_line('TEMP pressure workload completed without ORA-01652. Increase --temp-exhaust-mb for a stronger lab drill.');
  exception
    when others then
      if sqlcode = -1652 then
        dbms_output.put_line('Expected TEMP exhaustion symptom captured: ' || sqlerrm);
      else
        raise;
      end if;
  end;

  rollback;
  execute immediate 'drop table crashsim_temp_pressure purge';
end;
/
prompt TEMP usage after controlled pressure cleanup
select tablespace, round(sum(blocks * 8192)/1024/1024, 2) used_mb
from v$tempseg_usage
group by tablespace
order by tablespace;
exit
