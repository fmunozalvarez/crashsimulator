whenever sqlerror exit sql.sqlcode
set serveroutput on feedback on pages 100 lines 220
prompt FRA usage before pressure change
select name, space_limit, space_used, space_reclaimable, number_of_files
from v$recovery_file_dest;
alter system set db_recovery_file_dest_size=18141434776 scope=both;
prompt FRA usage after shrinking DB_RECOVERY_FILE_DEST_SIZE
select name, space_limit, space_used,
       round(space_used / nullif(space_limit, 0) * 100, 2) used_pct,
       space_reclaimable, number_of_files
from v$recovery_file_dest;
declare
begin
  execute immediate 'alter system archive log current';
  dbms_output.put_line('ARCHIVE LOG CURRENT completed. FRA pressure may not be high enough; lower headroom or generate more redo in a lab.');
exception
  when others then
    if sqlcode in (-19809, -19815, -16038, -257) then
      dbms_output.put_line('Expected FRA pressure symptom captured: ' || sqlerrm);
    else
      raise;
    end if;
end;
/
prompt Restore command for recovery helper
prompt alter system set db_recovery_file_dest_size=257698037760 scope=both;
exit
