# CrashSimulator Review Center

- Generated UTC: `2026-06-08T08:49:40Z`
- Log directory: `/tmp/crashsimulator/crashsimulator_logs`
- Audit directory: `/tmp/crashsimulator/crashsimulator_logs/audit`

This index lists previously collected CrashSimulator topology snapshots, scenario manifests, runbooks, dry-run/execution audit records, health checks, and reports. It does not reconnect to the database.

## Latest Collected Topology

- Latest topology artifact: `/tmp/crashsimulator/crashsimulator_logs/crashsim_topology_latest.txt`
- Latest configuration report: `/tmp/crashsimulator/crashsimulator_logs/crashsim_config_report_20260608_084856.md`
- Latest backup/recoverability report: `/tmp/crashsimulator/crashsimulator_logs/crashsim_backup_report_20260608_084918.md`
- Latest service HA review: `/tmp/crashsimulator/crashsimulator_logs/crashsim_service_review_20260608_084926.md`
- Latest scenario readiness report: `/tmp/crashsimulator/crashsimulator_logs/crashsim_scenario_readiness_latest.md`
- Latest scenario lifecycle coverage report: `/tmp/crashsimulator/crashsimulator_logs/crashsim_scenario_lifecycle_latest.md`
- Latest MAA readiness report: `/tmp/crashsimulator/crashsimulator_logs/crashsim_maa_report_20260608_084932.md`
- Latest health check: `/tmp/crashsimulator/crashsimulator_logs/crashsim_health_check_20260608_084618.log`

## Scenario / Protection / Recovery Manifests

No stored manifests found.

## Runbooks

No stored artifacts found.

## Health Checks

- `/tmp/crashsimulator/crashsimulator_logs/crashsim_health_check_20260608_084618.log`

## Configuration Reports

- `/tmp/crashsimulator/crashsimulator_logs/crashsim_config_report_20260608_084354.md`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_config_report_20260608_084856.md`

## Backup Strategy / Recoverability Reports

- `/tmp/crashsimulator/crashsimulator_logs/crashsim_backup_report_20260608_084412.md`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_backup_report_20260608_084918.md`

## Service HA Reviews

- `/tmp/crashsimulator/crashsimulator_logs/crashsim_service_review_20260608_084926.md`

## APEX / ORDS Readiness Reports

No stored artifacts found.

## Scenario Readiness Reports

- `/tmp/crashsimulator/crashsimulator_logs/crashsim_scenario_readiness_20260608_084558.md`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_scenario_readiness_20260608_084729.md`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_scenario_readiness_latest.md`

## Scenario Lifecycle Coverage Reports

- `/tmp/crashsimulator/crashsimulator_logs/crashsim_scenario_lifecycle_20260608_084616.md`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_scenario_lifecycle_latest.md`

## MAA Readiness Reports

- `/tmp/crashsimulator/crashsimulator_logs/crashsim_maa_report_20260608_084932.md`

## Baseline Backup Plans And Logs

- `/tmp/crashsimulator/crashsimulator_logs/crashsim_baseline_backup_20260608_084206.rman`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_baseline_backup_20260608_084223.log`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_baseline_backup_20260608_084223.rman`

## RMAN And SQL Helper Files

- `/tmp/crashsimulator/crashsimulator_logs/crashsim_backup_report_20260608_084412_detail.sql`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_backup_report_20260608_084412_evidence.sql`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_backup_report_20260608_084412_repository.rman`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_backup_report_20260608_084412_validate.rman`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_backup_report_20260608_084918_detail.sql`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_backup_report_20260608_084918_evidence.sql`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_backup_report_20260608_084918_repository.rman`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_baseline_backup_20260608_084206.rman`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_baseline_backup_20260608_084223.rman`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_config_report_20260608_084354.sql`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_config_report_20260608_084354_restore_preview.rman`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_config_report_20260608_084354_show_all.rman`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_config_report_20260608_084856.sql`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_config_report_20260608_084856_restore_preview.rman`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_config_report_20260608_084856_show_all.rman`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_maa_report_20260608_084932.sql`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_s61_20260608_084558_fra_pressure.sql`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_s61_20260608_084729_fra_pressure.sql`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_s62_20260608_084558_recovery_decision.rman`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_s62_20260608_084729_recovery_decision.rman`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_s63_20260608_084558_temp_exhaustion.sql`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_s63_20260608_084729_temp_exhaustion.sql`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_s69_20260608_084558_standby_redo_review.sql`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_s69_20260608_084729_standby_redo_review.sql`
- `/tmp/crashsimulator/crashsimulator_logs/crashsim_service_review_20260608_084926.sql`

## Audit Records

- `/tmp/crashsimulator/crashsimulator_logs/audit/2026-06-08/crashsim_audit_20260608_084354_150540` - mode `report`, started `2026-06-08T08:43:55Z`, exit `0`
  Command: `./CrashSimulatorV2.sh --config-report --html`
- `/tmp/crashsimulator/crashsimulator_logs/audit/2026-06-08/crashsim_audit_20260608_084412_154263` - mode `backup_report`, started `2026-06-08T08:44:12Z`, exit `0`
  Command: `./CrashSimulatorV2.sh --backup-report --deep-validate --html`
- `/tmp/crashsimulator/crashsimulator_logs/audit/2026-06-08/crashsim_audit_20260608_084558_163969` - mode `scenario_readiness_report`, started `2026-06-08T08:45:58Z`, exit `0`
  Command: `./CrashSimulatorV2.sh --scenario-readiness-report --pdb CRASHPDB --html`
- `/tmp/crashsimulator/crashsimulator_logs/audit/2026-06-08/crashsim_audit_20260608_084616_169431` - mode `scenario_lifecycle_report`, started `2026-06-08T08:46:16Z`, exit `0`
  Command: `./CrashSimulatorV2.sh --scenario-lifecycle-report --html`
- `/tmp/crashsimulator/crashsimulator_logs/audit/2026-06-08/crashsim_audit_20260608_084618_171181` - mode `health`, started `2026-06-08T08:46:18Z`, exit `0`
  Command: `./CrashSimulatorV2.sh --health-check`
- `/tmp/crashsimulator/crashsimulator_logs/audit/2026-06-08/crashsim_audit_20260608_084729_178825` - mode `scenario_readiness_report`, started `2026-06-08T08:47:29Z`, exit `0`
  Command: `./CrashSimulatorV2.sh --scenario-readiness-report --pdb CRASHPDB --html`
- `/tmp/crashsimulator/crashsimulator_logs/audit/2026-06-08/crashsim_audit_20260608_084856_191599` - mode `report`, started `2026-06-08T08:48:56Z`, exit `0`
  Command: `./CrashSimulatorV2.sh --config-report --html`
- `/tmp/crashsimulator/crashsimulator_logs/audit/2026-06-08/crashsim_audit_20260608_084918_193546` - mode `backup_report`, started `2026-06-08T08:49:18Z`, exit `0`
  Command: `./CrashSimulatorV2.sh --backup-report --html`
- `/tmp/crashsimulator/crashsimulator_logs/audit/2026-06-08/crashsim_audit_20260608_084926_194244` - mode `service_review`, started `2026-06-08T08:49:27Z`, exit `0`
  Command: `./CrashSimulatorV2.sh --service-review --html`
- `/tmp/crashsimulator/crashsimulator_logs/audit/2026-06-08/crashsim_audit_20260608_084932_194927` - mode `maa_report`, started `2026-06-08T08:49:32Z`, exit `0`
  Command: `./CrashSimulatorV2.sh --maa-report --html`

## Access Shortcuts

- Show latest topology: `./CrashSimulatorV2.sh --review-topology`
- Show latest scenario readiness report: `./CrashSimulatorV2.sh --show-artifact latest:scenario-readiness`
- Show latest scenario lifecycle report: `./CrashSimulatorV2.sh --show-artifact latest:lifecycle`
- Show latest health check: `./CrashSimulatorV2.sh --show-artifact latest:health`
- Generate HTML for latest review index: `./CrashSimulatorV2.sh --render-html latest:review`
- Generate HTML for a specific artifact: `./CrashSimulatorV2.sh --render-html /path/to/artifact`
