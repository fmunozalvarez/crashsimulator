# CrashSimulator Scenario Readiness Report

- Generated UTC: `2026-06-08T14:56:18Z`
- Tool version: `2.0.1-beta`
- Log directory: `/tmp/crashsimulator/crashsimulator_logs`
- Target PDB context: `CRASHPDB`
- Target schema context: `not set`
- Target FILE# context: `not set`

This report validates the discovered target environment against the CrashSimulator scenario registry. The same requirement checks, topology gates, target selection, and execution guardrails are used by scenario execution, so unavailable scenarios are blocked before destructive code runs.

> Historical reference note: this 2026-06-08 report was generated with the
> 2.0.1-beta 82-scenario registry. The current CrashSimulator catalog contains
> 123 scenarios: 103 database-host/application/platform scenarios plus 20
> Autonomous Database scenarios.

## Current Topology

| Signal | Value |
| --- | --- |
| Host | crashrac1-xnvfw |
| OS user | oracle |
| Oracle home | /u02/app/oracle/product/<ip-redacted>/dbhome_1 |
| SQL*Plus | /u02/app/oracle/product/<ip-redacted>/dbhome_1/bin/sqlplus |
| Database name | CRASHDB |
| DB unique name | crashrdb |
| Database role | PRIMARY |
| Open mode | READ WRITE |
| CDB | YES |
| Instance | exampledb1 |
| Thread | 1 |
| RAC parallel | YES |
| Cluster type | RAC |
| GI managed | 1 |
| Storage type | FEX |
| Protection mode | MAXIMUM PERFORMANCE |
| Switchover status | TO STANDBY |
| SPFILE | @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/PARAMETERFILE/spfile.OMF.37A52C57 |
| Password file | @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/PASSWORD/pwdCRASHRDB.4B81E94C |
| FRA | @rJOnB8bM(RECO_HC_HIGHREDUNDANCY) |

## PDBs

| PDB | CON_ID | Open mode |
| --- | --- | --- |
| CRASHPDB | 3 | READ WRITE |

## Readiness Summary

| Status | Count | Meaning |
| --- | ---: | --- |
| RUNNABLE | 24 | Scenario can be selected for dry-run and, when requested, execution. |
| PLAN-ONLY | 48 | Scenario can produce useful dry-run/runbook evidence, but execution is blocked by a guardrail or provider-specific limitation. |
| NOT-RUNNABLE | 10 | Scenario is not available in the current topology or target context. |
| TOTAL | 82 | Registered scenarios evaluated. |

## Runnable Scenarios

| ID | Group | Scope | Impact | Scenario | Reason |
| --- | --- | --- | --- | --- | --- |
| `11` | Logical | CDB/non-CDB | logical | Drop non-unique indexes outside Oracle schemas | Requirements passed and target selection produced executable actions. |
| `27` | Config | CDB/non-CDB | destructive | Loss of SQL*Net config files | Requirements passed and target selection produced executable actions. |
| `36` | PDB | PDB | logical | PDB drop non-unique indexes | Requirements passed and target selection produced executable actions. |
| `43` | PDB | PDB | logical | PDB loss of one user table | Requirements passed and target selection produced executable actions. |
| `44` | PDB | PDB | logical | PDB loss of one user schema | Requirements passed and target selection produced executable actions. |
| `51` | DataGuard | Primary | logical | Primary transport destination deferred | Requirements passed and target selection produced executable actions. |
| `55` | RAC | RAC | destructive | RAC abort one instance | Requirements passed and target selection produced executable actions. |
| `56` | RAC | RAC | logical | RAC service relocation failure practice | Requirements passed and target selection produced executable actions. |
| `57` | Network | CDB/non-CDB | destructive | Listener config unavailable | Requirements passed and target selection produced executable actions. |
| `58` | Security | CDB/non-CDB | destructive | TDE wallet or keystore unavailable | Requirements passed and target selection produced executable actions. |
| `60` | Backup | External | logical | Recovery catalog unavailable | Requirements passed and target selection produced executable actions. |
| `61` | Backup | CDB/non-CDB | destructive | FRA reaches critical utilization | Requirements passed and target selection produced executable actions. |
| `62` | Backup | CDB/non-CDB | destructive | Missing required archived log during recovery | Requirements passed and target selection produced executable actions. |
| `63` | Core | CDB/non-CDB | logical | TEMP tablespace exhaustion | Requirements passed and target selection produced executable actions. |
| `64` | Compliance | CDB/non-CDB | logical | RTO validation drill | Requirements passed and target selection produced executable actions. |
| `65` | Compliance | CDB/non-CDB | logical | RPO validation drill | Requirements passed and target selection produced executable actions. |
| `68` | DataGuard | Primary | logical | Data Guard transport network partition | Requirements passed and target selection produced executable actions. |
| `69` | DataGuard | DG | logical | Standby redo log misconfiguration review | Requirements passed and target selection produced executable actions. |
| `71` | RAC | RAC | logical | RAC service placement failure | Requirements passed and target selection produced executable actions. |
| `76` | APEX/ORDS | Application | logical | APEX/ORDS runtime account locked | Requirements passed and target selection produced executable actions. |
| `78` | APEX/ORDS | Application | logical | APEX application availability validation after recovery | Requirements passed and target selection produced executable actions. |
| `80` | APEX/ORDS | Application | logical | APEX session continuity test | Requirements passed and target selection produced executable actions. |
| `81` | APEX/ORDS | Application | logical | APEX mail queue and configuration validation | Requirements passed and target selection produced executable actions. |
| `82` | APEX/ORDS | Application | logical | APEX upgrade or patch rollback readiness | Requirements passed and target selection produced executable actions. |

## Dry-Run Planning Only

| ID | Group | Scope | Impact | Scenario | Reason |
| --- | --- | --- | --- | --- | --- |
| `1` | Core | CDB/non-CDB | destructive | Loss of one control file | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/CONTROLFILE/Current.OMF.713193E5 (FEX/ACFS managed storage handle requires provider-aware crash injection; this @... handle is not a local filesystem path) |
| `2` | Core | CDB/non-CDB | destructive | Loss of all control files | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/CONTROLFILE/Current.OMF.713193E5 (FEX/ACFS managed storage handle requires provider-aware crash injection; this @... handle is not a local filesystem path) |
| `3` | Core | CDB/non-CDB | destructive | Loss of one member from current redo group | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ONLINELOG/group_2.OMF.306D564A (FEX/ACFS managed storage handle requires provider-aware crash injection; this @... handle is not a local filesystem path) |
| `4` | Core | CDB/non-CDB | destructive | Loss of all members from current redo group | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ONLINELOG/group_2.OMF.306D564A (FEX/ACFS managed storage handle requires provider-aware crash injection; this @... handle is not a local filesystem path) |
| `5` | Core | CDB/non-CDB | destructive | Loss of one non-system datafile | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/USERS.OMF.6CA6D570 (FEX/ACFS managed storage handle requires provider-aware datafile loss injection; this @... handle is not a local filesystem path) |
| `6` | Core | CDB/non-CDB | destructive | Loss of one temporary file | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/TEMPFILE/TEMP.OMF.6CE4F0B7 (FEX/ACFS managed storage handle requires provider-aware tempfile loss injection; this @... handle is not a local filesystem path) |
| `7` | Core | CDB/non-CDB | destructive | Loss of one SYSTEM datafile | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/SYSTEM.OMF.70DAA345 (FEX/ACFS managed storage handle requires provider-aware datafile loss injection; this @... handle is not a local filesystem path) |
| `8` | Core | CDB/non-CDB | destructive | Loss of one UNDO datafile | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/UNDOTBS1.OMF.5CF22136 (FEX/ACFS managed storage handle requires provider-aware datafile loss injection; this @... handle is not a local filesystem path) |
| `9` | Core | CDB/non-CDB | destructive | Loss of a read-only tablespace | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/CRASHSIM_ROOT_RO_TBS.OMF.28790F18 (FEX/ACFS managed storage handle requires provider-aware datafile loss injection; this @... handle is not a local filesystem path) |
| `10` | Core | CDB/non-CDB | destructive | Loss of an index-only tablespace | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/CRASHSIM_ROOT_INDEX_TBS.OMF.15484A11 (FEX/ACFS managed storage handle requires provider-aware datafile loss injection; this @... handle is not a local filesystem path) |
| `12` | Core | CDB/non-CDB | destructive | Loss of a non-system tablespace | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/CRASHSIM_ROOT_INDEX_TBS.OMF.15484A11 (FEX/ACFS managed storage handle requires provider-aware datafile loss injection; this @... handle is not a local filesystem path) |
| `13` | Core | CDB/non-CDB | destructive | Loss of a temporary tablespace | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/TEMPFILE/TEMP.OMF.6CE4F0B7 (FEX/ACFS managed storage handle requires provider-aware tempfile loss injection; this @... handle is not a local filesystem path) |
| `14` | Core | CDB/non-CDB | destructive | Loss of SYSTEM tablespace | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/SYSTEM.OMF.70DAA345 (FEX/ACFS managed storage handle requires provider-aware datafile loss injection; this @... handle is not a local filesystem path) |
| `15` | Core | CDB/non-CDB | destructive | Loss of UNDO tablespace | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/UNDOTBS1.OMF.5CF22136 (FEX/ACFS managed storage handle requires provider-aware datafile loss injection; this @... handle is not a local filesystem path) |
| `16` | Config | CDB/non-CDB | destructive | Loss of password file | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/PASSWORD/pwdCRASHRDB.4B81E94C (FEX/ACFS managed storage handle requires provider-aware crash injection; this @... handle is not a local filesystem path) |
| `17` | Core | CDB/non-CDB | destructive | Loss of all datafiles | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/SYSTEM.OMF.70DAA345 (FEX/ACFS managed storage handle requires provider-aware datafile loss injection; this @... handle is not a local filesystem path) |
| `18` | Core | CDB/non-CDB | destructive | Loss of one member from multiplexed redo group | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ONLINELOG/group_1.OMF.4CE3B837 (FEX/ACFS managed storage handle requires provider-aware crash injection; this @... handle is not a local filesystem path) |
| `19` | Core | CDB/non-CDB | destructive | Loss of all inactive redo groups | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ONLINELOG/group_1.OMF.4CE3B837 (FEX/ACFS managed storage handle requires provider-aware crash injection; this @... handle is not a local filesystem path) |
| `20` | Core | CDB/non-CDB | destructive | Loss of all active redo groups | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ONLINELOG/group_2.OMF.306D564A (FEX/ACFS managed storage handle requires provider-aware crash injection; this @... handle is not a local filesystem path) |
| `21` | Core | CDB/non-CDB | destructive | Loss of all current redo group members | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ONLINELOG/group_2.OMF.306D564A (FEX/ACFS managed storage handle requires provider-aware crash injection; this @... handle is not a local filesystem path) |
| `22` | Corrupt | CDB/non-CDB | destructive | Datafile header corruption | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/DATAFILE/SYSTEM.OMF.70DAA345 (FEX/ACFS managed storage handle requires provider-aware header-corruption handling; this @... handle is not a local filesystem path) |
| `23` | Corrupt | CDB/non-CDB | destructive | Control file corruption | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/CONTROLFILE/Current.OMF.713193E5 (FEX/ACFS managed storage handle requires provider-aware corruption handling; this @... handle is not a local filesystem path) |
| `24` | Corrupt | CDB/non-CDB | destructive | Redo log corruption | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ONLINELOG/group_2.OMF.306D564A (FEX/ACFS managed storage handle requires provider-aware corruption handling; this @... handle is not a local filesystem path) |
| `25` | Backup | CDB/non-CDB | destructive | Loss of RMAN backup pieces | Scenario 25 can see local and object-storage backup handles; execution requires --piece-handle or --local-only --max-targets <n>. |
| `26` | Config | CDB/non-CDB | destructive | Loss of SPFILE | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/PARAMETERFILE/spfile.OMF.37A52C57 (FEX/ACFS managed storage handle requires provider-aware crash injection; this @... handle is not a local filesystem path) |
| `28` | Config | CDB/non-CDB | destructive | Loss of ORACLE_HOME | Scenario 28 ORACLE_HOME loss requires an external restore/reinstall plan and is intentionally dry-run/manual only in this framework. |
| `29` | Backup | CDB/non-CDB | destructive | Loss of FRA destination | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM(RECO_HC_HIGHREDUNDANCY) (FEX/ACFS managed storage handle requires provider-aware crash injection; this @... handle is not a local filesystem path) |
| `30` | PDB | PDB | destructive | PDB loss of one non-system datafile | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/USERS.OMF.7A32E8B8 (FEX/ACFS managed storage handle requires provider-aware datafile loss injection; this @... handle is not a local filesystem path) |
| `31` | PDB | PDB | destructive | PDB loss of one temporary file | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/TEMPFILE/TEMP.OMF.7E47A0BB (FEX/ACFS managed storage handle requires provider-aware tempfile loss injection; this @... handle is not a local filesystem path) |
| `32` | PDB | PDB | destructive | PDB loss of one SYSTEM datafile | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/SYSTEM.OMF.49D473E6 (FEX/ACFS managed storage handle requires provider-aware datafile loss injection; this @... handle is not a local filesystem path) |
| `33` | PDB | PDB | destructive | PDB loss of one UNDO datafile | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/UNDOTBS1.OMF.79BB15E3 (FEX/ACFS managed storage handle requires provider-aware datafile loss injection; this @... handle is not a local filesystem path) |
| `34` | PDB | PDB | destructive | PDB loss of read-only tablespace | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/CRASHSIM_RO_TBS.OMF.3653F3F1 (FEX/ACFS managed storage handle requires provider-aware datafile loss injection; this @... handle is not a local filesystem path) |
| `35` | PDB | PDB | destructive | PDB loss of index-only tablespace | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/CRASHSIM_INDEX_TBS.OMF.4F7C5839 (FEX/ACFS managed storage handle requires provider-aware datafile loss injection; this @... handle is not a local filesystem path) |
| `37` | PDB | PDB | destructive | PDB loss of non-system tablespace | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/CRASHSIM_INDEX_TBS.OMF.4F7C5839 (FEX/ACFS managed storage handle requires provider-aware datafile loss injection; this @... handle is not a local filesystem path) |
| `38` | PDB | PDB | destructive | PDB loss of temporary tablespace | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/TEMPFILE/TEMP.OMF.7E47A0BB (FEX/ACFS managed storage handle requires provider-aware tempfile loss injection; this @... handle is not a local filesystem path) |
| `39` | PDB | PDB | destructive | PDB loss of SYSTEM tablespace | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/SYSTEM.OMF.49D473E6 (FEX/ACFS managed storage handle requires provider-aware datafile loss injection; this @... handle is not a local filesystem path) |
| `40` | PDB | PDB | destructive | PDB loss of UNDO tablespace | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/UNDOTBS1.OMF.79BB15E3 (FEX/ACFS managed storage handle requires provider-aware datafile loss injection; this @... handle is not a local filesystem path) |
| `41` | PDB | PDB | destructive | PDB loss of all datafiles | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/SYSTEM.OMF.49D473E6 (FEX/ACFS managed storage handle requires provider-aware datafile loss injection; this @... handle is not a local filesystem path) |
| `42` | PDB | PDB | destructive | PDB SYSTEM file header corruption | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/53B77AB496E44BD8E0633400020A4FF3/DATAFILE/SYSTEM.OMF.49D473E6 (FEX/ACFS managed storage handle requires provider-aware header-corruption handling; this @... handle is not a local filesystem path) |
| `45` | PDB | PDB | destructive | Drop selected PDB including datafiles | Scenario 45 can only execute against a disposable PDB whose name starts with CRASHSIM_. Current PDB: CRASHPDB. |
| `46` | ASM | ASM/FEX | destructive | ASM/FEX data storage unavailable | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM(RECO_HC_HIGHREDUNDANCY) (FEX/ACFS managed storage outage requires provider-aware fault injection, service impact validation, and RMAN/GI recovery checks) |
| `47` | GI | Cluster | destructive | OCR loss or restore drill | Selected target requires a provider-specific or manual handler before safe execution: OCR (OCR restore practice must use a root/Grid procedure, verified OCR backups, and CRS validation) |
| `48` | GI | Cluster | destructive | Voting disk loss or restore drill | Selected target requires a provider-specific or manual handler before safe execution: VOTING_DISK (Voting disk replacement practice must use a root/Grid procedure and cluster membership validation) |
| `49` | ASM | ASM/FEX | destructive | ASM/FEX SPFILE loss | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/PARAMETERFILE/spfile.OMF.37A52C57 (FEX/ACFS managed SPFILE loss requires provider-aware metadata restore, srvctl database validation, and instance restart/recovery checks) |
| `52` | DataGuard | DG | logical | Data Guard broker configuration unavailable | Selected target requires a provider-specific or manual handler before safe execution: DG_BROKER_CONFIG (Approved lab action only: make broker configuration unavailable or stop broker management, then validate DGMGRL/SQL warnings and restore broker configuration. CrashSimulator keeps this plan-only.) |
| `59` | Backup | CDB/non-CDB | destructive | Missing archived redo log | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM/CREASHRAC-A4FEA717C5C96F3BFFC46A6348A21A9F/CRASHRDB/ARCHIVELOG/2026_06_08/thread_2_seq_35.OMF.643CBEB6 (FEX/ACFS managed storage handle requires provider-aware crash injection; this @... handle is not a local filesystem path) |
| `66` | DataGuard | DG | logical | FSFO observer unavailable | Selected target requires a provider-specific or manual handler before safe execution: FSFO_OBSERVER (Stop or isolate the observer host/process, then validate broker status, failover expectations, and observer restart. CrashSimulator keeps this plan-only.) |
| `72` | ASM | ASM/FEX | destructive | ASM/FEX storage component failure | Selected target requires a provider-specific or manual handler before safe execution: @rJOnB8bM(RECO_HC_HIGHREDUNDANCY) (FEX/ACFS storage-component failure should be injected through provider-approved storage controls; validate database service continuity, GI resources, RMAN recoverability, and provider redundancy/rebuild evidence) |

## Not Runnable Now

| ID | Group | Scope | Impact | Scenario | Reason |
| --- | --- | --- | --- | --- | --- |
| `50` | DataGuard | Standby | logical | Standby managed recovery cancelled | Scenario 50 requires a physical standby database with managed recovery running. Run it on a standby environment, then confirm an MRP process is visible in V$MANAGED_STANDBY. |
| `53` | ADG | Standby | logical | Active Data Guard read-only session pressure | Scenario 53 requires an Active Data Guard standby opened READ ONLY WITH APPLY. Run it on an ADG standby after confirming open mode and apply status. |
| `54` | DataGuard | Standby | logical | Snapshot standby conversion practice | Scenario 54 requires a Data Guard physical standby that is approved for snapshot-standby conversion practice. Run it on the standby after confirming flashback, broker/transport posture, and restore-point policy. |
| `67` | DataGuard | Standby | logical | Data Guard apply lag exceeds SLA | Scenario 67 requires a physical standby database with managed recovery running. Run it on a standby environment, then confirm an MRP process is visible in V$MANAGED_STANDBY. |
| `70` | RAC | RAC | logical | RAC VIP relocation drill | Unable to collect Clusterware resource status with crsctl. |
| `73` | APEX/ORDS | Application | logical | ORDS service unavailable | ORDS is not installed or not in PATH. Install/configure ORDS on this host before running scenario 73. |
| `74` | APEX/ORDS | Application | destructive | ORDS configuration unavailable | ORDS configuration directory was not found at /etc/ords/config. Configure ORDS or pass --ords-config-dir before running scenario 74. |
| `75` | APEX/ORDS | Application | logical | ORDS database pool misconfiguration | ORDS is not installed or not in PATH. Install/configure ORDS before running scenario 75. |
| `77` | APEX/ORDS | Application | destructive | APEX static resources unavailable | No APEX static images directory was found. Install APEX static files and pass --apex-images-dir before running scenario 77. |
| `79` | APEX/ORDS | Application | logical | ORDS node unavailable behind load balancer | ORDS is not installed or not in PATH. Install/configure ORDS on this host before running scenario 79. |

## How CrashSimulator Uses This Result

- `--scenario <id> --execute`, `--protect <id> --execute`, and aleatory scenario execution run readiness validation before confirmation or destructive actions.
- Guided Workflow scenario selection now shows the selected scenario readiness status immediately.
- Use only `RUNNABLE` scenarios for execution drills. Review `PLAN-ONLY` and `NOT-RUNNABLE` reasons before changing topology, targets, or helper coverage.
- Re-run this report after changing database topology, adding PDBs, multiplexing redo/control files, configuring Data Guard, adding ASM/GI lab disks, reseeding logical objects, or taking fresh backups.

## Recommended Next Commands

```bash
./CrashSimulatorV2.sh --validate-scenario <id> --pdb CRASHPDB
./CrashSimulatorV2.sh --scenario <id> --pdb CRASHPDB --dry-run
./CrashSimulatorV2.sh --runbook <id> --pdb CRASHPDB
./CrashSimulatorV2.sh --health-check --pdb CRASHPDB
```
