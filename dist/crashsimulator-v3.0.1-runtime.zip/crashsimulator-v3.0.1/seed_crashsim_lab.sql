whenever sqlerror exit sql.sqlcode
set echo on feedback on serveroutput on
set verify off

-- ---------------------------------------------------------------------------
-- Lab user passwords are parameterised (roadmap #3) — never hardcoded here.
-- Provide the password through the substitution variable crashsim_lab_password:
--   * Recommended: run  tools/crashsim_seed_lab.sh  (prompts hidden, or reads
--                  CRASHSIM_LAB_PASSWORD, then DEFINEs it for this script).
--   * Manual:      SQL> define crashsim_lab_password = <redacted>
--                  SQL> @seed_crashsim_lab.sql
--   * If left undefined you are prompted once (input is NOT hidden that way).
-- 'set verify off' above is REQUIRED: it stops SQL*Plus echoing the substituted
-- password value in its old/new verification lines.
-- ---------------------------------------------------------------------------

-- Fail fast if the password is missing or too weak, so we never create lab
-- users with an empty or trivial password.
begin
  if '&&crashsim_lab_password' is null
     or length('&&crashsim_lab_password') < 8 then
    raise_application_error(-20001,
      'crashsim_lab_password is unset or shorter than 8 chars. '
      || 'Run tools/crashsim_seed_lab.sh, or DEFINE it before running this script.');
  end if;
end;
/

alter session set container = cdb$root;

begin
  for rec in (
    select tablespace_name, status
    from dba_tablespaces
    where tablespace_name in (
      'CRASHSIM_ROOT_RO_TBS',
      'CRASHSIM_ROOT_INDEX_TBS'
    )
  ) loop
    if rec.status = 'READ ONLY' then
      execute immediate 'alter tablespace ' || rec.tablespace_name || ' read write';
    end if;
  end loop;

  for rec in (
    select username
    from dba_users
    where username = 'C##CRASHSIM_ROOT_LAB'
  ) loop
    execute immediate 'drop user ' || rec.username || ' cascade';
  end loop;

  for rec in (
    select tablespace_name
    from dba_tablespaces
    where tablespace_name in (
      'CRASHSIM_ROOT_RO_TBS',
      'CRASHSIM_ROOT_INDEX_TBS'
    )
  ) loop
    execute immediate 'drop tablespace ' || rec.tablespace_name ||
      ' including contents and datafiles';
  end loop;
end;
/

-- Datafile clause: use Oracle-managed files when db_create_file_dest is set,
-- otherwise derive an explicit path from an existing datafile in this container
-- so the seed also works on databases where OMF is not configured.
column crashsim_df_clause new_value crashsim_df_clause
select case
         when (select value from v$parameter where name = 'db_create_file_dest') is not null
           then 'size 16m autoextend on next 16m maxsize 128m'
         else '''' ||
              (select substr(f.name, 1, instr(f.name, '/', -1)) from v$datafile f where rownum = 1) ||
              'crashsim_root_ro_tbs_01.dbf'' size 16m reuse autoextend on next 16m maxsize 128m'
       end crashsim_df_clause
  from dual;
create tablespace crashsim_root_ro_tbs
  datafile &crashsim_df_clause;

-- Datafile clause: use Oracle-managed files when db_create_file_dest is set,
-- otherwise derive an explicit path from an existing datafile in this container
-- so the seed also works on databases where OMF is not configured.
column crashsim_df_clause new_value crashsim_df_clause
select case
         when (select value from v$parameter where name = 'db_create_file_dest') is not null
           then 'size 16m autoextend on next 16m maxsize 128m'
         else '''' ||
              (select substr(f.name, 1, instr(f.name, '/', -1)) from v$datafile f where rownum = 1) ||
              'crashsim_root_index_tbs_01.dbf'' size 16m reuse autoextend on next 16m maxsize 128m'
       end crashsim_df_clause
  from dual;
create tablespace crashsim_root_index_tbs
  datafile &crashsim_df_clause;

create user c##crashsim_root_lab identified by "&&crashsim_lab_password" container=all;
grant create session, create table to c##crashsim_root_lab container=current;
alter user c##crashsim_root_lab quota unlimited on users container=current;
alter user c##crashsim_root_lab quota unlimited on crashsim_root_ro_tbs container=current;
alter user c##crashsim_root_lab quota unlimited on crashsim_root_index_tbs container=current;

create table c##crashsim_root_lab.root_readonly_target (
  id number primary key,
  payload varchar2(100),
  created_at timestamp default systimestamp
) tablespace crashsim_root_ro_tbs;

insert into c##crashsim_root_lab.root_readonly_target (id, payload)
select level, 'root-readonly-row-' || level
from dual
connect by level <= 10;

alter tablespace crashsim_root_ro_tbs read only;

create table c##crashsim_root_lab.root_index_base (
  id number primary key,
  lookup_value varchar2(30),
  payload varchar2(100)
) tablespace users;

insert into c##crashsim_root_lab.root_index_base
select level, 'L' || mod(level, 5), 'root-index-row-' || level
from dual
connect by level <= 50;

create index c##crashsim_root_lab.root_index_payload_ix
  on c##crashsim_root_lab.root_index_base (payload)
  tablespace crashsim_root_index_tbs;

commit;

select owner, table_name, tablespace_name
from dba_tables
where owner = 'C##CRASHSIM_ROOT_LAB'
order by owner, table_name;

select owner, index_name, tablespace_name
from dba_indexes
where owner = 'C##CRASHSIM_ROOT_LAB'
order by owner, index_name;

select tablespace_name, contents, status
from dba_tablespaces
where tablespace_name like 'CRASHSIM_ROOT\_%' escape '\'
order by tablespace_name;

column crashsim_target_pdb new_value crashsim_target_pdb noprint
select coalesce(
         max(case when name = 'CRASHPDB' and open_mode = 'READ WRITE' then name end),
         min(case when name <> 'PDB$SEED' and open_mode = 'READ WRITE' then name end)
       ) crashsim_target_pdb
from v$pdbs;

prompt Seeding PDB lab targets in &&crashsim_target_pdb

alter session set container = &&crashsim_target_pdb;

begin
  for rec in (
    select tablespace_name, status
    from dba_tablespaces
    where tablespace_name in (
      'CRASHSIM_RO_TBS',
      'CRASHSIM_INDEX_TBS'
    )
  ) loop
    if rec.status = 'READ ONLY' then
      execute immediate 'alter tablespace ' || rec.tablespace_name || ' read write';
    end if;
    execute immediate 'drop tablespace ' || rec.tablespace_name ||
      ' including contents and datafiles';
  end loop;

  for rec in (
    select username
    from dba_users
    where username in (
      'CRASHSIM_TABLE_LAB',
      'CRASHSIM_SCHEMA_LAB',
      'CRASHSIM_INDEX_LAB'
    )
  ) loop
    execute immediate 'drop user ' || rec.username || ' cascade';
  end loop;
end;
/

create user crashsim_table_lab identified by "&&crashsim_lab_password" quota unlimited on users;
grant create session, create table, create sequence to crashsim_table_lab;

create table crashsim_table_lab.crash_table_target (
  id number generated by default as identity,
  payload varchar2(100),
  created_at timestamp default systimestamp,
  constraint crash_table_target_pk primary key (id)
);

insert into crashsim_table_lab.crash_table_target (payload)
select 'table-loss-row-' || level
from dual
connect by level <= 10;

create user crashsim_schema_lab identified by "&&crashsim_lab_password" quota unlimited on users;
grant create session, create table, create sequence to crashsim_schema_lab;

create table crashsim_schema_lab.schema_drop_target (
  id number primary key,
  payload varchar2(100)
);

insert into crashsim_schema_lab.schema_drop_target
select level, 'schema-loss-row-' || level
from dual
connect by level <= 10;

create user crashsim_index_lab identified by "&&crashsim_lab_password" quota unlimited on users;
grant create session, create table, create sequence to crashsim_index_lab;

create table crashsim_index_lab.index_target (
  id number primary key,
  lookup_value varchar2(30),
  payload varchar2(100)
);

insert into crashsim_index_lab.index_target
select level, 'L' || mod(level, 5), 'index-loss-row-' || level
  from dual
  connect by level <= 50;

create index crashsim_index_lab.index_target_lookup_ix
  on crashsim_index_lab.index_target (lookup_value);

-- Datafile clause: use Oracle-managed files when db_create_file_dest is set,
-- otherwise derive an explicit path from an existing datafile in this container
-- so the seed also works on databases where OMF is not configured.
column crashsim_df_clause new_value crashsim_df_clause
select case
         when (select value from v$parameter where name = 'db_create_file_dest') is not null
           then 'size 16m autoextend on next 16m maxsize 128m'
         else '''' ||
              (select substr(f.name, 1, instr(f.name, '/', -1)) from v$datafile f where rownum = 1) ||
              'crashsim_ro_tbs_01.dbf'' size 16m reuse autoextend on next 16m maxsize 128m'
       end crashsim_df_clause
  from dual;
create tablespace crashsim_ro_tbs
  datafile &crashsim_df_clause;

alter tablespace crashsim_ro_tbs read only;

-- Datafile clause: use Oracle-managed files when db_create_file_dest is set,
-- otherwise derive an explicit path from an existing datafile in this container
-- so the seed also works on databases where OMF is not configured.
column crashsim_df_clause new_value crashsim_df_clause
select case
         when (select value from v$parameter where name = 'db_create_file_dest') is not null
           then 'size 16m autoextend on next 16m maxsize 128m'
         else '''' ||
              (select substr(f.name, 1, instr(f.name, '/', -1)) from v$datafile f where rownum = 1) ||
              'crashsim_index_tbs_01.dbf'' size 16m reuse autoextend on next 16m maxsize 128m'
       end crashsim_df_clause
  from dual;
create tablespace crashsim_index_tbs
  datafile &crashsim_df_clause;

alter user crashsim_index_lab quota unlimited on crashsim_index_tbs;

create index crashsim_index_lab.index_target_payload_ix
  on crashsim_index_lab.index_target (payload)
  tablespace crashsim_index_tbs;

commit;

select owner, table_name
from dba_tables
where owner like 'CRASHSIM\_%' escape '\'
order by owner, table_name;

select owner, index_name, uniqueness
from dba_indexes
where owner like 'CRASHSIM\_%' escape '\'
order by owner, index_name;

select tablespace_name, contents, status
from dba_tablespaces
where tablespace_name like 'CRASHSIM\_%' escape '\'
order by tablespace_name;

alter session set container = cdb$root;

exit
