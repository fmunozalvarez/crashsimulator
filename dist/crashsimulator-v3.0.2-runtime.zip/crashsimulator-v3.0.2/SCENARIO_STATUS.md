# CrashSimulator Scenario Status

Snapshot date: 2026-06-15

This status reflects the first OCI Base DB Service validation environment and
the RAC/GI/ASM validation environments, including the current two-node RAC lab.

Current framework registry snapshot:

- `123` total catalog entries: `103` database-host, application access-path,
  and platform/readiness scenarios across Core, PDB, Backup, Config, Corrupt,
  Logical, ASM, GI, Data Guard, Active Data Guard, RAC, Network, Security,
  Compliance, APEX/ORDS, Services, Recovery, Lifecycle, Exadata, OCI DB, and
  GoldenGate groups, plus `ADB01` through `ADB20` Autonomous Database
  cloud-service scenarios.
- Newly added high-value resilience drills: `61` FRA pressure, `62` required
  archived-log recovery gap, `63` TEMP exhaustion, `64` RTO validation, and
  `65` RPO validation.
- Newly added topology-specific drills: `66` FSFO observer unavailable, `67`
  Data Guard apply lag, `68` Data Guard transport partition, `69` standby redo
  log review, `70` RAC VIP relocation planning, `71` RAC service placement
  failure, and `72` ASM single-disk failure planning.
- Recovery automation is available for the reversible DG/RAC additions `67`,
  `68`, and `71`; `66`, `69`, `70`, and `72` are intentionally plan-only or
  review-only until a matching DG/RAC/ASM lab topology is explicitly approved.
- Newly added APEX/ORDS application access-path drills: `73` ORDS service
  unavailable, `74` ORDS configuration unavailable, `75` ORDS pool
  misconfiguration, `76` APEX/ORDS runtime account locked, `77` APEX
  static resources unavailable, `78` APEX availability smoke validation, `79`
  ORDS node unavailable behind a load balancer, `80` APEX session continuity
  evidence, `81` APEX mail configuration validation, and `82` APEX
  upgrade/patch rollback readiness.
- Newly added service-continuity, transition, lifecycle, and platform drills:
  `83` AC/TAC replay validation, `84` FAN/ONS notification unavailable, `85`
  planned Data Guard switchover, `86` Data Guard failback rehearsal, `87`
  role-based service validation, `88` PDB PITR, `89` guaranteed restore point
  rollback, `90` database patch rollback readiness, `EXA01` through `EXA04`
  Exadata readiness drills, `OCI01` through `OCI05` OCI Base Database Service
  readiness drills, and `GG01` through `GG04` GoldenGate readiness drills.
  These are intentionally evidence/runbook-first and block execution until the
  platform-specific lab target, rollback path, and approval boundary are known.
- Autonomous Database coverage is tracked as a separate cloud-service scenario
  catalog, `ADB01` through `ADB20`, rather than as host-level destructive
  scenario IDs. `--list-adb-scenarios`, `--adb-scenario <id>`, and the Guided
  Workflow Autonomous Database scenarios submenu let users browse the catalog,
  select `ADB01` through `ADB20`, inspect readiness status, configure ADB
  context, and refresh ADB readiness evidence. The Guided Workflow Reports menu
  also exposes ADB options `12` through `18` for context, readiness report
  generation, report browsing, scenario list/select/detail, and the full ADB
  submenu. `--adb-readiness-report`
  validates wallet/client connectivity, SQL evidence, APEX visibility,
  Flashback Archive posture, OCI control-plane gaps, and ADB-specific scenario
  readiness for logical recovery, clone/PITR, wallet rotation, private
  endpoint, resource pressure, Autonomous Data Guard, IAM, Object Storage,
  Database Actions, APEX workspace access, cross-region clone validation,
  wallet distribution drift, and OCI IAM token-expiration drills.

Autonomous Database validation environment:

- Live ADB target reached through the bastion client path with the supplied
  wallet and `python-oracledb` 4.0.1.
- SQL probe connected as `ADMIN` to Oracle AI Database 26ai
  `<ip-redacted>.0`, database `FCEYFTL6`, open read write, primary role,
  ARCHIVELOG, and CDB enabled.
- APEX registry is `24.2.17:VALID`, invalid object count is `0`, Flashback
  Archive retention is `60` days, encrypted tablespaces detected: `6`, and
  reported segment size is `165.09 GB`.
- The original ADB readiness operational check score was `85%`: client wallet,
  `python-oracledb`, SQL connectivity, APEX visibility, Flashback Archive, and
  user-facing URLs passed; OCI CLI/ADB OCID metadata is still required for
  backup/PITR/clone/ADG/IAM/Object Storage proof. The current report also
  includes a separate ADB domain scorecard for Backup Readiness, PITR,
  Autonomous Data Guard, Cross-Region DR, IAM, wallet lifecycle, private
  endpoint, Resource Manager, logical/object recovery, and application access.
- Reference artifacts:
  the ADB readiness report the runtime generates locally (Markdown, HTML and
  evidence forms). Those artifacts are produced on your own target; they are
  no longer shipped pre-populated in the distribution.

Oracle AI Database 26ai RAC/ASM validation environment:

- Oracle AI Database 26ai EE Extreme Perf Release `<ip-redacted>.0`
- Two-node RAC primary database `CRASHDB`, DB unique name `crashdb_26ai`
- CDB with PDB `CRASHDB_PDB1`
- ASM storage with `DATA` and `RECO` diskgroups
- No standby database and no Active Data Guard in this lab
- Lab objects reseeded with `seed_crashsim_lab.sql`; the script now detects
  `CRASHPDB` when present, otherwise the first read-write user PDB
- Online redo groups multiplexed across `+RECO` and `+DATA`
- Control files multiplexed across `+RECO` and `+DATA`
- Fresh RMAN baseline backup completed with tag `C26AI_260607031353`; a
  post-APEX/ORDS baseline refresh was completed with tag
  `C26AIAPEX_260607073734`.
- MAA readiness report detected Silver posture with baseline checks passed
- Backup report detected Level 0/full datafile backup strategy with archived
  redo backups after patching full/non-incremental backup detection
- APEX 26.1.0 installed in PDB `CRASHDB_PDB1` and validated as `VALID` with no
  invalid APEX objects.
- ORDS 26.1.2 installed on both RAC nodes. Node 1 ORDS pool was configured
  against the RAC SCAN and PDB service, verified successfully, and node 2 was
  synchronized to the same ORDS configuration and static-resource posture.
- APEX/ORDS readiness reporting and scenarios `73` through `82` are implemented
  in the framework. Destructive execution is gated by ORDS service permissions,
  writable/reversible config/static directories, load-balancer URL availability,
  and APEX/ORDS installation status.
- Restricted ORDS OS action helper `/usr/local/bin/crashsim_ords_priv` was
  installed on both RAC nodes and granted only through a narrow sudoers rule for
  the Oracle software owner. It permits ORDS service control and reversible
  `/etc/ords/config` rename/restore only.
- A lab peer-continuity URL was enabled at `http://localhost:18080/ords/` on
  each RAC node through a node-to-node tunnel. This supports scenario `79`
  continuity practice, but a real load-balancer URL is still preferred for
  production-grade load-balancer health-check/routing validation.

26ai scenario readiness result:

- `49` scenarios runnable in this RAC/ASM/APEX/ORDS/no-Data-Guard topology
- `23` scenarios plan-only because they require ASM/GI/provider-specific
  destructive handlers, a disposable PDB, explicit backup-piece selection, or
  external restore practice
- `10` scenarios not runnable because this lab has no Data Guard/Active Data
  Guard topology, no NORMAL/HIGH/FLEX ASM diskgroup for single-disk failure
  practice
- All `49` runnable scenarios completed readiness validation successfully:
  `5`, `6`, `7`, `8`, `9`, `10`, `11`, `12`, `13`, `14`, `15`, `17`, `22`,
  `27`, `30`, `31`, `32`, `33`, `34`, `35`, `36`, `37`, `38`, `39`, `40`,
  `41`, `42`, `43`, `44`, `55`, `56`, `57`, `58`, `60`, `61`, `63`, `64`,
  `65`, `71`, `73`, `74`, `75`, `76`, `77`, `78`, `79`, `80`, `81`, and
  `82`.
- APEX/ORDS scenarios `73`, `74`, `75`, `76`, `77`, and `79` were executed and
  recovered successfully; read-only scenarios `78`, `80`, `81`, and `82`
  generated evidence reports. Scenario `73` restarted ORDS through the
  restricted helper, `74` restored `/etc/ords/config` through the helper, `75`
  restored the original ORDS `db.servicename`, and `79` used the lab peer
  continuity URL after the local ORDS service was stopped. Scenario `80`
  generated read-only APEX/ORDS continuity evidence.
- Scenario `76` initially exposed a CDB recovery-helper gap because unlock ran
  from root instead of the PDB; the helper now reads the target container from
  the manifest and recovery was revalidated in `CRASHDB_PDB1`. Scenario `77`
  restored `/opt/oracle/apex/images` with no `.crashsim.bak` leftovers.
  Scenarios `78`, `81`, and `82` were also executed and evidence reports were
  generated.
- A real ORDS load-balancer URL should still be supplied for production-grade
  scenario `79`; the 26ai lab evidence used a peer continuity endpoint because
  node-to-node ORDS port access was restricted by the environment.
- Scenario `80` now has an optional seeded APEX browser-session driver
  (`tools/crashsim_apex_session_driver.cjs`) for end-user screenshots,
  Markdown, and JSON evidence when a disposable APEX test application URL and
  success selector are supplied.
- Post-validation health check showed CDB/PDB open read write, no
  `V$RECOVER_FILE` rows, and no `V$DATABASE_BLOCK_CORRUPTION` rows.
- Evidence files are written locally by the runtime; the sanitized examples live under `docs/reference/26ai/`.

New 26ai RAC/FEX smoke validation on 2026-06-15:

- The updated catalog and ADB catalog were deployed to the 26ai RAC node
  `/tmp/crashsimulator/CrashSimulatorV2.sh`.
- `--list-scenarios` shows scenarios `83` through `90`, `EXA01` through
  `EXA04`, `OCI01` through `OCI05`, and `GG01` through `GG04`.
- `--list-adb-scenarios` shows `ADB01` through `ADB20`.
- Readiness validation was run for representative new scenarios `83`, `84`,
  `85`, `86`, `87`, `88`, `89`, `90`, `EXA01`, `OCI01`, and `GG01`.
  Results were correct for this no-Data-Guard, non-Exadata, no-GoldenGate lab:
  service/platform drills returned plan-only external-action blockers; Data
  Guard switchover/failback returned a clear Data Guard prerequisite; PDB PITR,
  GRP rollback, and patch rollback readiness generated operator-approved
  plan/runbook blockers.
- Full dry-run of scenario `83` generated service-continuity evidence and a
  report without changing the database.
- Refreshed lifecycle and topology-versus-scenario readiness reports are stored
  under `captures/26ai_new_rac_20260615/new_scenarios_20260615/`.

First OCI Base DB Service validation environment:

- Oracle Database 19.31 Enterprise Edition
- CDB `CRASHDB` with PDB `CRASHPDB`
- Single-instance primary database
- Filesystem/LVM storage, no ASM
- No RAC, no standby, no Active Data Guard
- Backups to Object Storage/SBT, with local filesystem drills constrained where required

The required patched project files on the server and laptop were compared by
SHA-256 and matched for the framework, README, seed/verify scripts, and drill
SQL/RMAN helpers. Generated manifests and logs under `/tmp/crashsim_logs` are
environment-specific evidence and are not source-controlled by default.

## Validated In This Environment

The following scenarios were dry-run checked, executed where a target existed,
recovered, and followed by database/PDB health validation:

- `1`: loss of one control file
- `2`: loss of all control files
- `4`: loss of all members from current redo group
- `5`: loss of one non-system datafile
- `6`: loss of one temporary file
- `7`: loss of one SYSTEM datafile
- `16`: loss of password file
- `17`: loss of all datafiles
- `19`: loss of all inactive redo groups
- `20`: loss of all active redo groups
- `21`: loss of all current redo group members
- `23`: control file corruption
- `24`: redo log corruption
- `25`: loss of local RMAN backup piece, using `--local-only --max-targets 1`
- `26`: loss of SPFILE
- `30`: PDB loss of one non-system datafile
- `31`: PDB loss of one temporary file
- `32`: PDB loss of one SYSTEM datafile
- `41`: PDB loss of all datafiles
- `59`: missing archived redo log

Final validation after the higher-risk batch showed:

- Database open read write
- PDB `CRASHPDB` open read write
- `V$RECOVER_FILE` count `0`
- `V$DATABASE_BLOCK_CORRUPTION` count `0`
- No remaining `.crashsim.bak` artifacts

## No Valid Target In This Environment

- `3`: loss of one member from current redo group
- `18`: loss of one member from multiplexed redo group

The test database did not have the required redo-log member shape for these
single-member drills. They should be validated in an environment with
multiplexed redo logs.

## Implemented But Still Awaiting Validation

These scenarios have handlers registered in the framework but still need
environment-specific dry-run, protection, execution, recovery, and validation:

- `8`: loss of one UNDO datafile
- `9`: loss of a read-only tablespace
- `10`: loss of an index-only tablespace
- `12`: loss of a non-system tablespace
- `13`: loss of a temporary tablespace
- `14`: loss of SYSTEM tablespace
- `15`: loss of UNDO tablespace
- `22`: datafile header corruption
- `28`: loss of ORACLE_HOME
- `29`: loss of FRA destination
- `33`: PDB loss of one UNDO datafile
- `34`: PDB loss of read-only tablespace
- `35`: PDB loss of index-only tablespace
- `37`: PDB loss of non-system tablespace
- `38`: PDB loss of temporary tablespace
- `39`: PDB loss of SYSTEM tablespace
- `40`: PDB loss of UNDO tablespace
- `42`: PDB SYSTEM file header corruption
- `50`: standby managed recovery cancelled
- `51`: primary transport destination deferred
- `61`: FRA reaches critical utilization
- `62`: missing required archived log during recovery
- `63`: TEMP tablespace exhaustion
- `64`: RTO validation drill
- `65`: RPO validation drill
- `66`: FSFO observer unavailable
- `67`: Data Guard apply lag exceeds SLA
- `68`: Data Guard transport network partition
- `69`: standby redo log misconfiguration review
- `70`: RAC VIP relocation drill
- `71`: RAC service placement failure
- `72`: ASM/FEX storage component failure
- APEX/ORDS scenarios `73` through `82`: implemented and validated in the 26ai
  RAC/ASM/APEX/ORDS lab. Scenarios `73`, `74`, `75`, `76`, `77`, and `79` now
  have execution/recovery evidence; `78`, `80`, `81`, and `82` have read-only
  evidence reports. Scenario `80` can add seeded browser-session evidence when
  the optional driver and a disposable APEX application URL are supplied.
  Scenario `79` should be rerun with a production load balancer URL when
  available; the current lab used peer continuity evidence.

Re-run `seed_crashsim_lab.sql` before table, schema, index-loss, read-only
tablespace, or index-only tablespace scenarios.

Storage compatibility update:

- CrashSimulator now classifies conventional ASM `+...` paths, opaque Oracle
  FEX-style `@...` storage handles, and visible ACFS filesystem paths
  separately.
- File-level drills no longer treat `@...` handles as local filesystem paths.
  They become provider-managed plan-only targets unless a future provider-aware
  injector is explicitly added.
- Scenarios `46`, `49`, and `72` now plan against ASM and FEX/ACFS-style
  managed storage. Conventional ASM still uses ASM disk group/SPFILE/disk
  evidence; FEX/ACFS emits provider-aware outage, SPFILE, and storage-component
  runbook evidence.

## Initial RAC/GI/ASM Validation

The RAC One Node/GI/ASM environment uses Oracle Database 19.31, CDB
`CRASHDB`, PDB `CRASHPDB`, DB unique name `crashdb_test2`, GI-managed
single-database topology detected as `GI_SINGLE`, and ASM disk groups `DATA`
and `RECO`.

- `55`: dry-run, execute, manual `srvctl start database` recovery, automated
  `--recover 55 --execute` validation, and post-drill health check completed.
- Redo groups were multiplexed by adding one `+DATA` member to each group while
  retaining the original `+RECO` members.
- `18`: inactive multiplexed redo member removed from ASM as `grid`, recovered
  with the ASM redo recovery helper, and validated.
- `3`: current redo member target selected and recovery helper dry-run
  validated. Destructive injection was not forced because ASM refused removal of
  the current file with ORA-15028 and Oracle refused logical drop with ORA-01609.
- `30`: protected FILE# `12`, removed the PDB USERS datafile from ASM, restored
  and recovered it, and reopened `CRASHPDB`.
- `32`: protected FILE# `8`, removed the PDB SYSTEM datafile from ASM, restored
  and recovered it, and reopened `CRASHPDB`.
- `41`: protected FILE# list `8,9,10,12`, removed all `CRASHPDB` datafiles from
  ASM, restored and recovered the list, reopened `CRASHPDB`, and restarted the
  PDB service.
- `7`: protected FILE# `1`, stopped the GI-managed database, removed the root
  SYSTEM datafile from ASM, restored and recovered in mount mode, and validated
  Clusterware/service state.
- `46`: ASM disk-group planning helper implemented and dry-run validated.
- `47`: OCR planning helper implemented and dry-run validated with `ocrcheck`
  and OCR backup listing evidence. A manual OCR backup was also created.
- `48`: voting-disk planning helper implemented and dry-run validated.
- `49`: ASM SPFILE planning helper implemented and dry-run validated, with
  `srvctl config asm` evidence. An ASM SPFILE backup was created in `+RECO`.
- `60`: RMAN recovery catalog lab created in `CRASHPDB`, target database
  registered, scenario dry-run and execute completed, catalog resync validated,
  and `NOCATALOG` fallback restore-preview checks completed.
- Logical lab reseeding was expanded to include controlled PDB read-only and
  index-only tablespaces: `CRASHSIM_RO_TBS` and `CRASHSIM_INDEX_TBS`.
- `11`: executed safely against `CRASHPDB` by using
  `ORACLE_PDB_SID=CRASHPDB` plus `--schema CRASHSIM_INDEX_LAB`; non-unique
  index loss was validated and the lab objects were reseeded.
- `36`: executed against `CRASHPDB` with `--schema CRASHSIM_INDEX_LAB`;
  non-unique index loss was validated and reseeded.
- `43`: executed against `CRASHPDB` with `--schema CRASHSIM_TABLE_LAB`; table
  loss was validated and reseeded.
- `44`: executed against `CRASHPDB` with `--schema CRASHSIM_SCHEMA_LAB`; schema
  loss was validated and reseeded.
- `27` and `57`: executed against Oracle Home `network/admin` SQL*Net files,
  restored from `.crashsim.bak` copies, and validated with listener status plus
  local SQL*Plus verification. The active listener parameter file is in the Grid
  home, so these scenarios exercised the Oracle Home client/network config path.
- `45`: executed against disposable PDB `CRASHSIM_DROP_PDB` only; the PDB was
  dropped including datafiles and validated absent while `CRASHPDB` remained
  open read write.
- `33`, `34`, `35`, `37`, `38`, `39`, `40`, and `42`: dry-run target selection
  validated in `CRASHPDB`. Destructive execution remains blocked until the
  framework has ASM-aware injection and scenario-specific recovery helpers for
  these PDB datafile/tablespace variants.
- `8`, `12`, `13`, `14`, `15`, `22`, `28`, and `29`: dry-run target
  selection validated. ASM datafile/FRA targets remained provider-specific, and
  ORACLE_HOME execution was intentionally not performed without an external
  restore/reinstall plan.
- `9` and `10`: no valid CDB-root read-only or index-only tablespace target was
  present in this RAC/GI/ASM lab.
- A post-drill targeted RMAN backup captured `CRASHPDB` datafiles `31` and `32`
  for the new logical lab tablespaces, plus the current control file and SPFILE,
  and resynced the recovery catalog.
- `--maa-report`: Oracle MAA readiness reporting implemented and validated on
  the RAC/GI/ASM lab. The report detected a Bronze MAA posture for the current
  GI-managed single-database environment, with baseline backup/recoverability
  checks passing and expected gaps for Gold-or-higher posture because no Data
  Guard, FSFO, or standby topology is configured.
- FSFO observer best-practice awareness added to MAA/service reports. When
  FSFO is enabled, CrashSimulator now collects Data Guard Broker evidence,
  checks active observer evidence, multiple-observer posture,
  `PreferredObserverHosts`, and reports conservative placement guidance:
  external site preferred, primary site fallback if no external site exists,
  never colocate the active observer with the standby database.

## Two-Node RAC/GI/ASM Follow-Up Validation

The current two-node RAC lab uses Oracle Database 19.31, CDB `CRASHDB`, PDB
`CRASHPDB`, DB unique name `crashdb`, ASM storage, and a RAC service
`crashdb_CRASHPDB.paas.oracle.com` running on instances `crashdb1` and
`crashdb2`.

Additional framework improvements and validations completed:

- `56`: implemented as a RAC service drill. If a singleton service has a
  running source and idle target, the scenario plans a `srvctl relocate service`
  action. If the service is already running on all preferred instances, as in
  this lab, it performs a controlled `srvctl stop service ... -i <instance>` and
  `srvctl start service ... -i <instance>` cycle. The scenario was dry-run
  validated, executed against `crashdb_CRASHPDB.paas.oracle.com`, recovered with
  `--recover 56`, and followed by health validation.
- `27` and `57`: recovery helper coverage was added for filesystem rename
  restore pairs. Both scenarios were re-executed against Oracle Home
  `network/admin` SQL*Net files, restored with `--recover 27` / `--recover 57`,
  and followed by database/PDB health validation.
- `58`: recovery helper coverage was added for filesystem or ACFS wallet-root
  restore pairs. The TDE wallet-root scenario was dry-run checked, executed by
  renaming `/var/opt/oracle/dbaas_acfs/crashdb/wallet_root`, recovered with
  `--recover 58`, and followed by database/PDB health validation.
- `11`, `36`, `43`, and `44`: logical lab objects were reseeded, the scenarios
  were validated and executed against scoped lab schemas, and
  `seed_crashsim_lab.sql` was rerun afterward to restore the logical lab
  objects.
- `28`: validation now reports `PLAN-ONLY`; ORACLE_HOME loss requires an
  external restore/reinstall plan and is intentionally manual-only.
- `45`: validation and execution now require a disposable target PDB whose name
  starts with `CRASHSIM_`. The framework refuses to drop application PDBs such
  as `CRASHPDB`.
- `3`, `46`, `47`, `48`, and `49`: two-node preparation completed on
  2026-06-05. Redo groups were confirmed multiplexed across `+DATACRASHDB` and
  `+LOGCRASHDB`; a fresh manual OCR backup was created in `+GRID`; and an ASM
  SPFILE backup was created in `+RECOCRASHDB`. Dry-runs completed and remained
  correctly gated for destructive execution where the current storage topology
  is not safe.
- `8`, `12`, `13`, `15`, `22`, `33`, `34`, `35`, `37`, `38`, `40`, and `42`:
  ASM-aware destructive and recovery helper coverage was added. Datafile and
  tablespace scenarios now plan `asmcmd rm`-based ASM file loss actions with
  FILE# metadata in the manifest; tempfile scenarios plan ASM tempfile removal
  with multi-tempfile metadata repair; and ASM header-corruption drills use a
  documented loss-style surrogate that removes the ASM datafile and practices
  FILE# restore/recover. All listed scenarios were readiness validated on the
  two-node RAC lab, followed by dry-run scenario manifests and recovery dry-run
  generation. Datafile-based scenarios also produced `--protect` RMAN dry-run
  plans with the expected FILE# lists.
- `9` and `10`: controlled CDB-root targets were added and reseeded:
  `CRASHSIM_ROOT_RO_TBS` for read-only tablespace loss and
  `CRASHSIM_ROOT_INDEX_TBS` for index-only tablespace loss. Scenario target
  selection now prefers these lab tablespaces when present. Both scenarios were
  readiness validated on the two-node RAC lab and produced ASM `asmcmd rm`
  dry-run manifests, `--protect` RMAN dry-run plans, and `--recover` FILE#
  restore/recover dry-runs for FILE# `25` and FILE# `26`.

Final two-node RAC validation showed:

- Database `CRASHDB` open read write
- PDB `CRASHPDB` open read write
- `V$RECOVER_FILE` returned no rows
- `V$DATABASE_BLOCK_CORRUPTION` returned no rows
- Service `crashdb_CRASHPDB.paas.oracle.com` running on `crashdb1` and
  `crashdb2`
- Logical lab users, tables, non-unique indexes, read-only tablespace, and
  index-only tablespace present after reseed
- No remaining `.crashsim.bak` artifacts in the exercised SQL*Net or wallet-root
  paths

Destructive GI execution for `46`, `47`, `48`, and `49` remains blocked in this
lab because OCR, the only voting disk, and the ASM SPFILE are backed by `+GRID`,
all ASM disk groups use `EXTERN` redundancy, and the observed layout has one
ASM disk per disk group with no spare shared disks. Use a purpose-built
redundant GI lab before removing OCR/voting/ASM SPFILE resources.

A guarded preparation helper and runbook were added for the required redundant
GI/ASM lab foundation:

- `crashsim_prepare_redundant_gi_lab.sh`
- `docs/REDUNDANT_GI_LAB_RUNBOOK.md`

The helper can scan the current RAC/GI posture and generate or execute a
`NORMAL`/`HIGH` redundancy `CREATE DISKGROUP` plan once additional shared block
devices are provisioned and visible on all RAC nodes. It intentionally cannot
create OCI shared storage from the database host and does not use existing ASM
member disks.

Final RAC/GI/ASM validation showed:

- Database open read write
- PDB `CRASHPDB` open read write
- `V$RECOVER_FILE` count `0`
- `V$DATABASE_BLOCK_CORRUPTION` count `0`
- Online redo groups `1` through `8` each have two ASM members
- Clusterware database resource `ONLINE/STABLE`
- PDB service running
- No remaining `.crashsim.bak` artifacts
- Post-drill database, control-file, SPFILE, and logical-lab datafile backups
  completed

## Registered Placeholders Needing Implementation

These scenarios are registered and gated, but still need purpose-built
implementation before destructive validation:

- `52`: Data Guard broker configuration unavailable
- `53`: Active Data Guard read-only session pressure
- `54`: snapshot standby conversion practice

## Next Validation Environments

Use GitHub `fmunozalvarez/crashsimulator` as the main repository. Laptop and
server copies should be treated as working copies that pull from, test against,
and push back to GitHub.

Recommended next validation coverage:

- True storage-level current-redo fault injection for scenario `3`
- Redundant GI lab coverage for destructive scenarios `46`, `47`, `48`, and `49`
- Data Guard and Active Data Guard for scenarios `50`, `51`, `52`, `53`, `54`,
  `66`, `67`, `68`, and `69`
- RAC client/network/service validation for scenarios `70` and `71`
- Controlled destructive execution validation for the new ASM-aware root/PDB
  datafile and tempfile helpers: `8`, `12`, `13`, `15`, `22`, `33`, `34`,
  `35`, `37`, `38`, `40`, and `42`
- Redundant ASM disk failure validation for scenario `72`
- Controlled destructive execution validation for CDB-root read-only/index-only
  scenarios `9` and `10`
- High-value resilience/compliance drill validation for scenarios `61`, `62`,
  `63`, `64`, and `65`
- APEX/ORDS controlled execution validation for scenarios `73`, `74`, and `79`
  after ORDS service/config privileges and an optional load-balancer URL are
  confirmed; lab-script design for plan-only scenarios `75` and `80`
